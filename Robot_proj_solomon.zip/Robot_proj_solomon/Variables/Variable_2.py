URL = 'https://qa-productlinkweb.cat.com'
CGW_URL = 'https://qa-servicetool-beta.telematics-managed.com'