class handles():

    def __init__(self):
        self.pl_handle = ''
