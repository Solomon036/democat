import logging
from Actions.supportfiles.common import handles
import time
from datetime import datetime
from Actions.lib.plweb import ProductLinkWeb
from Actions.lib import webinterface
from Actions.lib.webinterface import WebInterface
from robot.api.deco import keyword
from Actions.supportfiles import constants
from Actions.supportfiles.meta import metafunctions
from robot.libraries.BuiltIn import BuiltIn
pl_handle = ''


# @keyword('PLWEB Login as user')
# def initializeplweb(url, username, password,):
#     """ Method to initialize the Product Link Web page. """
#     global pl_handle
#     url = 'https://qa-productlinkweb.cat.com'
#     username = 'antons'
#     password = 'rejisolomon-2'
#     handles.plweb = ProductLinkWeb()
#     status = handles.plweb.login(url, username, password)
#     logging.info("Initialization of PLWeb is {}".format("Successful!!"))
#     pl_handle = handles
#     return handles


@keyword('PLWEB Login as user with username url and password and asset')
def initialize_plweb(url, username, password, asset_name=None):
    """ Initialization function for PL Web. """
    global pl_handle
    handles = ProductLinkWeb()
    for _ in range(4):
        if not handles.is_element_present(".//*[@ng-href='#/tel_home']"):
            handles.login(url, username, password)
        else:
            break
    handles.driver.execute_script('window.scrollTo(0, 0);')
    time.sleep(1)
    # if asset_name:
    #     handles.global_search(asset_name)
    #BuiltIn().set_suite_variable("${handle}",handles)
    pl_handle = handles
    return handles


@keyword('Close Plweb')
def deIntialize_plweb():
    global pl_handle
    pl_handle.close_plweb_browser()


@keyword('PLWEB Get hourloc for an asset')
def gethourslocinformation(asset):
    getplwebselection='PLWEB'
    """ Method to get the Hours and location information from Product Link Web. """
    global pl_handle
    if getplwebselection=='PLWEB':
        pl_handle.edp.go_to_details_page(asset)
        hours = pl_handle.edp.get_gen_engine_hours()
        gpsstatus = constants.GPSVALID if pl_handle.\
            edp.get_location_status() \
            else constants.GPSINVALID
        if gpsstatus == constants.GPSVALID:
            latitude, longitude = pl_handle.edp.get_gen_location()
            latnum, latdir = latitude.split('\xc2\xb0')
            latitude = float(latnum) * -1 if "S" in latdir else float(latnum)
            lonnum, londir = longitude.split('\xc2\xb0')
            longitude = float(lonnum) * -1 if "W" in londir else float(lonnum)
        else:
            latitude, longitude = [constants.NA] * 2
        print hours, gpsstatus, latitude, longitude
        return hours, gpsstatus, latitude, longitude
    else:
        return constants.NA * 4


@keyword('PLWEB Get asset status')
def getenginestatusinformation(asset):
    global pl_handle
    handles.plweb=pl_handle
    getplwebselection='PLWEB'
    """ Method to get the Engine Status information from Product Link Web. """
    if getplwebselection=='PLWEB':
        handles.plweb.edp.go_to_details_page(asset)
        enginestatus = handles.plweb.edp.get_gen_last_reported_status()
        return enginestatus
    else:
        return constants.NA


@keyword('PLWEB Go to Home Page')
def go_to_Homepage():
    """ Method to initialize the Product Link Web page. """
    global pl_handle
    handles.plweb = pl_handle
    handles.plweb.go_to_home_page()
    print "Initialization of PLWeb is {}".format("Successful!!")

@keyword('PLWEB Go to Groups Page')
def go_to_grouppage():
    """ Method to initialize the Product Link Web page. """
    global pl_handle
    handles.plweb = pl_handle
    handles.plweb.admin.go_to_group_page()
    print "Initialization of PLWeb is {}".format("Successful!!")

@keyword('PLWEB Get group value from Homepage')
def get_gp_fleet_view():
        """"Method to validate the group in Fleet View"""
        global pl_handle
        handles.plweb = pl_handle
        parent = WebInterface()
        print "Home"
        handles.plweb.click('.//select[@ng-model="defaultGroup"]')
        val = handles.plweb.get_value('//*[@ng-model="defaultGroup"]//child::option')
        print val
        return val


@keyword('PLWEB Get date ranges from Homepage')
def get_gp_dateranges():
        """"Method to validate the group in Fleet View"""
        global pl_handle
        handles.plweb = pl_handle
        handles.plweb.click('//*[@class ="leftSummaryTitle"]//*[@ng-model="defaultGroup"]')
        val_list = handles.plweb.get_list_values(".//select[@ng-model='dateFilter']/option")
        return val_list


@keyword('Assertion for as String')
def verify_strings_equal(expected,actual):
        """"Method to verify expected and actual strings"""
        return metafunctions.checkstring("Plweb", "Verifying", expected, actual)

@keyword('Assertion for lists')
def verify_lists_equal(expected, actual):
        """"Method to verify expected and actual strings"""
        #expected = ['Today', 'Yesterday', 'Last 7 Days', 'Last 30 Days']
        if len(expected) == len(actual):
           status = False
           size = len(expected)
           for i in range(0, size):
              status = metafunctions.checkstring("Plweb", "HomePageVerification", expected[i], actual[i])
        else:
            return False
        return status

@keyword('PLWEB Create A Complex Asset')
def create_product_structure():
        """ Method to create a complex asset"""
        global pl_handle
        handles.plweb = pl_handle
        # prod_id and Serial Num is displayed
        prod_id = "paset_" + datetime.now().strftime('%H:%M')
        status = handles.plweb.admin.prodstructpage.generate_product_structure(assets=['AAA', 'IVA'], prod_id = prod_id, serial_num = prod_id)
        return [prod_id, status]


@keyword('PLWEB Go to Product Structures')
def go_to_product_structures():
        """ Method to navigate to product structures page"""
        global pl_handle
        handles.plweb = pl_handle
        handles.plweb.admin.go_to_product_structure_page()


@keyword('Create Admin Groups')
def create_admin_groups(prod_id):
    """ Methods to create a new group in plweb """
    global pl_handle
    handles.plweb = pl_handle
    # prod_id and Serial Num is displayed
    group_name = "saset_" + datetime.now().strftime('%H:%M')
    handles.plweb.admin.groupspage.generate_group_of_assets(group_name, [prod_id, 'AAA'])
    return group_name


@keyword('Verify groups availability')
def verify_groups_availability(groupname, assetname):
    """ methods to confirm the groups level of availability"""
    global pl_handle
    handles.plweb = pl_handle
    status = handles.plweb.admin.groupspage.is_group_present(assetname, groupname)
    if status:
        status = "Available"
    else:
        status = "Not Available"
    return status


@keyword('Verify group is editable')
def verify_group_is_editable(groupname, assetname):
    """ methods to confirm the groups level of availability"""
    global pl_handle
    handles.plweb = pl_handle
    status = handles.plweb.admin.groupspage.edit_gp_button(groupname, assetname)
    if status:
        status = "Editable"
    else:
        status = "Not Editable"
    return status

@keyword('Verify group is deletable')
def verify_group_is_deletable(groupname, assetname):
    """ methods to confirm the groups level of availability"""
    global pl_handle
    handles.plweb = pl_handle
    status = handles.plweb.admin.groupspage.delete_gp_button(groupname, assetname)
    if status:
        status = "Deletable"
    else:
        status = "Not Deletable"
    return status

@keyword('print error messages')
def print_to_console(*args, **kwargs):
    """ printing the error message"""
    logging.info(args, kwargs)


@keyword('Get Screenshot')
def get_screenshot():
    "taking screenshot of the current driver"
    global pl_handle
    handles.plweb = pl_handle
    image = webinterface.get_screen_shot(pl_handle, "C:\Users\antons\
        Desktop\Robot\Robot_proj_solomon\TestResults\image")