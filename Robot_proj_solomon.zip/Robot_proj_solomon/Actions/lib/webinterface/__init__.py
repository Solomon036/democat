"""
Package for acting as a wrapper for Webinterface for Selenium Driver .
"""
# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     webinterface/__init__.py
# **
# ** DESCRIPTION:
# **     Package for acting as a wrapper for Webinterface for Selenium Driver .
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-02-16 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

import logging
import json
import os
import tempfile
import uuid
from time import sleep
from selenium import webdriver
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver import ActionChains, DesiredCapabilities
from .. import catch_except


try:
    from PIL import Image
except ImportError:
    pass


def get_screen_shot(driver, *args):
    """ Method to get the Screen Shot. """
    try:
        driver.get_screenshot_as_file(*args)
        return args
    except Exception as err:
        logging.error(err)
        return False


def get_partial_screen_shot(driver, element, file_name):
    """ Method to get the partial Screen Shot. """
    try:
        loc = element.location
        sizin = element.size
        driver.save_screenshot("temp.png")
        image_ = Image.open("temp.png")
        left = loc['x'] - 50
        top = loc['y'] - 50
        right = loc['x'] + sizin['width'] + 50
        bottom = loc['y'] + sizin['height'] + 50
        image_c = image_.crop((left, top, right, bottom))
        image_c.save(file_name)
    except Exception as err:
        logging.exception(err)
        return False


def get_partial_screen_shot_by_xpath(driver, xpath, file_name, delta_pixel=0):
    """ Method to get the Partial Screen Shot by Xpath. """
    try:
        element = driver.find_element_by_xpath(xpath)
        loc = element.location
        sizin = element.size
        driver.save_screenshot("temp.png")
        image_ = Image.open("temp.png")
        left = loc['x'] - delta_pixel
        top = loc['y'] - delta_pixel
        right = loc['x'] + sizin['width'] + delta_pixel
        bottom = loc['y'] + sizin['height'] + delta_pixel
        image_c = image_.crop((left, top, right, bottom))
        image_c.save(file_name)
    except Exception as err:
        logging.exception(err)
        return False


class WebInterface(object):
    """ Parent Class for WebInterface. """
    def __init__(self, driver_type="Chrome"):
        """ Method to Instance for Webinterface. """
        mainpath = os.path.dirname(os.path.realpath(__file__))
        self.is_performance = False
        self.screenshot = ""
        if driver_type == 'Chrome':
            self._chromeops = webdriver.ChromeOptions()
            prefs = {"download.default_directory": mainpath + r"\bin\download_files",
                     "download.prompt_for_download": False,
                     'credentials_enable_service': False,
                     'profile': {
                         'password_manager_enabled': False
                     },
                     "applicationCacheEnabled": True,
                     "safebrowsing": {"enabled": True, "malware": {"enabled": True}}}
            self._caps = DesiredCapabilities.CHROME
            if self.is_performance:
                self._caps['loggerPrefs'] = {'performance': 'ALL'}
            self._chromeops.add_experimental_option("prefs", prefs)
            self._chromeops.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])
            self._chromeops.add_argument("--start-maximized")
            self._chromeops.add_argument("--disable-plugins")
            self._chromeops.add_argument("--disable-extensions")
            self._chromeops.add_argument("--disable-infobars")
            self._chromedriver = r"{}\bin\chromedriver.exe".format(mainpath)
        self.driver = None
        self.actionChains = None

    def init_driver(self, driver_type="Chrome"):
        """ Initialize the driver for the Webinterface. """
        mainpath = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
        if driver_type == "Chrome":
            self.driver = webdriver.Chrome(executable_path=self._chromedriver,
                                           chrome_options=self._chromeops,
                                           desired_capabilities=self._caps)
        elif driver_type == "IE":
            ie_driver = r"{0}\bin\IEDriverServer.exe".format(mainpath)
            self.driver = webdriver.Ie(executable_path=ie_driver)
        self.driver.implicitly_wait(3)
        self.driver.maximize_window()
        self.actionChains = ActionChains(self.driver)

    @catch_except
    def close(self):
        """ Method to Close the Webinterface. """
        if self.is_performance:
            logs = [json.loads(log['message'])['message'] for log in self.driver.get_log('performance')]
            with open(r'C:\Tools\devtools.json', 'wb') as filepointer:
                json.dump(logs, filepointer, indent=4)
        self.driver.close()
        self.driver.quit()

    @catch_except
    def enter_url(self, url):
        """ Method to Enter the URL. """
        self.driver.get(url)
        return True

    @catch_except
    def get_page_title(self):
        """ Method to get the Title of the Page. """
        return self.driver.title

    @catch_except
    def scroll_to_view_element(self, element):
        """ Method to Scroll to View Element. """
        self.driver.execute_script("return arguments[0].scrollIntoView();", element)
        return True

    @catch_except
    def is_element_present(self, xpath):
        """ Method to verify Is the Element is present. """
        xpath = self.generate_xpath_structure(xpath)
        element_present = self.driver.find_element_by_xpath(xpath)
        self.scroll_to_view_element(element_present)
        sleep(1)
        return element_present.is_enabled()

    @catch_except
    def is_element_visible(self, xpath):
        """ Method to verify is the Element is Visible. """
        xpath = self.generate_xpath_structure(xpath)
        element_present = self.driver.find_element_by_xpath(xpath)
        self.scroll_to_view_element(element_present)
        return element_present.is_displayed()

    @catch_except
    def find_element_by_xpath(self, xpath):
        """ Method to find the Element by Xpath. """
        xpath = self.generate_xpath_structure(xpath)
        if self.is_element_present(xpath):
            return self.driver.find_element_by_xpath(xpath)
        else:
            return False

    @catch_except
    def find_element_by_id(self, attrib_id):
        """ Method to find the Element by ID. """
        elem = self.driver.find_element_by_id(attrib_id)
        self.scroll_to_view_element(elem)
        return elem

    @catch_except
    def switch_to_alert(self):
        alert_info = self.driver.switch_to_alert()
        return alert_info.text

    @catch_except
    def switch_to_window(self):
        self.driver.switch_to.window(self.driver.window_handles[1])
        return True

    @catch_except
    def clear_web_alerts(self):
        """ Method to Clear any unwanted pop-ups."""
        status = True
        try:
            alertinfo = self.driver.switch_to.alert
            logging.info("Pop Up: {}".format(alertinfo.text))
            self.screenshot = get_screen_shot(self.driver, r"{}\{}".format(tempfile.mkdtemp(), uuid.uuid4()))
            alertinfo.accept()
            return self.screenshot
        except Exception as err:
            logging.error(str(err))
        try:
            alertinfo = self.find_element_by_xpath('.//*[@onclick="window.customAlert.ok()"]')
            logging.info("Pop Up: {}".format(alertinfo.text))
            self.screenshot = self.getscreenshot()
            self.click('.//*[@onclick="window.customAlert.ok()"]')
            return self.screenshot
        except Exception as err:
            logging.error(str(err))
        try:
            alertinfo = self.find_element_by_xpath('.//*[@onclick="window.customConfirm.ok()"]')
            logging.info("Pop Up: {}".format(alertinfo.text))
            self.screenshot = get_screen_shot(self.driver, r"{}\{}".format(tempfile.mkdtemp(), uuid.uuid4()))
            self.click('.//*[@onclick="window.customConfirm.ok()"]')
            return self.screenshot
        except Exception as err:
            logging.error(str(err))
        return status

    @catch_except
    def is_displayed(self, xpath):
        """ Method to verify, whether the element is Displayed"""
        xpath = self.generate_xpath_structure(xpath)
        return self.find_element_by_xpath(xpath).is_displayed()

    @catch_except
    def click(self, xpath):
        """ Method to find and click element by Xpath."""
        try:
            xpath = self.generate_xpath_structure(xpath)
            element = self.find_element_by_xpath(xpath)
            self.scroll_to_view_element(element)
            element.click()
        except Exception as err:
            logging.error("Error while Clicking {}".format(xpath))
            logging.error("Error information {}".format(str(err)))
            self.jclick(xpath)
        return True

    @catch_except
    def input(self, xpath, value):
        """ Method to enter the value to the  Webpage. """
        xpath = self.generate_xpath_structure(xpath)
        element = self.find_element_by_xpath(xpath)
        self.scroll_to_view_element(element)
        element.clear()
        sleep(0.5)
        for i in value:
            element.send_keys(i)
            sleep(0.1)

    @catch_except
    def checkboxclick(self, xpath):
        """ Method to click the check box. """
        xpath = self.generate_xpath_structure(xpath)
        element = self.find_element_by_xpath(xpath)
        self.scroll_to_view_element(element)
        element.clear()
        sleep(0.25)
        element.send_keys(Keys.SPACE)

    @catch_except
    def jclick(self, xpath):
        """Method to Click using javascript"""
        checkbox = self.driver.find_element_by_xpath(xpath)
        self.scroll_to_view_element(checkbox)
        return self.driver.execute_script("arguments[0].click();", checkbox)

    @catch_except
    def iselement_enabled(self, xpath):
        """ Method to verify whether the Element is enabled. """
        xpath = self.generate_xpath_structure(xpath)
        element = self.find_element_by_xpath(xpath)
        element.is_enabled()
        return True

    @catch_except
    def click_element(self, element):
        """ Method to Click the Element. """
        self.scroll_to_view_element(element)
        element.click()
        return True

    @catch_except
    def get_value(self, xpath):
        """ Method to get the Value from Xpath. """
        try:
            xpath = self.generate_xpath_structure(xpath)
            element = self.find_element_by_xpath(xpath)
            return element.text
        except Exception as err:
            # logging.error(str(err))
            return "No Data"

    @catch_except
    def get_attribute_inner_text(self, xpath):
        """ Method to get the Value from the attribute. """
        xpath = self.generate_xpath_structure(xpath)
        element = self.find_element_by_xpath(xpath)
        inner_text = self.driver.execute_script("return arguments[0].innerText;", element)
        return inner_text

    @catch_except
    def get_attribute_value(self, xpath, attribute):
        """ Method to get the Value from the attribute. """
        xpath = self.generate_xpath_structure(xpath)
        element = self.find_element_by_xpath(xpath)
        attribute_value = element.get_attribute(attribute)
        return attribute_value

    @catch_except
    def press_esc_button(self, xpath):
        """Method to press ESC button """
        xpath = self.generate_xpath_structure(xpath)
        element = self.find_element_by_xpath(xpath)
        sleep(1)
        element.send_keys(Keys.ESCAPE)

    @catch_except
    def get_value_by_element(self, element):
        """ Method to get the value by Element. """
        return element.text

    @catch_except
    def switch_frame(self, frame):
        """ Method to Switch to Frame. """
        self.driver.switch_to_frame(frame)
        sleep(0.5)

    @catch_except
    def drag_drop(self, source, target):
        """ Method to Drag and Drop the Element. """
        source = self.find_element_by_xpath(source)
        sleep(0.5)
        target = self.find_element_by_xpath(target)
        drag_drop_action = self.actionChains.drag_and_drop(source, target)
        drag_drop_action.perform()
        del self.actionChains
        self.actionChains = ActionChains(self.driver)
        sleep(0.5)

    @catch_except
    def drag_and_drop_by_offset(self, source, x_offset, y_offset):
        """Method to Drag and Drop the Element based on the Offset"""
        source = self.find_element_by_xpath(source)
        sleep(0.5)
        drag_drop_offset = self.actionChains.drag_and_drop_by_offset(source, int(x_offset), int(y_offset))
        drag_drop_offset.perform()
        del self.actionChains
        self.actionChains = ActionChains(self.driver)
        sleep(0.5)

    @catch_except
    def move_to_element_with_offset(self, source=None, x_offset=0, y_offset=0):
        """Method to Move an Element from the current Position to given Co Ordinates"""
        action = self.actionChains.move_to_element_with_offset(to_element=source, xoffset=x_offset, yoffset=y_offset)
        action.click()
        action.perform()
        del self.actionChains
        self.actionChains = ActionChains(self.driver)
        sleep(0.5)

    @catch_except
    def click_and_drag(self, locator, x_offset=0, y_offset=0):
        element = self.find_element_by_xpath(locator)
        sleep(0.5)
        click_drag = self.actionChains.click_and_hold(element).move_by_offset(x_offset, y_offset).release(element)
        click_drag.perform()
        del self.actionChains
        self.actionChains = ActionChains(self.driver)
        sleep(0.5)

    @catch_except
    def double_click(self, xpath):
        """Method to Double Click on an Element"""
        element = self.find_element_by_xpath(str(xpath))
        double_click_element = self.actionChains.double_click(element)
        double_click_element.perform()
        del self.actionChains
        self.actionChains = ActionChains(self.driver)
        sleep(0.5)

    @catch_except
    def right_click(self, xpath):
        """Method to Right Click on an Element"""
        element = self.driver.find_element_by_xpath(str(xpath))
        right_click_element = self.actionChains.move_to_element(element).context_click(element)
        right_click_element.perform()
        del self.actionChains
        self.actionChains = ActionChains(self.driver)
        sleep(0.5)

    @catch_except
    def wait_till_frame_to_switch(self, tag, delay=20):
        """ Method to Wait till frame to Switch. """
        WebDriverWait(self.driver, delay).until(
            expected_conditions.frame_to_be_available_and_switch_to_it((By.TAG_NAME, tag)))

    @catch_except
    def wait_till_delay(self, xpath, delay=20):
        """ Method to Wait for the Xpath element to available for processing. """
        xpath = self.generate_xpath_structure(xpath)
        WebDriverWait(self.driver, delay).until(expected_conditions.visibility_of_element_located((By.XPATH, xpath)))

    @catch_except
    def wait_till_any_element_delay(self, xpath, delay=20):
        """ Method to Wait for the any of the Xpath element to available for processing. """
        xpath = self.generate_xpath_structure(xpath)
        return WebDriverWait(self.driver, delay).until(
            expected_conditions.visibility_of_any_elements_located((By.XPATH, xpath)))

    @catch_except
    def wait_till_inactive_delay(self, xpath, delay=20):
        """ Method to Wait for the Xpath element is Not available for processing. """
        xpath = self.generate_xpath_structure(xpath)
        WebDriverWait(self.driver, delay).until(expected_conditions.invisibility_of_element_located((By.XPATH, xpath)))

    @catch_except
    def wait_till_inactive_any_element_delay(self, xpath, delay=10):
        """ Method to Wait for the any of the Xpath element is Not available for processing. """
        xpath = self.generate_xpath_structure(xpath)
        return WebDriverWait(self.driver, delay).until(
            not expected_conditions.visibility_of_any_elements_located((By.XPATH, xpath)))

    @staticmethod
    @catch_except
    def generate_xpath_structure(xpath):
        """ Simplified Method to Create the Xpath, by attribute and value."""
        if isinstance(xpath, tuple) or isinstance(xpath, list):
            return ".//*[@{}='{}']".format(xpath[0], xpath[1])
        else:
            return xpath

    @catch_except
    def refreshdriver(self):
        """"Page Refresh"""
        self.driver.refresh()

    @catch_except
    def selectvalue(self, xpath, value):
        """ This Method to select the values from the list. """
        select = Select(self.driver.find_element_by_xpath(xpath))
        select.select_by_visible_text(value)
        return True


    @catch_except
    def select_index(self, xpath, value=0):
        """Method to select index """
        select = Select(self.driver.find_element_by_xpath(xpath))
        select.select_by_index(value)

    @catch_except
    def getscreenshot(self):
        """ Method to get the screen shot from the webdriver. """
        filename = r"{}\{}.jpg".format(tempfile.mkdtemp(), uuid.uuid4())
        self.driver.save_screenshot(filename)
        return filename

    @catch_except
    def jscroll_down(self):
        """ This Method to click the element using java script """
        self.driver.execute_script("window.scrollBy(0,100)", "")

    @catch_except
    def find_element_by_xpath_with_parent(self, parent, xpath):
        return parent.find_element_by_xpath(xpath)

    @catch_except
    def get_list_values(self, xpath):
        """ Method to get the Value from Xpath. """
        try:
            xpath = self.generate_xpath_structure(xpath)
            elements = self.driver.find_elements_by_xpath(xpath)
            element_list = list()
            for options in elements:
                element_list.append(str(options.text))
            return element_list
        except Exception as err:
            logging.error(str(err))
            return "No Data"