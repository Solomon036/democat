""" This a Documentation for Product Link Libraries. """
import glob
import logging
from functools import wraps
from os.path import dirname, basename, isfile


def catch_except(func):
    """ Method to handle Catch-Exception of methods. """
    @wraps(func)
    def wrapper(*args, **kwargs):
        """ Its a Wrapper Method. """
        try:
            #logging.info(" {} / {}  {}".format(str(func.__module__), func.__name__, args))
            #print (" {} / {}  {}".format(str(func.__module__), func.__name__, args))
            return func(*args, **kwargs)
        except Exception as err:
            # logging.error(" {} / {}  {}  {}".format(func.__module__,
            #                                         func.__name__, args, str(err)))
            # print(" {} / {}  {}  {}".format(func.__module__,
            #                                 func.__name__, args, str(err)))
            return False
    return wrapper


def timing(function):
    """ Method to calculate the run time of the function. """
    @wraps(function)
    def wrapped(*args, **kwargs):
        """ Its a Wrapper Method. """
        import time
        starttime = time.time()
        value = function(*args, **kwargs)
        timediff = time.time() - starttime
        logging.info('{} has been running for {} seconds.'.format(function.__name__, timediff))
        return value
    return wrapped


MODULES = glob.glob(dirname(__file__)+"/*.py")
__all__ = [basename(f)[:-3] for f in MODULES if isfile(f)]

