"""
Package for data extraction from Product link Web Application.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/__init__.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Product link Web Application.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """
import os
import logging
from time import sleep, clock
from selenium.webdriver.support.ui import Select
from lib.webinterface import WebInterface, catch_except
from lib.plweb.adminpage import adminpage
from lib.plweb.homepage import homepage
from lib.plweb.equipdetailspage import equipdetailspage
from lib.plweb.fleetpage import fleetpage



class ProductLinkWeb(WebInterface):
    """ Parent Class to hold the operation of multiple pages of ProductLink Web. """
    def __init__(self):
        """ Initialize function for the Parent Class. """
        super(ProductLinkWeb, self).__init__()
        self.home = homepage.HomePage(self)
        self.edp = equipdetailspage.EquipmentDetailsPage(self)
        self.admin = adminpage.AdminPage(self)
        self.fleet = fleetpage.FleetPage(self)
        self.get_edp_url = None
        self.get_fleet_url = None
        self.get_admin_url = None
        self.base_url = ''

    @catch_except
    def PLWEB_SN(self, SN):
        return self.home.enter_SN(SN)


    @catch_except
    def login(self, url, user_name, password):
        """ Login Method for PL Web, which intiates the webdriver and enter
        URL, UserName and Password. """
        self.init_driver()
        self.base_url = url
        stop = 0
        start = clock()
        logged_in = False
        login_error = False
        while not logged_in and not login_error:
            self.enter_url(url)
            sleep(2)
            self.wait_till_delay(".//*[@id='cwsUID']")
            self.input(".//*[@id='cwsUID']", user_name)
            self.input(".//*[@id='cwsPwd']", password)
            self.submit()
            self.wait_till_delay('.//*[@class="catlogo"]')
            logged_in = self.is_element_present('.//*[@class="catlogo"]')
            login_error = self.is_element_present('.//*[@id="login_status"]')
            stop = clock()
            if login_error:
                logging.error("Incorrect Username Password Error!! for PL Web.")
                # os._exit(1)
                self.close()
                return False
            if stop - start > 5 * 60:
                self.close()
                return False
        for _ in range(3):
            self.clear_web_alerts()
        self.wait_till_delay(".//*[@class='MapPushpinBase']", 60)
        return True

    @catch_except
    def submit(self):
        """ Method to click submit button in login page. """
        self.click(".//*[@id='submitButton']")
        return True

    @catch_except
    def go_to_home_page(self):
        """ Method to go Home Page. """
        self.click('//*[@id="navlist"]/li[1]/a')
        self.wait_till_delay(".//*[@id='pushpin']")
        print "home page"

    @catch_except
    def logout(self):
        """ Method to logout of PLWeb. """
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handleLogOut()']")
        sleep(1)
        self.close()
    @catch_except
    def close_plweb_browser(self):
        """ To close after Test"""
        self.close()

    def select_global_group(self, code="All equipments"):
        """ Method to select the Home page filter. """
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handlePreferencesClick()']")
        sleep(2)
        self.wait_till_delay(".//*[@id='user_preference_advance']")
        select = Select(self.driver.find_element_by_xpath(".//*[@ng-model='defaultGroup']"))
        if self.find_element_by_xpath(".//*[@ng-model='defaultGroup']"):
            self.click(".//*[@ng-model='defaultGroup']")
            select.select_by_visible_text(code)
            sleep(3)
            self.click(".//*[text()='Save']")
            sleep(2)

    @catch_except
    def select_home_filter(self, criteria='Cat', code=None):
        """ Method to select the Home page filter. """
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handlePreferencesClick()']")
        sleep(2)
        self.wait_till_delay(".//*[@id='user_preference_advance']")
        select = Select(self.driver.find_element_by_xpath(".//*[@ng-model='defaultGroup']"))
        if self.find_element_by_xpath(".//*[@ng-model='defaultGroup']"):
            self.click(".//*[@ng-model='defaultGroup']")
            select.select_by_visible_text(code)
            sleep(3)
            self.click(".//*[text()='Save']")
            sleep(2)

    @catch_except
    def set_preference(self, loc='GPS', time_zone='GMT',
                       hours='24 hour', units='Source Units', group="All equipment"):
        """ Method to set the Preferences in PL Web. Usually called while in Home page."""
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handlePreferencesClick()']")
        sleep(2)
        self.wait_till_delay(".//*[@id='user_preference_general']")
        self.click(".//*[@id='user_preference_general']")
        self.click('.//*[@class="selectDiv"]/select[@ng-model="defaultGroup"]/option[@label="{}"]'.format(group))
        self.click(".//*[@name='locationType'][@value='{}']".format(loc))
        self.click(".//*[@ng-model='timeZoneCode']/option[text()='{}']".format(time_zone))
        self.click(".//*[@name='timeDisplayFormat'][@value='{}']".format(hours))
        self.click(".//*[@ng-model='unitName']/option[text()='{}']".format(units))
        sleep(2)
        self.click(".//*[@ng-click='ok()']")
        sleep(5)
        for _ in range(3):
            self.clear_web_alerts()
            sleep(3)

    @catch_except
    def global_search(self, asset_name):
        """ Method to do the Global Search in PL Web. """
        self.click('//*[@class="search"]')
        sleep(3)
        self.input(".//*[@class='searchSection']/input[@ng-model='searchTerm']", asset_name)
        sleep(3)
        self.click(".//*[@class='searchSection']/button[text()='GO']")
        sleep(10)
        if not "no data" in self.get_value(".//*[@id='unpinnedContainer']/div[3]/div/div"):
            self.wait_till_delay(".//*[text()='{}']".format(asset_name.upper()))
            self.jclick('.//*[@identifier="SerialNumber"]/div/a')
            self.wait_till_delay('.//*[@ng-if="rowData.dateLastReported12Hour"]', 30)
            return True
        else:
            return False

    @catch_except
    def hover_fleet(self):
        """ Method to hover to Fleet Page Selection. """
        self.click('//*[@id="navlist"]/li[2]/a')
        sleep(5)

    @catch_except
    def go_to_fleet_page(self):
        """ Method to go to Fleet Page. """
        self.hover_fleet()
        sleep(3)
        self.jclick('.//*[@ng-href="#/fleetSummary"]')
        self.wait_till_delay('.//*[@id="assetAvatar"]')
        sleep(1)
        self.refreshdriver()
        sleep(5)

    @catch_except
    def go_to_fleet_alert(self):
        """ Method to go to Fleet Alert Page. """
        self.hover_fleet()
        self.click('.//*[@ng-href="#/fleetAlert"]')
        self.wait_till_delay('.//*[@id="assetAvatar"]')
        sleep(1)

    @catch_except
    def go_to_fleet_fault_code_page(self):
        """ Method to go to Fleet Fault Code Page. """
        self.hover_fleet()
        self.click('.//*[@ng-href="#/faultCode/null/null"]')
        self.wait_till_delay('.//*[@id="assetAvatar"]')
        sleep(1)

    @catch_except
    def go_to_fleet_utilization_page(self):
        """ Method to go to Fleet Utilization Page. """
        self.hover_fleet()
        self.click('.//*[@ng-href="#/fleetUtilization"]')
        self.wait_till_delay('.//*[@id="assetAvatar"]')
        sleep(1)

    @catch_except
    def go_to_fleet_operation_history_page(self):
        """ Method to go to Fleet Operation History Page. """
        self.hover_fleet()
        self.click('.//*[@ng-href="#/OperationHistory"]')
        self.wait_till_delay('.//*[@id="assetAvatar"]')
        sleep(1)

    @catch_except
    def go_to_maintenance_page(self):
        """ Method to go to Maintenance Page. """
        self.hover_fleet()
        self.click('.//*[@ng-href="#/Maintenance"]')

    @catch_except
    def go_to_fleet_data_viz_page(self):
        """ Method to go to Data Vizualization Page. """
        self.hover_fleet()
        self.click('.//*[@ng-href="#/datavizualization"]')
        self.wait_till_delay('.//*[@class="datavizualization ng-scope"]')
        self.switch_frame(self.driver.find_element_by_tag_name("iframe"))
        self.wait_till_inactive_delay(".//*[@id='loadingIcon']", 60)
        self.click('.//*[@id="breadcrumbs"]')
        sleep(2)

    @catch_except
    def go_to_kpi(self):
        """ Method to go to KPI Page. """
        self.hover_fleet()
        sleep(1.5)
        self.click('.//*[@ng-href="#/kpi"]')
        self.wait_till_delay('.//*[@class="kpi ng-scope"]')
        self.switch_frame(self.driver.find_element_by_tag_name("iframe"))
        self.wait_till_inactive_delay(".//*[@id='loadingIcon']", 60)
        self.click('.//*[@id="breadcrumbs"]')
        sleep(2)

    @catch_except
    def go_to_my_dash_board(self):
        """ Method to go to My Dashboard Page. """
        self.click('.//*[@ng-href="#/MyDashboard"]')
        sleep(2)
        self.wait_till_inactive_delay(".//*[@id='loadingIcon']", 60)
        self.wait_till_delay('.//*[@ng-click="layoutservice.switchDashboardTab(item)"]')

    @catch_except
    def select_user_preference(self):
        """Method to select User preference"""
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handlePreferencesClick()']")
        sleep(2)
        self.wait_till_delay(".//*[@id='user_preference_general']")

    @catch_except
    def validate_group_user_pref(self, gp_name):
        """Method to validate the group in user Preference"""
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handlePreferencesClick()']")
        sleep(2)
        self.wait_till_delay(".//*[@id='user_preference_general']")
        self.click('//*[@id="preferencesLink"]//*[@ng-model="defaultGroup"]')
        val = self.get_value('//*[@id="preferencesLink"]//*[@ng-model="defaultGroup"]')
        if gp_name in val:
            return True

    @catch_except
    def select_group_user_pref(self, gp_name):
        """Method to select the group in User Preference"""
        self.click('.//*[@class="accountImg"]')
        sleep(1)
        self.click(".//*[@ng-click='handlePreferencesClick()']")
        sleep(2)
        self.wait_till_delay(".//*[@id='user_preference_general']")
        self.click('//*[@id="preferencesLink"]//*[@ng-model="defaultGroup"]')
        if self.selectvalue('//*[@id="preferencesLink"]//*[@ng-model="defaultGroup"]', gp_name):
            return True

    @catch_except
    def set_preference_cancel(self):
        """"Method to Click on Cancel button in User Preference"""
        self.click('//*[@ng-click="cancel()"]')
        sleep(2)

    @catch_except
    def set_preference_save(self):
        """"Method to Click on Save Button in User preference"""
        self.click('//*[@ng-click="ok()"]')
        sleep(10)

    @catch_except
    def maximize_filter(self):
        """"Method to maximize the Filters"""
        self.click('//*[@class="plusIcon"]')

    @catch_except
    def minimize_filter(self):
        """Method to maximize the Filters"""
        self.click('.//*[@id="panelMinimize"]')

    @catch_except
    def select_group_fleet_filter(self, arg):
        """Method to maximize group filter in fleet filters"""
        self.find_element_by_xpath("//*[contains(text(), '%s')]" % arg)
        self.click('//*[@class="accordion-toggle"]//*[contains(text(), "Saved Group")]')
        sleep(2)

    @catch_except
    def validate_gp_filter(self, arg):
        """"Method to validate the presence of group in Filters"""
        self.maximize_filter()
        self.select_group_fleet_filter("Saved Group")
        self.getscreenshot()
        for element in self.driver.find_elements_by_xpath(
                        "//*[@class='accordionInnerSection ng-scope']//*[contains(text(), '%s')]" % arg):
            if arg in element.text:
                return True
        return False

    @catch_except
    def clear_all_filters(self):
        """"Method to Clear All the Filters in Fleet and Admin Filters"""
        self.maximize_filter()
        self.click('//*[@class="filterClearAll"]')

    @catch_except
    def get_fleet_header_data(self):
        """Method to Get all the Fleet Header Titles"""
        list_headers = []
        for item in range(1, 5):
            data = self.find_element_by_xpath(".//*[@class='grid-row clear-fix']/div[{}]/span".format(item))
            list_headers.append(data.text)
        return list_headers

    @catch_except
    def get_all_applied_filters(self):
        """Method to Get all the Applied Filters"""
        applied_filters_list = []
        for filters in range(1, 7):
            data = self.find_element_by_xpath("(.//*[@class='panel-title']/a/div)[{}]".format(filters))
            applied_filters_list.append(data.text)
        return applied_filters_list

    @catch_except
    def click_parts_link(self):
        """Method to Click on the Parts.Cat.Com"""
        self.click(".//*[@href='http://parts.cat.com/']")
        sleep(1)

    @catch_except
    def click_locate_link(self):
        """Method to Click on the Locate Link"""
        self.click(".//*[@href='http://www.cat.com/en_US/support/dealer-locator.html']")
        sleep(1)

    @catch_except
    def select_date_value_homepage(self):
        """Method to Select all the date from the Drop Down of Home Page"""
        date_list = []
        for date in range(1,5):
            data = self.find_element_by_xpath(".//*[@id='dateFilter']/option[{}]".format(date))
            date_list.append(data.text)
        return date_list

    @catch_except
    def select_help_link(self):
        """Method to select the Help Link"""
        self.click(".//*[@href='/assets/help/index.htm']")
        self.switch_to_window()
        sleep(0.5)


@catch_except
def initialize_plweb(url, username, password, asset_name=None):
    """ Initialization function for PL Web. """
    handles = ProductLinkWeb()
    for _ in range(4):
        if not handles.is_element_present(".//*[@ng-href='#/tel_home']"):
            handles.login(url, username, password)
        else:
            break
    handles.driver.execute_script('window.scrollTo(0, 0);')
    sleep(1)
    if asset_name:
        handles.global_search(asset_name)
    return handles


# @keyword('Close Plweb')
# def deIntialize_plweb(handle):
#
#     handle.close_plweb_browser()

