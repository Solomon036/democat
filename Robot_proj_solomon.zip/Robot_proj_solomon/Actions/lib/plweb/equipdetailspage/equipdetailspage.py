"""
Module for performing operations and data extraction on Equipment Details Page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/equipdetailspage/equipdetailspage.py
# **
# ** DESCRIPTION:
# **     Module for performing operations and data extraction on Equipment Details Page.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from datetime import datetime
from dateutil.parser import parse
from lib.webinterface import catch_except


class EquipmentDetailsPage(object):
    """ Parent Class for Equipment Details Page. """
    def __init__(self, parent):
        """ Method to initialize the instance of the Equipment Details Page. """
        self.current_asset_name = ''
        self.parent = parent

    @catch_except
    def go_to_details_page(self, asset_name):
        """ Method to go to Equipment Details Page. """
        status = True
        if self.parent.get_edp_url and self.current_asset_name == asset_name:
            self.parent.enter_url(self.parent.get_edp_url)
        else:
            status = self.parent.global_search(asset_name)
            self.current_asset_name = asset_name
            self.parent.get_edp_url = self.parent.driver.current_url
        sleep(5)
        return status

    @catch_except
    def get_gen_date_last_reported(self):
        """ Method to get the Date Last Reported. """
        last_reported_time = self.parent.get_value(".//*[@ng-if='rowData.dateLastReported12Hour']")
        if last_reported_time:
            # #last_reported_time = \
            #     datetime.strptime(last_reported_time,
            #                       "%Y-%m-%d %H:%M:%S").strftime("%d/%m/%Y %H:%M:%S")
                last_reported_time = parse(last_reported_time).strftime("%d/%m/%Y %H:%M:%S")
        return last_reported_time

    @catch_except
    def set_gen_asset_refresh(self):
        """ Method to perform Refresh the Page. """
        self.parent.click(".//*[@ng-click='datePolling()']")
        sleep(5)
        self.parent.clear_web_alerts()
        sleep(5)
        return True

    @catch_except
    def get_gen_asset_type(self):
        """ Method to get the Asset Type. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[2]/div[1]/div[2]/b')\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_equipment_id(self):
        """ Method to get the Equipment ID. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[2]/div[2]/div[2]/b')\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_serial_num(self):
        """ Method to get the Serial Number. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[2]/div[3]/div[2]/b')\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_make(self):
        """ Method to get the Make information. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[2]/div[4]/div[2]/b')\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_model(self):
        """ Method to get the Model infromation. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[2]/div[5]/div[2]/b')\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_last_reported_status(self):
        """ Method to get the Last Reported Status. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[3]/div[1]/div[2]/span')\
            .replace(":\n", '')

    @catch_except
    def get_gen_last_reported_colour_status(self):
        """ Method to get the Last Reported colour status from Equipment Details Page. """
        element = self.parent.find_element_by_xpath('.//*[@class="justdot"]')
        if element:
            attribval = element.get_attribute("style")
            return attribval.split(" ")[-1].strip(";")
        else:
            return "No Data"

    @catch_except
    def get_gen_last_reported_comm_mode(self):
        """ Method to get the Last Reported Communication Mode. """
        return self.parent.get_value(".//*[@ng-if='commMode']")

    @catch_except
    def get_gen_engine_hours(self):
        """ Method to get the Engine Hours. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[3]/div[3]/div[2]/b')\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_battery_voltage(self):
        """ Method to get the Battery Voltage. """
        return self.parent.get_value('//*[@id="assetImageCont"]/table/tbody/tr/td[3]/div[4]/div[2]/b')\
            .replace(":", '').lower().replace(" volts", '').lstrip()

    @catch_except
    def get_gen_average_power_factor(self):
        """ Method to get the Average Power Factor. """
        return self.parent.get_value(".//*[contains(@class,'powerMeterStyle')]/div[contains(@class,"
                                     "'powerMeterName')]").replace(":", '').lstrip()

    @catch_except
    def get_gen_kwh(self):
        """ Method to get the KWH value. """
        return self.parent.get_value(".//*[contains(@class,'kwhStyle')]/div[contains(@class,"
                                     "'kwhName')]").replace(":", '').lstrip()

    @catch_except
    def get_gen_kvarh(self):
        """ Method to get the KVARH value. """
        return self.parent.get_value(".//*[contains(@class,'kwarhhStyle')]"
                                     "/div[contains(@class,'kwarhName')]")\
            .replace(":", '').lstrip()

    @catch_except
    def get_gen_fuel_level(self):
        """ Method to get the Fuel Level value. """
        values = self.parent.get_value('//*[@id="assetFuel"]/div[4]')
        return values.replace("%", "")

    @catch_except
    def get_gen_location(self):
        """ Method to Get the Location information. """
        if not self.parent.is_displayed(".//*[@id='currentLocationDiv']"):
            self.parent.click('.//*[@ng-disabled="!isMapLoaded"]')
            sleep(1)
        loc_text = self.parent.get_value(".//*[@id='currentLocationDiv']")\
            .encode('utf-8')
        if not self.get_location_status():
            loc_text.replace('Location set manually', '')
        return loc_text.splitlines()[0].split('/')

    @catch_except
    def get_location_status(self):
        """ Method to Get the Location status. """
        if not self.parent.is_displayed(".//*[@id='currentLocationDiv']"):
            self.parent.click('.//*[@ng-disabled="!isMapLoaded"]')
            sleep(1)
        status_text = self.parent.get_value(".//*[@id='edpSetLocHrefDiv']")
        if not status_text:
            return True
        if 'Set Location' in status_text or 'Edit Location' in status_text:
            return False
        else:
            return True

    @catch_except
    def set_gen_location(self, location):
        """ Method to Set the Location information. """
        if not self.parent.is_displayed(".//*[@id='currentLocationDiv']"):
            self.parent.click('.//*[@ng-disabled="!isMapLoaded"]')
            sleep(1)
        self.parent.click(".//*[@id='edpSetLocHrefDiv']")
        sleep(2)
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(1)
        self.parent.input(".//*[@id='findSetLocationInput']", location)
        self.parent.click(".//*[@id='findSetAddress']")
        sleep(1)
        self.parent.click(".//*[@id='setButton']")
        sleep(1)
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(5)
        return True

    @catch_except
    def get_asset_info(self):
        """ Method to get the Asset Info from Equipment Details Page."""
        class AssetInfo(object):
            """ Class to hold the asset information. """
            def __init__(self):
                self.device_type = None
                self.part_no = None
                self.serial_number = None
                self.firmware_part_no = None
                self.base_config_part_no = None
                self.customer_config_date = None
                self.customer_config_desc = None
                self.engineering_config_date = None
                self.engineering_config_desc = None

        self.parent.click(".//*[text()='Device Info']")
        sleep(3)
        self.parent.click(".//*[text()='Device Information']")
        sleep(5)
        self.parent.wait_till_delay(".//*[@id='deviceInfoCont']")
        data = list()
        asset_data_ele = self.parent.find_element_by_xpath(".//*[@id='deviceInfoCont']")
        row_elements = asset_data_ele.\
            find_elements_by_xpath(".//*[contains(@class,'deviceDataCls')]")
        for element in row_elements:
            data.append(element.find_elements_by_tag_name("div")[1].text)
        asset_data = AssetInfo()
        if data:
            asset_data.device_type = data[0]
            asset_data.part_no = data[1]
            asset_data.serial_number = data[2]
            asset_data.firmware_part_no = data[3]
            asset_data.base_config_part_no = data[4]
            asset_data.customer_config_date = data[5]
            asset_data.customer_config_desc = data[6]
            asset_data.engineering_config_date = data[7]
            asset_data.engineering_config_desc = data[8]
        self.parent.click(".//*[text()='Device Information']")
        return asset_data

    @catch_except
    def get_radio_info(self):
        """ Method to get the Radio Information of Equipment Detail Page. """
        class RadioInfo(object):
            """ Class to hold the Radio Information. """
            def __init__(self):
                self.communication_method = None
                self.hardware_part_no = None
                self.radio_serial_number = None
                self.software_part_no = None
                self.meid = None
                self.imei = None
                self.sim_card_id = None
                self.device_type = None
        self.parent.click(".//*[text()='Radio Information']")
        sleep(2)
        self.parent.wait_till_delay(".//*[@id='radioInfoCont']")
        radio_data_ele = self.parent.\
            find_element_by_xpath(".//*[@id='radioInfoCont']")
        row_elements = radio_data_ele.\
            find_elements_by_xpath(".//*[contains(@class,'radioDataCls')]")
        data = list()

        for element in row_elements:
            data.append(element.find_elements_by_tag_name("div")[1].text)
        radio_data = RadioInfo()
        if data:
            radio_data.communication_method = data[0]
            radio_data.hardware_part_no = data[1]
            radio_data.radio_serial_number = data[2]
            radio_data.software_part_no = data[3]
            radio_data.meid = data[4]
            radio_data.imei = data[5]
            radio_data.sim_card_id = data[6]
        self.parent.click(".//*[text()='Radio Information']")
        return radio_data

    @catch_except
    def get_ecm_info(self):
        """ Method to get the ECM Info. """
        class ECMInfo(object):
            """ Class to hold the ECM Info Information. """
            def __init__(self):
                self.name = None
                self.description = None
                self.ecm_serial_number = None
                self.firmware_pn = None
                self.hardware_pn = None
                self.sync_clock_enabled = None
                self.sync_clock_level = None

        self.parent.click(".//*[text()='ECM Information']")
        self.parent.wait_till_inactive_delay(".//*[@id='loadingIcon']")
        sleep(3)
        ecm_data = list()
        self.parent.wait_till_delay(".//*[@data='data']")
        row_elements = self.parent.driver.find_elements_by_xpath(".//*[@data='data']")
        for element in row_elements:
            ecm_info_ = ECMInfo()
            data_info = element.find_elements_by_xpath(".//*[@ng-repeat='val in gridData']")
            info = [z.text for z in data_info]
            ecm_info_.name = info[0]
            ecm_info_.description = info[1]
            ecm_info_.ecm_serial_number = info[2]
            ecm_info_.firmware_pn = info[3]
            ecm_info_.hardware_pn = info[4]
            ecm_info_.sync_clock_enabled = info[5]
            ecm_info_.sync_clock_level = info[6]
            ecm_data.append(ecm_info_)
        return ecm_data

    @catch_except
    def go_to_device_info_tab(self):
        self.parent.driver.execute_script('window.scrollTo(0, 50);')
        sleep(2)
        self.parent.click(".//*[text()='Device Info']")
        sleep(3)

    @catch_except
    def get_device_info(self):
        """ Method to get the Device Info. """
        self.parent.driver.execute_script('window.scrollTo(0, 50);')
        sleep(2)
        asset_data = self.get_asset_info()
        sleep(1)
        radio_data = self.get_radio_info()
        sleep(1)
        ecm_data = self.get_ecm_info()
        sleep(1)
        return asset_data, radio_data, ecm_data

    @catch_except
    def configure_and_add_all(self):
        """ Method to do configure and add-all in Equipment Details Page. """
        self.parent.click(".//*[@class='glyphicon glyphicon-cog pull-right']")
        sleep(2)
        elements = self.parent.driver.find_elements_by_xpath(".//*[@title='Add']")
        for ele in elements:
            ele.click()
            sleep(0.5)
        sleep(1)
        self.parent.click(".//*[@ng-click='saveVisibleTabsFn()']")
        sleep(2)
        return True

    @catch_except
    def select_alerts_tab(self):
        """ Method to Select the Alerts tab. """
        self.parent.click(".//*[@class='icon-placeholder alertsIconCls']")
        sleep(1)
        return True

    @catch_except
    def select_control_asset_tab(self):
        """ Method to Select the Control the Asset Tab. """
        self.parent.click(".//*[text()='Control Asset']")
        sleep(1)
        return True

    @catch_except
    def select_dash_board_tab(self):
        """ Method to Select the Dashboard Tab. """
        self.parent.click(".//*[text()='Dashboard']")
        sleep(1)
        return True

    @catch_except
    def select_device_info_section(self):
        """ Method to Select the Device Info Tab. """
        self.parent.click(".//*[@class='icon-placeholder deviceInfoIconCls']")
        sleep(1)
        return True

    @catch_except
    def select_fault_code_section(self):
        """ Method to Select the Fault Code Section. """
        self.parent.click(".//*[@class='icon-placeholder faultCodeIconCls']")
        sleep(1)
        return True

    @catch_except
    def select_fuel_section(self):
        """ Method to Select the Fuel Section. """
        self.parent.click(".//*[@class='icon-placeholder fuelIconCls']")
        sleep(3)
        return True

    @catch_except
    def select_power_section(self):
        """ Method to Select the Power Section. """
        self.parent.click(".//*[@class='icon-placeholder powerIconCls']")
        sleep(1)
        return True

    @catch_except
    def traverse_edp_child_tab(self, direction):
        """ Method to Traverse the EDP Child. """
        self.parent.click(".//*[@class='glyphicon glyphicon-chevron-{}']".format(direction.lower()))
        sleep(1)
        return True

    @catch_except
    def select_status_parameter_tab(self):
        """ Method to Select the Status Parameter Tab. """
        self.parent.click(".//*[@class='icon-placeholder statusParamIconCls']")
        sleep(1)
        return True

    @catch_except
    def select_tracking_points_tab(self):
        """ Method to Select the Tracking Points Tab. """
        self.parent.click(".//*[@class='icon-placeholder trackPointIconCls']")
        sleep(1)
        return True

    @catch_except
    def select_sos_section(self):
        """ Method to Select the SOS Section. """
        self.parent.click(".//*[@class='icon-placeholder sosIconCls']")
        sleep(1)
        return True

    @catch_except
    def parse_alerts_tab(self):
        """ Method to parse the Alerts tab. """
        class AlertInfo(object):
            """ Class to hold the Alert Info of each alert. """
            name = None
            type = None
            description = None
            time_occured = None
            location = None
        alert_data = list()
        element = self.parent.find_element_by_xpath(".//*[@class='grid-content clearfix']")
        list_of_rows = element.find_elements_by_xpath(".//*[@data='data']")
        for row_content in list_of_rows:
            alert = AlertInfo()
            alert.name = row_content.find_element_by_xpath(".//*[@identifier='alertName']").text
            alert.type = row_content.find_element_by_xpath(".//*[@identifier='alertType']").text
            alert.description = row_content.\
                find_element_by_xpath(".//*[@identifier='alertDescription']").text
            alert.time_occured = row_content.\
                find_element_by_xpath(".//*[@identifier='alertTimeStamp24Hour']").text
            alert.location = row_content.\
                find_element_by_xpath(".//*[@identifier='latitude']").text
            alert_data.append(alert)
        return alert_data

    @catch_except
    def select_fault_tab(self):
        """ Method to Select the Fault Tab. """
        self.parent.click(".//*[text()='Fault Codes']")
        sleep(1)
        return True

    @catch_except
    def parse_fault_tab(self):
        """ Method to get the values of the Fault Tab."""
        class FaultCode(object):
            """ Class to hold the Fault Code information. """
            def __init__(self):
                self.severity = None
                self.code = None
                self.description = None
                self.source = None
                self.time_stamp = None
                self.location = None
                self.hours = None
                self.snapshots = None
        data = list()
        for row_content in self.parent.driver.find_elements_by_xpath('.//*[@data="data"]'):
            self.parent.click_element(row_content)
            fault_info = FaultCode()
            fault_info.severity = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="severity"]'))
            fault_info.code = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="code"]'))
            fault_info.description = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="description"]'))
            fault_info.source = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="source"]'))
            fault_info.time_stamp = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="timeStamp"]'))
            fault_info.location = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier='
                                                  '"gpsDirection"]')).encode('utf-8')
            fault_info.hours = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="hourMeter"]'))
            fault_info.snapshots = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="snapshot"]'))
            data.append(fault_info)
            sleep(1)
        return data

    @catch_except
    def select_fuel_tab(self):
        """ Method to go Select the Fuel Tab. """
        self.parent.click(".//*[text()='Fuel']")
        sleep(1)
        return True

    @catch_except
    def parse_fuel_tab(self):
        """ Method to get the Parse the Fuel information from the Fuel Tab. """
        class FuelInfo(object):
            """ Class to hold the Fuel Info. """
            def __init__(self):
                self.reported_date = None
                self.working_hours = None
                self.working_fuel = None
                self.idle_hours = None
                self.idle_fuel_burned = None
                self.dgb = None
                self.total_hours = None
                self.total_fuel_burned = None
        self.select_fuel_section()
        fuel_data = list()
        try:
            element = self.parent.find_element_by_xpath(".//*[@class='grid-content clearfix']")
            list_of_rows = element.find_elements_by_xpath(".//*[@data='data']")
            for row_content in list_of_rows:
                fuel = FuelInfo()
                fuel.reported_date = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='reportingDate']"))
                fuel.working_hours = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='totalWorkingHours']"))
                fuel.working_fuel = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='totalWorkingFuelUsed']"))
                fuel.idle_hours = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='totalIdleHours']"))
                fuel.idle_fuel_burned = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='totalIdleFuelUsed']"))
                fuel.dgb = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='dieselGasBlend']"))
                fuel.total_hours = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='reportedHours']"))
                fuel.total_fuel_burned = self.parent.get_value_by_element(
                    row_content.find_element_by_xpath(".//*[@identifier='totalFuelUsed']"))
                fuel_data.append(fuel)
        except:
            pass
            fuel_data = ["There is no data to display"]
        return fuel_data

    @catch_except
    def parse_power_tab(self):
        """ Method to get the values of the Fault Tab."""

        class Power(object):
            """ Class to hold the Power information. """

            def __init__(self):
                self.ReportedDate = None
                self.kilowatthour = None
                self.kvperArh = None
                self.AverageKW = None
                self.reportedHours = None


        data = list()
        for row_content in self.parent.driver.find_elements_by_xpath('.//*[@data="data"]'):
            self.parent.click_element(row_content)
            power_info = Power()
            power_info.reportingDate = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="reportingDate"]'))
            power_info.kilowatthour = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="kilowatthour"]'))
            power_info.kvperArh = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="kvperArh"]'))
            power_info.averagekW = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="averagekW"]'))
            power_info.reportedHours = self.parent.get_value_by_element(
                row_content.find_element_by_xpath('.//*[@identifier="reportedHours"]'))
            data.append(power_info)
            sleep(1)
        return data

    @catch_except
    def go_to_status_parameter_tab(self):
        """ Method to go to a Status Parameter. """
        self.parent.click(".//*[text()='Status Parameters']")
        sleep(2)
        self.parent.\
            wait_till_inactive_delay(".//*[@ng-if='showLoadingIconEDP']", 60)
        return True

    @catch_except
    def is_status_chart_loaded(self):
        """ Method to verify whether the Status Parameter Chart is loaded. """
        self.parent.driver.switch_to_frame(
            self.parent.driver.find_element_by_tag_name("iframe"))
        self.parent.wait_till_delay('.//*[@class="chart-container"]', 60)
        status = self.parent.is_displayed('.//*[@class="chart-container"]')
        self.parent.driver.switch_to_default_content()
        return status

    @catch_except
    def generate_report_chart(self):
        """ Method to Generate the Report chart in Status Parameter Chart. """
        self.parent.click('.//*[@id="buttonMultipleSelect"]')
        sleep(2)
        if self.parent.wait_till_inactive_delay(".//*[@class='loadingIcon']", 60):
            sleep(3)
            return self.is_status_chart_loaded()
        else:
            return False

    @catch_except
    def set_date_range(self, date_type="thirtyDays(hidePopover)"):
        """ Method to Set the Date Range. By Default, Thirty Days is set."""
        self.parent.click('.//*[@class="arrowDownDp"]')
        sleep(2)
        self.parent.click('.//*[@ng-click="{}"]'.format(date_type))
        sleep(2)


    @catch_except
    def get_trackingpoints_indicator(self):
        """Method to get the Indicator message in the Tracking Points Tab"""
        return self.parent.get_value('.//*[@class="infoDisplayCls ng-scope"]/span[2]')
