"""
Module for performing operations and data extraction on Fleet Page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/utilization.py
# **
# ** DESCRIPTION:
# **     Module for performing operations and data extraction on Fleet Utilization Page.
# **
# ** AUTHOR:
# **    Deepiga Ravi(ravid1)
# ** HISTORY:
# ** Change 00  2017-05-15 (ravid1)
# **     Created the Initial Version of the file for structure.
# **
# *******************************************************************************
# """

from time import sleep
from selenium.webdriver.common.by import By
from supportfiles.common import handles
from lib.webinterface import catch_except
from lib.plweb.fleetpage.dataviz import DataVisualization
from lib.plweb.fleetpage.kpi import KeyPerformanceIndicator


class UtilizationPage(object):
    """ Parent Class for Fleet Utilization Page. """
    def __init__(self, parent, fleet):
        """ Method to initialize the handles for Fleet Utilization Page. """
        self.parent = parent
        self.viz = DataVisualization(self.parent, self)
        self.kpi = KeyPerformanceIndicator(self.parent, self)
        self.fleet = fleet
        self.parent_window = None

    @catch_except
    def go_to_data_viz(self):
        """ Method to Go to Data Vizualization Page."""
        self.parent_window = self.parent.driver.current_window_handle
        self.parent.click('//*[@id="navlist"]/li[2]/a')
        sleep(1.5)
        self.parent.click('.//*[@ng-href="#/datavizualization"]')
        self.parent.wait_till_delay('.//*[@class="datavizualization ng-scope"]')
        self.parent.switch_frame(self.parent.driver.find_element_by_tag_name("iframe"))
        self.parent.wait_till_inactive_delay(".//*[@id='loadingIcon']", 60)
        self.parent.click('.//*[@id="breadcrumbs"]')
        # sleep(30)

    @catch_except
    def get_showtotals_data(self):
        """ Method used to get the value from Show Totals pop up"""
        showtotal_data = {}
        self.parent.click(".//*[@value='Show Totals']")
        sleep(5)
        fuelheaders = self.parent.driver.find_elements(By.XPATH, "(.//*[@id='utilization-totals']//child::th)")
        print len(fuelheaders)
        values = self.parent.driver.find_elements(By.XPATH,"(.//*[@id='utilization-totals']//child::td//child::span)")
        for i in range(0, len(fuelheaders)):
            showtotal_data[fuelheaders[i].text] = values[i].text
        self.parent.click(".//*[@class='closeButton']")
        return showtotal_data

    @catch_except
    def get_utilization_data(self):
        """Method to get Utilization Data"""
        util_data = {}
        fuelburned = self.parent.driver.find_elements(By.XPATH,".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='totalFuelUsed']//div[contains(@class,'ng-binding')]")
        idlefuelburned = self.parent.driver.find_elements(By.XPATH, ".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='totalIdleFuelUsed']//div[contains(@class,'ng-binding')]")
        workingfuelburned = self.parent.driver.find_elements(By.XPATH, ".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='totalWorkingFuelUsed']//div[contains(@class,'ng-binding')]")
        diesel = self.parent.driver.find_elements(By.XPATH, ".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='totalDieselFuel']//div[contains(@class,'ng-binding')]")
        displacedfuel = self.parent.driver.find_elements(By.XPATH, ".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='totalGasFuel']//div[contains(@class,'ng-binding')]")
        kwh = self.parent.driver.find_elements(By.XPATH, ".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='kilowatthour']//div[contains(@class,'ng-binding')]")
        kvarh = self.parent.driver.find_elements(By.XPATH, ".//*[@class='grid-row makeSelectionCls connectorExtension']/child::*[@identifier='kvperArh']//div[contains(@class,'ng-binding')]")
        totalfuel = 0
        totalidlefuel = 0
        totalworkingfuel = 0
        totaldiesel = 0
        totaldisplaced = 0
        totalkwh = 0
        totalkvarh = 0

        for index in range(0, len(fuelburned)):
            fuel_value = fuelburned[index].text
            idlefuel_value = idlefuelburned[index].text
            workingfuel_value = workingfuelburned[index].text
            diesel_value = diesel[index].text
            displacedfuel__value = displacedfuel[index].text
            kwh_value = kwh[index].text
            kvarh_value = kvarh[index].text
            if "-" not in fuel_value or " " not in fuel_value or (
                    "No Report for the Selected Date Range ") not in fuel_value:
                totalfuel = totalfuel + float(fuel_value)
            if "-" not in idlefuel_value and " " not in idlefuel_value and (
                    "No Report for the Selected Date Range ") not in idlefuel_value:
                totalidlefuel = totalidlefuel + float(idlefuel_value)
            if "-" not in workingfuel_value and " " not in workingfuel_value and (
                    "No Report for the Selected Date Range ") not in workingfuel_value:
                totalworkingfuel = totalworkingfuel + float(workingfuel_value)
            if "-" not in diesel_value and " " not in diesel_value and (
                    "No Report for the Selected Date Range ") not in diesel_value:
                totaldiesel = totaldiesel + float(diesel_value)
            if "-" not in displacedfuel__value and " " not in displacedfuel__value and (
                    "No Report for the Selected Date Range ") not in displacedfuel__value:
                totaldisplaced = totaldisplaced + float(displacedfuel__value)
            if "-" not in kwh_value and " " not in kwh_value and (
                    "No Report for the Selected Date Range ") not in kwh_value:
                totalkwh = totalkwh + float(kwh_value)
            if "-" not in kvarh_value and " " not in kvarh_value and (
                    "No Report for the Selected Date Range ") not in kvarh_value:
                totalkvarh = totalkvarh + float(kvarh_value)
            element = self.parent.driver.find_element_by_xpath \
                (".//*[@identifier='totalFuelUsed']//parent::"
                 "div[contains(@class,'connector')]")
            sno = element.get_attribute("id")

            util_data["Fuel Burned"] = totalfuel
            util_data["Idle Fuel Burned"] = totalidlefuel
            util_data["Working Fuel Burned"] = totalworkingfuel
            util_data["Diesel"] = totaldiesel
            util_data["Displaced Fuel"] = totaldisplaced
            util_data["kWh"] = totalkwh
            util_data["kVArh"] = totalkvarh
            return util_data

    @catch_except
    def utilization_defaultcheck(self):

        checkboxlist = handles.plweb.driver.find_elements(By.XPATH,
                                                          "(.//div[contains(@class,'selectColumns')]//input[@type='checkbox'])")

        # Verifying the default checkboxes values
        workingidle = handles.plweb.is_element_present(
            ".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'Working/Idle')]")
        dgb = handles.plweb.is_element_present(
            ".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'DGB')]")
        electricpower = handles.plweb.is_element_present(
            ".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'Electric Power')]")

        if workingidle is True:
            workingidle = "Displayed"
        else:
            workingidle = "Not Displayed"

        if dgb is True:
            dgb = "Displayed"
        else:
            dgb = "Not Displayed"

        if electricpower is True:
            electricpower = "Displayed"
        else:
            electricpower = "Not Displayed"

        return{"workingidle": workingidle,"dgb": dgb, "electricpower": electricpower}



    @catch_except
    def utiltable_checkbox(self, usertype, uworking_idle, udgb,uelectricpower):
        """ Checking the Checkboxes functionlaity in Fleet >> Utilization"""

        # Verifying the default checkboxes values
        workingidle = handles.plweb.is_element_present(
            ".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'Working/Idle')]")
        dgb = handles.plweb.is_element_present(
            ".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'DGB')]")
        electricpower = handles.plweb.is_element_present(
            ".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'Electric Power')]")

        if uworking_idle is True:
            if workingidle is False:
                handles.plweb.driver.find_element_by_xpath(".//input[@value='cat_1']").click()
        else:
            if workingidle is True:
                handles.plweb.driver.find_element_by_xpath(".//input[@value='cat_1']").click()

        if udgb is True:
            if dgb is False:
                handles.plweb.driver.find_element_by_xpath(".//input[@value='cat_2']").click()
        else:
            if dgb is True:
                handles.plweb.driver.find_element_by_xpath(".//input[@value='cat_2']").click()

        if uelectricpower is True:
            if electricpower is False:
                handles.plweb.driver.find_element_by_xpath(".//input[@value='cat_3']").click()
        else:
            if electricpower is True:
                handles.plweb.driver.find_element_by_xpath(".//input[@value='cat_3']").click()

        workingidle = handles.plweb.is_element_present(".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'Working/Idle')]")
        dgb = handles.plweb.is_element_present(".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'DGB')]")
        electricpower = handles.plweb.is_element_present(".//div[@class='grid-container-header-scrollFix']//child::div[contains(@class,'grid-row-headcat clear-fix')]//child::div[contains(@style,'display: inline-block;')]//child::span[contains(text(),'Electric Power')]")

        if workingidle is True:
            workingidle = "Displayed"
        else:
            workingidle = "Not Displayed"

        if dgb is True:
            dgb = "Displayed"
        else:
            dgb = "Not Displayed"

        if electricpower is True:
            electricpower = "Displayed"
        else:
            electricpower = "Not Displayed"

        if uworking_idle is True:
            uworking_idle = "Displayed"
        else:
            uworking_idle = "Not Displayed"

        return {"workingidle": workingidle, "dgb": dgb, "electricpower": electricpower}
