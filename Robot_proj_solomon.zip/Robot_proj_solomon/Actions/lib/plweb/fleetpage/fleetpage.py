"""
Module for performing operations and data extraction on Fleet Page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/fleetpage.py
# **
# ** DESCRIPTION:
# **     Module for performing operations and data extraction on Fleet Page.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except
from lib.plweb.fleetpage.dataviz import DataVisualization
from lib.plweb.fleetpage.kpi import KeyPerformanceIndicator
from lib.plweb.fleetpage.utilization import UtilizationPage


class FleetPage(object):
    """ Parent Class for Fleet Page. """
    def __init__(self, parent):
        """ Method to initialize the handles for Fleet Page. """
        self.parent = parent
        self.viz = DataVisualization(self.parent, self)
        self.kpi = KeyPerformanceIndicator(self.parent, self)
        self.utilization = UtilizationPage(self.parent,self)
        self.parent_window = None

    @catch_except
    def search_asset_in_fleet(self, asset_name):
        """ Method to Search the asset in Fleet. """
        self.parent.input(".//*[@ng-model='searchText']", asset_name)

    @catch_except
    def select_asset_in_fleet(self, asset_name):
        """ Method to Select the asset in Fleet. """
        self.search_asset_in_fleet(asset_name)
        self.parent.click(".//*[@class='innerbox']")
        sleep(5)

    @catch_except
    def select_standalone_in_complex_asset(self, asset_name):
        """ Method to Select the Standalone asset in Complex Asset. """
        self.search_asset_in_fleet(asset_name)
        sleep(1)
        self.parent.click(".//*[contains(@class,'avatar_plus')]")
        sleep(1)
        parent_element = self.parent.find_element_by_xpath(".//*[@id='{}']".format(asset_name))
        parent_element.find_element_by_xpath(".//*[@class='innerbox']").click()
        sleep(2)

    @catch_except
    def go_to_data_viz(self):
        """ Method to Go to Data Vizualization Page."""
        self.parent_window = self.parent.driver.current_window_handle
        self.parent.click('//*[@id="navlist"]/li[2]/a')
        sleep(1.5)
        self.parent.click('.//*[@ng-href="#/datavizualization"]')
        self.parent.wait_till_delay('.//*[@class="datavizualization ng-scope"]')
        self.parent.switch_frame(self.parent.driver.find_element_by_tag_name("iframe"))
        self.parent.wait_till_inactive_delay(".//*[@id='loadingIcon']", 60)
        self.parent.click('.//*[@id="breadcrumbs"]')
        # sleep(30)

    @catch_except
    def get_asset_row_data(self, assetname):
        """ Method to get the Asset Row data of the fleet summary page."""
        class FleetAssetInfo(object):
            """ Constructor to initialize object to hold the summary page information. """
            def __init__(self):
                self.equipmentid = None
                self.serialnum = None
                self.make = None
                self.model = None
                self.alertcount = None
                self.datelastreported = None
                self.hours = None
                self.lastreportedstatus = None
                self.lastreportedlocation = None
                self.lastreportedlocationtimestamp = None
        self.search_asset_in_fleet(assetname)
        sleep(8)
        info = FleetAssetInfo()
        info.equipmentid = self.parent.get_value('.//*[@identifier="equipmentId"]')
        info.serialnum = self.parent.get_value('.//*[@identifier="assetSN"]')
        info.make = self.parent.get_value('.//*[@identifier="make"]')
        info.model = self.parent.get_value('.//*[@identifier="model"]')
        info.alertcount = self.parent.get_value('.//*[@identifier="AlertCount"]')
        info.datelastreported = self.parent.get_value('.//*[contains(@identifier,"dateLastReported")]')
        info.hours = self.parent.get_value('.//*[@identifier="hours"]')
        info.lastreportedstatus = self.parent.get_value('.//*[@identifier="status"]')
        info.lastreportedlocation = self.parent.get_value('.//*[@identifier="lastReportedLocation"]')
        info.lastreportedlocationtimestamp = \
            self.parent.get_value('.//*[contains(@identifier,"lastReportedLocationTimestamp")]')
        return info

    @catch_except
    def get_asset_element_row_data(self, assetelement):
        """ Method to get the Asset Row data of the fleet summary page."""
        class FleetAssetInfo(object):
            """ Constructor to initialize object to hold the summary page information. """
            def __init__(self):
                self.equipmentid = None
                self.serialnum = None
                self.make = None
                self.model = None
                self.alertcount = None
                self.datelastreported = None
                self.hours = None
                self.lastreportedstatus = None
                self.lastreportedlocation = None
                self.lastreportedlocationtimestamp = None
        info = FleetAssetInfo()
        self.parent.wait_till_inactive_delay(".//*[@id='loadingIcon']", 60)
        info.equipmentid = \
            self.parent.get_value_by_element(self.parent.
                                             find_element_by_xpath_with_parent(assetelement,
                                                                               './/*[@identifier="equipmentId"]'))
        info.serialnum = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="assetSN"]'))
        info.make = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="make"]'))
        info.model = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="model"]'))
        info.alertcount = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="AlertCount"]'))
        info.datelastreported = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="dateLastReported24Hours"]'))
        info.hours = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="hours"]'))
        info.lastreportedstatus = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="status"]'))
        info.lastreportedlocation = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement, './/*[@identifier="lastReportedLocation"]'))
        info.lastreportedlocationtimestamp = self.parent.get_value_by_element(
            self.parent.find_element_by_xpath_with_parent(assetelement,
                                                          './/*[@identifier="lastReportedLocationTimestamp24Hours"]'))
        return info

    @catch_except
    def is_standalone_in_complex_asset(self, asset_name):
        """ Method to Select the Standalone asset in Complex Asset. """
        self.search_asset_in_fleet(asset_name)
        sleep(10)
        return self.parent.click(".//*[contains(@class,'avatar_plus')]")

    @catch_except
    def get_fleet_summary_header(self):
        """ Method to get the Fleet Summary Header. """
        header = list()
        for i in range(1, 11):
            header.append((self.parent.find_element_by_xpath("//*[@id='headerContainer']"
                                                             "/div/div/div/div[%s]/span[1]" % i)).text)
        return header

    @catch_except
    def search_make_in_fleet(self, make):
        """ Method to Search the asset in Fleet. """
        self.parent.input(".//*[@ng-model='searchText']", make)
        return True

    @catch_except
    def search_model_in_fleet(self, model):
        """ Method to Search the asset in Fleet. """
        self.parent.input(".//*[@ng-model='searchText']", model)
        return True

    @catch_except
    def go_to_fleet_element_present(self, flag='csv'):
        """Method to get the value of the Placeholder Attribute"""
        if flag == 'csv':
            xpath = str(".//*[contains(@class,'exportToCSVImage')]")
            return self.parent.is_element_present(xpath)
        if flag == 'date':
            xpath = str(".//*[contains(@class,'datePickerLabelEnd ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'filter':
            xpath = str(".//*[contains(@id,'filter_label')]")
            return self.parent.is_element_present(xpath)
        if flag == 'smartsearch':
            xpath = str(".//*[contains(@class,'searchBox')]")
            return self.parent.is_element_present(xpath )
        if flag == 'equipmentid':
            xpath = str(".//*[contains(text(),'Equipment ID ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'serialno':
            xpath = str(".//*[contains(text(),'S/N')]")
            return self.parent.is_element_present(xpath)
        if flag == 'make':
            xpath = str(".//*[contains(text(),'Make ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'model':
            xpath = str(".//*[contains(text(),'Model ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'alertcount':
            xpath = str(".//*[contains(text(),'Alert Count ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'datelastreported':
            xpath = str(".//*[contains(text(),'Date Last Reported ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'hours':
            xpath = str(".//*[contains(text(),'Hours ')] ")
            return self.parent.is_element_present(xpath)
        if flag == 'lastreportedstatus':
            xpath = str(".//*[contains(text(),'Last Reported Status ')] ")
            return self.parent.is_element_present(xpath)
        if flag == 'lastreportedlocation':
            xpath = str(".//*[contains(text(),'Last Reported  Location ')]")
            return self.parent.is_element_present(xpath)
        if flag == 'lastreportedlocationtimestamp':
            xpath = str(".//*[contains(text(),'Last Reported Location Timestamp ')]")
            return self.parent.is_element_present(xpath)
        return False


