"""
Module for performing operations and data extraction on Fleet Page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/fleetpage/kpi.py
# **
# ** DESCRIPTION:
# **     Module for performing operations and data extraction on Key performance Indicator Page.
# **
# ** AUTHOR:
# **    Pragati Bhargava(bhargp)
# ** HISTORY:
# ** Change 00  2017-03-24 (bhargp)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except


class KeyPerformanceIndicator(object):
    """ Parent Class for Key Performance Indicator. """
    def __init__(self, parent, fleet):
        """ Method to initialize handles for Key performance Indicator """
        self.parent = parent
        self.fleet = fleet

    @catch_except
    def default_date_range(self, date_range="seven-days"):
        # today, yesterday, seven-days, thirty-days
        """ Method to Set the Default Date Range. """
        self.parent.wait_till_delay('.//*[@class="dropdown nav-datepicker"]', 20)
        self.parent.click('.//*[@class="dropdown nav-datepicker"]')
        sleep(1)
        self.parent.wait_till_delay('.//*[@id="{}"]'.format(date_range))
        sleep(2)
        self.parent.click('.//*[@id="{}"]'.format(date_range))
        sleep(2)
        self.parent.click('.//*[@id="apply-date"]')
        sleep(2)

    @catch_except
    def close_all_widgets(self):
        """ Method to Close all open widgets. """
        closeelements = self.parent.driver.find_elements_by_xpath('.//*[@class="glyphicon glyphicon-remove"]')
        for elements in closeelements:
            self.parent.click_element(elements)
            sleep(1)
        # self.parent.driver.switch_to_default_content()
        # sleep(1)
        # self.parent.go_to_home_page()
        # sleep(2)
        # self.fleet.go_to_data_viz()
        # sleep(2)

    @catch_except
    def select_search_asset(self):
        """ Method to Select and Search Asset in Data Viz page"""
        self.parent.click('//*[@id="search-Assets-Icon-minimized"]')
        sleep(1)

    @catch_except
    def deselect_all_asset(self):
        """ Method to De-Select all the asset after select_search_asset()"""
        self.parent.click('.//*[@class="input-group-addon"]')
        sleep(1)
        self.parent.click('.//*[@id="select-all"]')
        sleep(1)

    @catch_except
    def select_asset(self, asset_name):
        """ Method to Select the Asset. """
        self.select_search_asset()
        self.deselect_all_asset()
        self.parent.input('.//*[@id="select-assets"]', asset_name)
        sleep(0.25)
        status = self.parent.click('.//*[@title="{}"]/*[@class="check"]'.format(asset_name))
        sleep(0.25)
        self.parent.click('.//*[@id="asset-ok"]')
        sleep(1)
        return status
