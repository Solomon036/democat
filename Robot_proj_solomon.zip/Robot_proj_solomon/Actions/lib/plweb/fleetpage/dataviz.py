"""
Module for performing operations and data extraction on Fleet Page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/fleetpage/dataviz.py
# **
# ** DESCRIPTION:
# **     Module for performing operations and data extraction on Data Visualization Page.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except


class DataVisualization(object):
    """ Parent Class for Data Visualization. """
    def __init__(self, parent, fleet):
        """ Method to initialize handles for Data Visualization """
        self.parent = parent
        self.fleet = fleet

    @catch_except
    def is_event_chart_data_loaded(self):
        """
        Method to verify whether the chart is loaded properly with out error.
        Return True when Chart is successfully loaded else False.
        """
        return self.parent.is_element_present('.//*[contains(@class, "chart-container")]')

    @catch_except
    def default_date_range(self, date_range="seven-days"):
        # today, yesterday, seven-days, thirty-days
        """ Method to Set the Default Date Range. """
        self.parent.wait_till_delay('.//*[@class="dropdown nav-datepicker"]', 20)
        self.parent.click('.//*[@class="dropdown nav-datepicker"]')
        sleep(1)
        self.parent.wait_till_delay('.//*[@id="{}"]'.format(date_range))
        sleep(2)
        self.parent.click('.//*[@id="{}"]'.format(date_range))
        sleep(2)
        self.parent.click('.//*[@id="apply-date"]')
        sleep(2)

    @catch_except
    def load_events_widget(self):
        """ Method to load the EDDT chart widget. """
        # self.default_date_range()
        self.parent.click('.//*[@id="Events-mini"]')
        self.parent.drag_drop('.//*[@id="Events-mini"]',
                              '//*[@id="dashboard-gridster"]')
        self.parent.wait_till_delay('//*[@class="chart-container"]', 60)
        return self.is_event_chart_data_loaded()

    @catch_except
    def load_histogram_widget(self):
        """ Method to load Histogram Chart Widget. """
        # self.default_date_range()
        # self.parent.click('.//*[@id="Histogram-mini"]')
        self.parent.drag_drop('.//*[@id="Histogram-mini"]',
                              '//*[@id="dashboard-gridster"]')
        return self.parent.is_element_present('.//*[@placeholder="Enter Equipment Name"]')

    @catch_except
    def load_vpdl_widget(self):
        """ Method to load VPDL Widget. """
        # self.default_date_range()
        self.parent.click('.//*[@id="VPDL-mini"]')
        self.parent.drag_drop('.//*[@id="VPDL-mini"]',
                              './/*[@id="dashboard-gridster"]')
        return self.parent.is_element_present('.//*[@placeholder="Enter Equipment Name"]')

    @catch_except
    def load_snapshots_widget(self):
        """ Method to load Snapshot Widget. """
        self.default_date_range()
        self.parent.click('.//*[@id="Snapshot-mini"]')
        self.parent.drag_drop('.//*[@id="Snapshot-mini"]', './/*[@id="dashboard-gridster"]')
        self.parent.wait_till_delay('.//*[@type="radio"]')
        self.parent.checkboxclick('.//*[@type="radio"]')
        self.parent.click('.//*[@class="glyphicon glyphicon-forward"]')
        self.parent.wait_till_delay('.//*[@class="snapshot-channel-checkbox"]')
        self.parent.checkboxclick('.//*[@class="snapshot-channel-checkbox"]')
        self.parent.wait_till_delay('.//*[contains(@id="Chart_")]', 60)
        return self.parent.is_element_present('.//*[contains(@id="Chart_")]')

    @catch_except
    def load_usage_widget(self):
        """ Method to load Usage Widget. """
        self.default_date_range()
        self.parent.click('.//*[@id="Usage-mini"]')
        self.parent.drag_drop('.//*[@id="Usage-mini"]', './/*[@id="dashboard-gridster"]')
        return self.parent.is_element_present('.//*[@placeholder="Enter Equipment Name"]')

    @catch_except
    def load_fuel_widget(self):
        """ Method to load Fuel Widget. """
        self.default_date_range()
        self.parent.click('.//*[@id="Fuel-mini"]')
        self.parent.drag_drop('.//*[@id="Fuel-mini"]', './/*[@id="dashboard-gridster"]')
        return self.parent.is_element_present('.//*[@placeholder="Enter Equipment Name"]')

    @catch_except
    def load_cumulative_widget(self):
        """ Method to load Cumulative Widget. """
        self.default_date_range()
        self.parent.click('.//*[@id="Cumulatives-mini"]')
        self.parent.drag_drop('.//*[@id="Cumulatives-mini"]', './/*[@id="dashboard-gridster"]')
        return self.parent.is_element_present('.//*[@class="dataTables_scroll"]')

    @catch_except
    def load_datalogger_widget(self):
        """ Method to load Datalogger Widget. """
        self.default_date_range()
        self.parent.click('.//*[@id="pldatalogger-mini"]')
        self.parent.drag_drop('.//*[@id="pldatalogger-mini"]', './/*[@id="dashboard-gridster"]')
        return self.parent.is_element_present('.//*[@placeholder="Enter Equipment Name"]')

    @catch_except
    def close_all_widgets(self):
        """ Method to Close all open widgets. """
        closeelements = self.parent.driver.find_elements_by_xpath('.//*[@class="glyphicon glyphicon-remove"]')
        for elements in closeelements:
            self.parent.click_element(elements)
            sleep(1)
        # self.parent.driver.switch_to_default_content()
        # sleep(1)
        # self.parent.go_to_home_page()
        # sleep(2)
        # self.fleet.go_to_data_viz()
        # sleep(2)

    @catch_except
    def select_search_asset(self):
        """ Method to Select and Search Asset in Data Viz page"""
        self.parent.click('//*[@id="search-Assets-Icon-minimized"]')
        sleep(1)

    @catch_except
    def deselect_all_asset(self):
        """ Method to De-Select all the asset after select_search_asset()"""
        self.parent.click('.//*[@class="input-group-addon"]')
        sleep(1)
        self.parent.click('.//*[@id="select-all"]')
        sleep(1)

    @catch_except
    def select_asset(self, asset_name):
        """ Method to Select the Asset. """
        self.select_search_asset()
        self.deselect_all_asset()
        self.parent.input('.//*[@id="select-assets"]', asset_name)
        sleep(0.25)
        status = self.parent.click('.//*[@title="{}"]/*[@class="check"]'.format(asset_name))
        sleep(0.25)
        self.parent.click('.//*[@id="asset-ok"]')
        sleep(1)
        return status
