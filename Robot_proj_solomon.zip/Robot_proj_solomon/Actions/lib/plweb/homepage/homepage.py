"""
Module for performing operations and data extraction on Home Page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/homepage.py
# **
# ** DESCRIPTION:
# **     Module for performing operations and data extraction on Home Page.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except


class HomePage(object):
    """ Parent Class for Home Page. """
    def __init__(self, parent):
        """ Initialize Constructor control for Home Page Class."""
        self.parent = parent

    @catch_except
    def enter_location(self, location):
        """ Method to enter the location in Home Page. """
        self.parent.input(".//*[@ng-model='findLocation.searchText']", location)
        self.parent.find_element_by_xpath(".//*[@ng-model='findLocation.searchText']").submit()
        self.parent.click(".//*[@class='input-group-addon']")
        return True

    @catch_except
    def enter_sn(self, serialnum):
        """ Method to enter the location in Home Page. """
        self.parent.click("//*[@class='search']")
        sleep(2)
        self.parent.input("//*[@id='searchText']", serialnum)
        self.parent.click("//*[@class='goButton ng-binding']")
        sleep(10)
        val = self.parent.find_element_by_xpath("//*[@id='assetImageCont']/table/tbody/tr/td[2]/div[3]/div[2]/b").text
        return serialnum.strip() in val.strip()

    @catch_except
    def validate_gp_fleet_view(self, gp_name):
        """"Method to validate the group in Fleet View"""
        self.parent.click('//*[@class ="leftSummaryTitle"]//*[@ng-model="defaultGroup"]')
        val = self.parent.get_value('//*[@class ="leftSummaryTitle"]//*[@ng-model="defaultGroup"]')
        if gp_name in val:
            return True

    @catch_except
    def get_homepage_utilization(self):
        """ Getting the fuel and power utilization from Fleet >> Utilization page"""
        self.parent.go_to_home_page()
        sleep(5)
        self.parent.wait_till_delay(".//*[@id='totalFuelUsed']")
        home_fuelvalue = self.parent.driver.find_element_by_xpath(".//*[@id='totalFuelUsed']").text
        home_working = self.parent.driver.find_element_by_xpath(".//div[text()='Working']//following-sibling::a").text
        home_notworking = self.parent.driver.find_element_by_xpath(
            ".//div[text()='Not Working']//following-sibling::a").text
        home_power = self.parent.driver.find_element_by_xpath(".//*[@id='totalKilowatthour']").text
        homepagedata = {}
        homepagedata["Fuel Burned"] = home_fuelvalue
        homepagedata["kWh"] = home_power
        homepagedata["Working"] = home_working
        homepagedata["Not working"] = home_notworking
        return homepagedata


