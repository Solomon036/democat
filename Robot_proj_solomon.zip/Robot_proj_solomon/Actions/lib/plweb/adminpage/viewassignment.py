"""
Module to perform operation and data extraction in Product Structures page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/viewassingment.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from view assignment Page for Product Link Application.
# **
# ** AUTHOR:
# **    Umasri Devireddy
# ** HISTORY:
# ** Change 00  2017-04-04 (deviru)
# **     Created the Initial Version of the file for View assignment.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except


class ViewAssignment(object):
    """ Parent Class for the view assignment Page of Admin Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of view assignment page. """
        self.parent = parent
        self.admin = admin

    @catch_except
    def create_view_assignment(self):
        """ Method to click Create View Assignment button. """
        self.parent.wait_till_delay(".//*[@ng-click='createViewAssignmentPage()']", 30)
        self.parent.click(".//*[@ng-click='createViewAssignmentPage()']")
        return self.parent.is_displayed('.//*[@class="manageViewAssignmentContainer ''ng-scope"]', 20)

    @catch_except
    def enter_view_assignment_name(self, view_assignment_name):
        """ Method to Enter the View Assignment Name. """
        self.parent.input(".//*[@id='entrAlertName']", view_assignment_name)
        sleep(0.5)
        return True

    @catch_except
    def get_existing_view_assignment_error(self):
        """Method to get the error displayed on entering existing Assignment Name"""
        return self.parent.get_value(".//*[@class='transformToLowercaseCls ng-binding']")

    @catch_except
    def enter_dealer_code(self, dealer_code):
        """ Method to Enter Dealer code in Select Viewer and expire date page """
        self.parent.input(".//*[contains(@class,'typeaHeadFldCls')]", dealer_code)
        self.parent.wait_till_delay(".//*[@matches = 'matches']", 20)
        dealer_code_add = self.parent.get_value(".//*[@matches = 'matches']")
        if dealer_code_add == dealer_code:
            sleep(2)
            self.parent.click(".//*[@matches = 'matches']")
            return True
        else:
            return False

    @catch_except
    def add_dealer_code(self):
        """ Method to click on create View assignment button"""
        self.parent.click(".//*[@class='asyncSelected ng-binding']")
        sleep(2)

    @catch_except
    def dealer_code_assigned_viewer(self):
        """ Method to get the added dealer code in the assigned dealer page"""
        self.parent.wait_till_delay(".//*[@identifier='accCode']", 20)
        return self.parent.get_value(".//*[@identifier='accCode']")

    @catch_except
    def filter_expand(self):
        """ Method to expand the filter option in left side of the view assingment page"""
        self.parent.wait_till_delay(".//*[@class='expandPannelIcon']")
        self.parent.click(".//*[@class='expandPannelIcon']")
        return self.parent.wait_till_delay(".//*[@ng-click='handleClearAllClick()']", 10)

    @catch_except
    def filter_asset_view_assignment(self, assetname):
        """ Method to Filter the asset in Select equipment pane in View assignment page"""
        element = self.parent.find_element_by_xpath('//*[@ng-if="gridData"]//*[@id="searchInputCCat"]')
        self.parent.scroll_to_view_element(element)
        for _ in range(2):
            element.clear()
            sleep(0.2)
            for i in assetname:
                element.send_keys(i)
                sleep(0.2)
            sleep(2)
        return True

    @catch_except
    def select_assets(self, asset_name):
        """ Method to select the Asset(s) in Select equipment Pane. """
        if isinstance(asset_name, list):
            for asset in asset_name:
                self.filter_asset_view_assignment(asset)
                sleep(0.5)
                self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
                sleep(0.5)
        else:
            self.filter_asset_view_assignment(asset_name)
            self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
            sleep(0.5)

    @catch_except
    def edit_view_assignment(self):
        """ Method to click on Edit view assignment button in view assignment page"""
        self.parent.wait_till_delay(".//*[@class='groupEditButton ng-scope']")
        self.parent.click(".//*[@class='groupEditButton ng-scope']")
        return self.parent.is_displayed('.//*[@class="manageViewAssignmentContainer '
                                        'ng-scope"]', 30)

    @catch_except
    def next_button_exists(self):
        """ Method to verify the next button existence"""
        self.parent.wait_till_delay(".//*[@ng-click='moveNext();']", 30)
        return self.parent.is_displayed(".//*[@ng-click='moveNext();']")

    @catch_except
    def next_button_view_assignment(self):
        """ Method to click on Next button in view assignment page"""
        self.parent.wait_till_delay(".//*[@ng-click='moveNext();']", 30)
        sleep(3)
        self.parent.click(".//*[@ng-click='moveNext();']")

    @catch_except
    def get_view_assignment_lables(self):
        """ Method to get labels select Equipment,Select viewer and expiration date and Confirm and Activate. """
        parent_element = self.parent.driver.find_elements_by_class_name("wizardSectionClass")
        label_name = []
        for element in parent_element:
            label_name.append(self.parent.get_value_by_element(element))
        return label_name

    @catch_except
    def cancel_button(self):
        """ Method to check the existence of cancel button """
        return self.parent.is_displayed(".//*[@ng-click='multiPageConfig.onCancelBtn();']")

    @catch_except
    def previous_button(self):
        """ Method to check the existence of Previous button """
        return self.parent.is_displayed(".//*[@ng-click='movePrev();']")

    @catch_except
    def next_button(self):
        """ Method to check the existence of next button """
        return self.parent.is_displayed(".//*[@ng-click='moveNext();']")

    @catch_except
    def click_activate_button(self):
        """ Method to click on Activate button """
        self.parent.is_displayed(".//*[@ng-click='multiPageConfig.onCreateBtn();']", 20)
        self.parent.click(".//*[@ng-click='multiPageConfig.onCreateBtn();']")
        self.parent.wait_till_delay(".//*[contains(@class,'manageViewAssignmentContainer ')]", 30)
        return self.parent.is_displayed(".//*[contains(@class,'manageViewAssignmentContainer ')]")

    @catch_except
    def landing_page(self):
        """ Method to go to the landing page. """
        self.parent.wait_till_delay(".//*[contains(@class,'manageViewAssignmentContainer ')]", 30)
        return self.parent.is_displayed(".//*[contains(@class,'manageViewAssignmentContainer ')]")

    @catch_except
    def delete_view_assignment(self, asset, assignmentname = ""):
        """ Method to Delete a View Assignment """
        element = self.search_asset_page(asset, assignmentname)
        try:
            delete_button = element.find_element_by_xpath(".//*[@class='groupDeleteButton ng-scope']")
            delete_button.click()
            delete_msg = self.parent.get_value(".//*[@id='customConfirm']/div[2]")
            self.parent.is_displayed(".//*[@onclick='window.customConfirm.ok()']", 20)
            self.parent.click(".//*[@onclick='window.customConfirm.ok()']")
            return delete_msg
        except Exception as err:
            return False

    @catch_except
    def search_asset_page(self, asset_name, assignmentname):
        """ Method to search asset in view assignment page """
        search_element = self.parent.find_element_by_xpath('//*[@ng-model="search.key"]')
        self.parent.scroll_to_view_element(search_element)
        for _ in range(2):
            search_element.clear()
            sleep(0.2)
            for i in asset_name:
                search_element.send_keys(i)
                sleep(0.2)
            sleep(2)
        sleep(10)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@class='accordion-toggle']"):
            if assignmentname in (element.find_element_by_xpath(".//*[@ng-if='group.webViewName']")).text:
                return element
        return False

    @catch_except
    def get_active_state(self, assignmentname, asset):
        """ Method to get the Active state of view assignment page """
        element = self.search_asset_page(asset, assignmentname)
        try:
            return (element.find_element_by_xpath(".//*[@ng-if='group.webViewState']")).text
        except Exception as err:
            return False


    @catch_except
    def click_down_arrow(self):
        "Method to click on Drop down in View assignment page to verify the asset"
        self.parent.wait_till_delay(".//*[@ng-if='group.webViewState']", 30)
        self.parent.click(".//*[@ng-if='group.webViewName']")
        self.parent.wait_till_delay(".//*[@ng-disabled='!group.webViewState']", 30)
        return self.parent.is_displayed(".//*[@ng-disabled='!group.webViewState']")


    @catch_except
    def deactivate_button(self):
        """ Method to click the deactive button."""
        self.parent.click("//*[text()='Deactivate']")
        sleep(6)
        return self.parent.iselement_enabled("//*[text()='Deactivate']")


    @catch_except
    def cancel_button_click(self):
        """ Method to check the existence of cancel button """
        self.parent.is_displayed(".//*[@ng-click='multiPageConfig.onCancelBtn();']")
        self.parent.click(".//*[@ng-click='multiPageConfig.onCancelBtn();']")


    @catch_except
    def save_only(self):
        """" Method to click on Save only button """
        self.parent.click("//*[text()='Save Only']")
        sleep(5)


    @catch_except
    def save_only_exists(self):
        """" Method to click on Save only button """
        sleep(5)
        return self.parent.is_displayed("//*[text()='Save Only']")


    @catch_except
    def select_viewer_page(self):
        """" Method to ccheck if Select/ Add Viewer is displayed """
        return self.parent.is_displayed("// *[text() = 'Select / Add Viewer(s)']")


    @catch_except
    def alert_cancel(self):
        """"Method to check the alert shows by clicking on Cancel button"""
        if self.parent.is_displayed("//*[@id='customConfirm']"):
            self.parent.click("//*[@onclick='window.customConfirm.ok()']")
            return self.parent.is_displayed("//*[@class='ng-binding ng-scope']")
        else:
            return False


    @catch_except
    def is_name_txtbox_available(self):
        """Method to check if View Assignment Name text box is available"""
        return self.parent.is_displayed(".//*[@id='entrAlertName']")


    @catch_except
    def is_filter_available(self):
        """Method to check if Filter is available on the Left Side"""
        return self.parent.is_displayed(".//*[@class='expandPannelIcon']")


    @catch_except
    def is_select_equip_section_available(self):
        """Method to check if Select/Available Equipment Pane is available"""
        return self.parent.is_displayed(".//*[@id='selectEquipmentSection']")


    @catch_except
    def is_selected_equip_section_available(self):
        """Method to check if Selected Equipment Pane is available"""
        return self.parent.is_displayed(".//*[@id='selectEquipmentSection']")


