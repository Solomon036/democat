"""
Module to perform operation and data extraction in Configuration Manager page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/deviceconfig/configmanagepage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Configuration Manager Page for Product Link Application.
# **
# ** AUTHOR:
# **     Mani Shankar Venkatachalam.
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except


class ConfigManage(object):
    """ Parent Class for the Configuration Manager Page of Admin Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of Configuration Manager page. """
        self.parent = parent
        self.admin = admin

    @catch_except
    def enter_customer_ucid(self, ucId):
        """"Enter UCID Number/Name in Config Page"""
        self.parent.input("//*[@id='ucIdTextBox']", ucId)
        self.parent.wait_till_delay(".//*[@class='dropDownRow ng-scope']", 20)
        ucId_add = self.parent.get_value(".//*[@class='dropDownRow ng-scope']")
        if ucId_add == ucId:
            sleep(2)
            self.parent.click(".//*[@class='dropDownRow ng-scope']")
            return True
        else:
            return False


