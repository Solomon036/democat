"""
Module to perform operation and data extraction in Switch Configuration page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/deviceconfig/switchconfigpage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Switch Configuration Page for Product Link Application.
# **
# ** AUTHOR:
# **
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for structure.
# **
# *******************************************************************************
# """
from time import sleep
from lib.webinterface import catch_except


class SwitchConfig(object):
    """ Parent Class for the Switch Config Page of Device Configuration Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of Switch Config page. """
        self.parent = parent
        self.switch_slot = 0
        self.admin = admin

    @catch_except
    def search_asset_in_swconfig(self, assetname):
        """ Method to Search the asset in Switch Configuration Page. """
        self.admin.filter_asset(assetname)
        sleep(1)
        return True

    @catch_except
    def select_asset_in_swconfig(self, assetname):
        """ Method to Select the asset in Switch Configuration. """
        self.search_asset_in_swconfig(assetname)
        self.parent.click(".//*[@ng-model='data.Selected']")
        sleep(5)
        self.click_configure()
        return True

    @catch_except
    def click_configure(self):
        """ Method to Click Configure."""
        self.parent.click(".//*[@class='configureBtnDiv configureBtnDivPadding']/button")
        sleep(2)

    @catch_except
    def click_alert(self):
        """ Method to Click Alert."""
        self.parent.click(".//*[@class='configureBtnDiv']/button")
        sleep(2)

    @catch_except
    def configure_sw_content(self, index):
        """ Method to Configure the Switch Content. """
        if index:
            xpath = ".//*[@switchdata='switchdata[switchStartIndex+{}]']".format(index)
        else:
            xpath = ".//*[@switchdata='switchdata[switchStartIndex]']"
        element = self.parent.find_element_by_xpath(xpath)
        element.find_element_by_xpath(".//*[@ng-model='switchdata.description']").clear()
        sleep(0.25)
        element.find_element_by_xpath(".//*[@ng-model='switchdata.description']")\
            .send_keys('Switch {}'.format(self.switch_slot + index))
        sleep(0.5)
        element.find_element_by_xpath(".//*[@ng-model='switchdata.state']/option[@value='all_conditions']").click()
        sleep(0.5)
        element.find_element_by_xpath(".//*[@ng-model='switchdata.monitorMode']/option[@value='always']").click()
        sleep(0.5)
        element.find_element_by_xpath(".//*[@ng-model='switchdata.delayTime']").clear()
        sleep(0.25)
        element.find_element_by_xpath(".//*[@ng-model='switchdata.delayTime']").send_keys('10.0')
        sleep(0.5)
        element.find_element_by_xpath(".//*[@value='send immediately']").click()
        sleep(0.5)
        return True

    @catch_except
    def configure_switches(self):
        """ Method to configure all the Switches in the Switch list. """
        for slot in range(1, 4):
            self.switch_slot = slot
            if slot == 2:
                self.switch_slot = 5
            elif slot == 3:
                self.switch_slot = 9
            self.parent.wait_till_delay(".//*[@ng-click='switchCatClicked({})']".format(slot))
            if self.parent.click(".//*[@ng-click='switchCatClicked({})']".format(slot)):
                sleep(2)
                for index in range(4):
                    self.configure_sw_content(index)
                    sleep(0.25)
        return True

    @catch_except
    def sw_config_send(self):
        """ Method to Send the Switch Configuration. """
        self.parent.click(".//*[@ng-click='sendHandler();']")
        sleep(5)

    @catch_except
    def generate_sw_configuration(self, assetname):
        """ Method to Generate the Switch Configuration. """
        self.select_asset_in_swconfig(assetname)
        self.configure_switches()
        self.sw_config_send()
        self.parent.clear_web_alerts()
        return True

    @catch_except
    def fill_alert_details(self, alert_name=''):
        """ Method to fill the alert details in Manage Switch Alert. """
        self.parent.find_element_by_xpath(".//*[@id='entrAlertName']").clear()
        self.parent.find_element_by_xpath(".//*[@id='entrAlertName']").send_keys(str(alert_name))
        for _ in range(1, 5):
            self.parent.click("(.//*[@ng-model='selSwitches[k]'])[{}]".format(_))
            sleep(0.25)
        self.enter_recipient_name(name='switch_alert_name_123')
        self.select_gmt_time_zone()
        self.enter_mail_or_mobile_info(email='xxx@cat.com')
        self.add_recipient()
        return True

    @catch_except
    def edit_alert_details(self, alert_name=''):
        """ Method to fill the alert details in Manage Switch Alert. """
        self.click_alert_edit()
        self.parent.find_element_by_xpath(".//*[@id='entrAlertName']").clear()
        self.parent.find_element_by_xpath(".//*[@id='entrAlertName']").send_keys(str(alert_name))
        for _ in range(1, 6):
            self.parent.click("(.//*[@ng-model='selSwitches[k]'])[{}]".format(_))
            sleep(0.25)
        self.enter_recipient_name(name=str(alert_name*2))
        self.select_gmt_time_zone()
        self.enter_mail_or_mobile_info(email='yyy@cat.com')
        self.update_recipient()
        self.click_next()
        self.parent.click(".//*[@ng-click='multiPageConfig.onEditSaveBtn();']")
        self.parent.click(".//*[@class='btn btn-primary']")
        return True

    @catch_except
    def enter_recipient_name(self, name=''):
        """ Method to enter the Recipient Name for the alert rule. """
        self.parent.input(".//*[@ng-model='addRecipientsData.recipientName']",
                          name)
        sleep(0.2)

    @catch_except
    def enter_mail_or_mobile_info(self, email='', rep_type='email'):
        """ Method to enter the Email ID for the alert rule. """
        if rep_type == 'email':
            self.parent.click(".//*[@name='byEmail']")
        else:
            self.parent.click(".//*[@name='byEmailTextMsg']")
        sleep(3)
        self.parent.input(".//*[@type='email']", email)
        sleep(0.2)

    @catch_except
    def add_recipient(self):
        """ Method to add the Recipient name. """
        self.parent.click(".//*[@ng-click='addDataVal()']")
        sleep(0.2)

    @catch_except
    def update_recipient(self):
        """ Method to edit the Recipient name. """
        self.parent.click(".//*[@ng-click='updateDataVal()']")
        sleep(0.2)

    @catch_except
    def select_gmt_time_zone(self, timezone="GMT"):
        """
        Method to select GMt time zone"
        @timezone <string> GMT specified time Zone
        @:return Boolean
        """
        self.parent.click(".//*[@ng-model='switchtzcode']")
        sleep(0.1)
        self.parent.click(".//*[text()='{}']".format(timezone))
        sleep(0.5)
        return True

    @catch_except
    def click_next(self):
        """ Method to do the click Next operation. """
        self.parent.click(".//*[@ng-click='moveNext();']")
        sleep(0.2)
        return True

    @catch_except
    def click_alert_create(self):
        """ Method to click the Create button to do the  final alert rule creation."""
        self.parent.click(".//*[@ng-click='multiPageConfig.onCreateBtn();']")
        return True

    @catch_except
    def click_alert_edit(self):
        """Method to edit the Switch Configuration Alert"""
        self.parent.click(".//*[@class='groupEditButton ng-scope']")
        sleep(2)
        self.parent.click(".//*[@class='glyphicon glyphicon-edit']")
        return True

    @catch_except
    def click_alert_delete(self):
        """Method to delete the Switch Configuration Alert"""
        self.parent.click(".//*[@class='groupDeleteButton ng-scope']")
        sleep(2)
        self.parent.click(".//*[@class='btn btn-success confirm']")
        return True

    @catch_except
    def create_new_switch_alert(self, alert_name=''):
        """ Method to Create a New Alert. """
        self.click_alert()
        sleep(2)
        self.parent.click(".//*[@ng-click='createNewAlertPageFn()']")
        sleep(3)
        self.fill_alert_details(alert_name=str(alert_name))
        self.click_next()
        self.click_alert_create()
        self.parent.click(".//*[@class='btn btn-primary']")
        return True

    @catch_except
    def is_button_present(self, *buttons_list):
        """Method to check Buttons in the Page are present."""
        buttons = {
            'edit': str(".//*[@class='groupEditButton ng-scope']"),
            'delete': str(".//*[@class='groupDeleteButton ng-scope']")}
        result = dict()
        for button in buttons_list:
            xpath = buttons.get(button, "")
            self.parent.wait_till_delay(xpath, 10)
            result[button] = self.parent.is_element_present(xpath)
        return result
