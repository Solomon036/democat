"""
Module to perform operation and data extraction in Report Configuration page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/deviceconfig/reportingconfigpage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Report Configuration Page for Product Link Application.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """


from time import sleep
from lib.webinterface import catch_except


class ReportingConfig(object):
    """ Parent Class for the Reporting Config Page of Admin Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of Reporting Config page. """
        self.parent = parent
        self.admin = admin

    @catch_except
    def search_asset_in_device_config(self, assetname):
        """ Method to search the asset in Device Config. """
        self.admin.filter_asset(assetname)

    @catch_except
    def select_asset_to_configure(self, asset):
        """ Method to Select the asset to Configure in Reporting configuration page. """
        self.search_asset_in_device_config(asset)
        self.parent.wait_till_inactive_delay(".//*[@class='loadingIcon']")
        sleep(5)
        self.parent.click(".//*[@id='chkBox']")
        sleep(3)
        self.parent.click(".//*[@id='configureDevice']")
        sleep(5)

    @catch_except
    def select_asset_in_complex_to_configure(self, asset_name):
        """ Method to Select the Asset in Complex asset to configure. """
        self.search_asset_in_device_config(asset_name)
        self.parent.click(".//*[@class='leftBlock avatar_plus']")
        sleep(2)
        parent_element = self.parent.find_element_by_xpath(".//*[@id='{}']".format(asset_name))
        sleep(0.5)
        parent_element.find_element_by_xpath(".//*[@type='checkbox']").click()
        sleep(2)
        self.parent.click(".//*[@id='configureDevice']")
        sleep(5)
        return True

    @catch_except
    def configure_daily_report_time(self, reset=False, hours="06",
                                    minutes="00", time_zone="UTC+00:00"):
        """ Method to set the Daily Reporting time. """
        if reset:
            self.parent.click(".//*[@ng-model='DefaultTime.set']")
            sleep(2)
            return True
        self.parent.click(".//*[text()='Daily Report Time']")
        sleep(1)
        self.parent.click(".//*[@attrtochange='hour']")
        sleep(0.5)
        self.parent.click(".//*[@attrtochange='hour']/*[text()='{}']".format(hours))
        sleep(0.5)
        self.parent.click(".//*[@attrtochange='minute']")
        sleep(0.5)
        self.parent.click(".//*[@attrtochange='minute']/*[text()='{}']".format(minutes))
        sleep(0.5)
        self.parent.click(".//*[@attrtochange='zone']")
        sleep(0.5)
        self.parent.click(".//*[@attrtochange='zone']/*[contains(text(),'{}')]".format(time_zone))
        sleep(0.5)
        self.parent.click(".//*[@attrtochange='zone']/*[contains(text(),'{}')]".format(time_zone))
        sleep(0.5)
        return True

    @catch_except
    def configure_battery_voltage(self, batt_volt):
        """ Method to Configure the Battery Voltage in the Reporting configuration Page. """
        self.parent.click(".//*[text()='Battery Voltage Threshold']")
        sleep(1)
        self.parent.input(".//*[@ng-model='BVThreshold.voltage']", str(batt_volt))
        sleep(0.2)
        return True

    @catch_except
    def click_hours_config_section(self):
        """ Method to click the Hours config section. """
        status = self.parent.click(".//*[text()='Hour Meter']")
        sleep(2)
        return status

    @catch_except
    def configure_hours(self, hours_info):
        """ Method to configure the Hours information. """
        if self.click_hours_config_section():
            self.parent.input(".//*[@ng-model='newHourMeter.newHour']", str(hours_info))
            sleep(2)
            return True
        return False

    @catch_except
    def get_current_hour_meter_value(self):
        """ Method to get the current hour meter value. """
        hour_val = self.parent.get_value(".//*[@class='hoursStamp ng-binding']")
        reported_time = self.parent.get_value(".//*[@class='dataeTime ng-binding']")
        return [hour_val, reported_time]

    @catch_except
    def click_config_send(self):
        """ Method to Send the configured values in the Reporting Configuration. """
        self.parent.click(".//*[@ng-click='sendConfiguredData()']")
        sleep(2)
        self.parent.click_config_popup()
        sleep(5)
        return True

    @catch_except
    def click_config_popup(self, accept=True):
        """ Method to Click te Configuration Pop-Up. """
        if accept:
            self.parent.click('.//*[@ng-click="ok()"]')
        else:
            self.parent.click('.//*[@ng-click="cancel()"]')
        self.parent.clear_web_alerts()
        return True

    @catch_except
    def get_error_on_hour(self):
        """ Method to get the Error information in Hours Section. """
        return self.parent.get_value(".//*[@ng-if='hourComparedError']")

    @catch_except
    def get_error_on_batt(self):
        """ Method to get the Error information in Battery Section. """
        return self.parent.iselement_enabled(".//*[@ng-click='sendConfiguredData()']")

    @catch_except
    def get_device_configured_info(self, asset_name):
        """ Method to get the Reporting configuration information. """
        self.search_asset_in_device_config(asset_name)
        sleep(5)
        drt = self.parent.get_value(".//*[@ng-controller='dailyReportTimeController']").strip()
        sleep(0.2)
        batt_thershold = self.parent.get_value(".//*[@ng-if='data.batteryThreshold']").strip()
        sleep(0.2)
        hours = self.parent.get_value(".//*[@ng-controller='getAdjustedHoursInfoController']/div").strip()
        sleep(0.2)
        return [drt, batt_thershold, hours]

    @catch_except
    def is_status_active(self, asset_name):
        """ Method to get the Status infromation of the asset. """
        self.search_asset_in_device_config(asset_name)
        return self.parent.get_value(".//*[@class='statusCont']").text == ""

    @catch_except
    def get_status(self, asset_name):
        """Method to get the status of Daily Report Time, Battery Threshold & Hours"""
        self.search_asset_in_device_config(asset_name)
        drt_status = self.parent.get_value('.//*[@ng-controller="dailyReportTimeController"]/div[2]/div[2]')
        batt_status = self.parent.get_value('.//*[@ng-controller="batteryVoltageThresholdController"]/div[2]/div[2]')
        hours_status = self.parent.get_value('.//*[@ng-controller="getAdjustedHoursInfoController"]/div[2]/div[2]')
        return [drt_status, batt_status, hours_status]

    @catch_except
    def get_asset_list(self):
        """Method to get the list of assets in report configuration page"""
        class AssetList(object):
            """Class to hold the list of assets"""
            def __init__(self):
                self.equip_id = ''
                self.id = ''
                self.make = ''
                self.model = ''
                self.drt = ''
                self.battery = ''
                self.hours = ''
        data = []
        iterator = 1
        parent = self.parent.find_element_by_xpath('//*[@id="rowContainer"]/div/div[%s]' % iterator)
        asset_ids = (parent.find_elements_by_xpath('//*[@identifier="assetSN"]/div'))
        for index in range(0, len(asset_ids)):
            index = index + 1
            if asset_ids[index-1].is_displayed():
                asset_details = AssetList()
                asset_details.equip_id = parent.find_element_by_xpath('.//*[@inner-html-text="data.equipmentId"]').text
                asset_details.id = asset_ids[index-1].text
                asset_details.make = parent.find_element_by_xpath('//*[@identifier="make"]/div').text
                asset_details.model = parent.find_element_by_xpath('//*[@identifier="model"]/div').text
                asset_details.drt = parent.find_element_by_xpath('//*[@identifier="dailyReportTime"]/div/div/div').text
                asset_details.battery = self.parent.\
                    get_element_value_by_xpath_parent(parent, '//*[@identifier="batteryThreshold"]/div/div/div[1]')
                if not asset_details.battery:
                    asset_details.battery = ''
                asset_details.hours = parent.find_element_by_xpath('//*[@identifier="hours"]/div/div/div[1]').text
                iterator = iterator + 1
                data.append(asset_details)
                parent = self.parent.find_element_by_xpath('//*[@id="rowContainer"]/div/div[%s]' % iterator)
        return data
