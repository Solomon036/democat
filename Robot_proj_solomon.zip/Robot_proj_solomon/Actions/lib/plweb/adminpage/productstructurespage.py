"""
Module to perform operation and data extraction in Product Structures page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/productstructurespage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Product Structures Page for Product Link Application.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam.
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except


class ProductStructures(object):
    """ Parent Class for the Product Structures Page of Admin Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of Product Structures page. """
        self.parent = parent
        self.admin = admin

    @catch_except
    def manage_product_structures(self):
        """ Method to Manage the Product Structures. """
        self.parent.click(".//*[@id='pageHeader']/a[@href='#/ManageProductStructure']")
        sleep(2)
        self.parent.clear_web_alerts()
        sleep(3)

    @catch_except
    def create_product_strucutre(self):
        """ Method to Create the Product Structures. """
        self.parent.wait_till_delay(".//*[@ng-click='createProdPage()']")
        if not self.parent.iselement_enabled(".//*[@ng-click='createProdPage()']"):
            self.parent.admin.go_to_product_structure_page()
            self.parent.wait_till_delay(".//*[@ng-click='createProdPage()']")
        self.parent.click(".//*[@ng-click='createProdPage()']")
        self.parent.wait_till_delay(".//*[@class='loadingIcon']")
        sleep(5)
        return True

    @catch_except
    def select_prodstruct_asset_type(self, asset_type=""):
        """ Method to select Asset type for the Product Structures. """
        self.parent.click(".//*[@ng-model='assetTypeName']/option[text()='{}']".format(asset_type))
        sleep(2)
        return True

    @catch_except
    def select_prodstruct_icon(self):
        """ Method to select the Icon. """
        self.parent.click(".//*[@ng-model='assetIconImage']")
        sleep(5)
        self.parent.click(".//*[text()='General']")
        sleep(1)
        self.parent.click(".//*[@class='iconImage']")
        sleep(1)
        self.parent.click(".//*[@ng-click='ok()']")
        sleep(2)

    @catch_except
    def enter_prodstruct_prodid(self, prod_id):
        """ Method to enter the ProductID for the Product structures. """
        self.parent.input(".//*[@id='prodId']", prod_id)
        sleep(1)

    @catch_except
    def enter_prodstruct_prodfamily(self, prod_family):
        """ Method to enter the Product Family. """
        self.parent.input(".//*[@id='prodFamily']", prod_family)
        sleep(1)

    @catch_except
    def enter_prodstruct_serialnum(self, serial_num):
        """ Method to enter the Serial. """
        self.parent.input(".//*[@id='serialNum']", serial_num)
        sleep(1)

    @catch_except
    def enter_prodstruct_model(self, model):
        """ Method to enter the Model. """
        self.parent.input(".//*[@id='ModelC']", model)
        sleep(1)

    @catch_except
    def enter_prodstruct_manufacturer(self, manu_fact):
        """ Method to enter the Manufacturer. """
        self.parent.input(".//*[@id='Manufact']", manu_fact)
        sleep(1)

    @catch_except
    def go_to_prodstruct_next(self):
        """ Method to click the Next button. """
        self.parent.click(".//*[text()='Next>>']")
        sleep(3)

    @catch_except
    def set_prodstruct_asset_master(self, asset_name, master=True):
        """ Method to set the Asset in product structure as Master.
        If the master is True, asset will be set to Master asset else it will set to Slave. """
        parent_element = self.parent.find_element_by_xpath(".//*[@id = 'selectedEquipmentSection']")
        child_element = parent_element.find_element_by_xpath(".//*[@class='selectedAssets']")
        search_element = child_element.find_element_by_xpath(".//*[@ng-model='searchText']")
        search_element.clear()
        sleep(0.25)
        search_element.send_keys(asset_name)
        sleep(2)
        if master:
            self.parent.click(".//*[@title='Click to switch master asset']")
        else:
            self.parent.click(".//*[@title='Master asset']")
        sleep(5)
        return True

    @catch_except
    def click_prodstruct_create(self):
        """ Method to click Create button. """
        self.parent.click('//*[@id="pageNavigatorsTop"]//*[@id="rightSideNav"]/button[3]')
        sleep(2)
        self.parent.wait_till_delay('//*[@id="pageNavigatorsTop"]//*[@id="rightSideNav"]/button[3]')
        sleep(2)

    @catch_except
    def click_prodstruct_save(self):
        """ Method to click the Save. """
        self.parent.click(".//*[@ng-click='updateSelectedComplexAsset()']")
        sleep(5)
        self.parent.wait_till_delay(".//*[@ng-click='createProdPage()']")
        sleep(2)

    @catch_except
    def confirm_product_structure_creation(self, serial_num, prod_id):
        """ Method to confirm the Product Structure. """
        class ProdStruct(object):
            """ Class to hold the product structure data. """
            def __init__(self):
                self.name = None
                self.number = None
        prodinfo = ProdStruct()
        self.search_complex_asset_in_product_page(serial_num)
        elements = self.parent.driver.find_elements_by_xpath('.//*[@ng-if="group"]')
        for ele in elements:
            if prod_id in self.parent.get_value_by_element(ele):
                prodinfo.name = self.parent.\
                    get_value_by_element(self.parent.find_element_by_xpath_with_parent(ele,
                                                                                       ".//*[@ng-if='group.equipmentId']"))
                prodinfo.number = self.parent.get_value_by_element(self.parent.
                                                                   find_element_by_xpath_with_parent(ele,
                                                                                                     ".//*[@class='serial ng-binding ng-scope']"))
                local_info = prodinfo.number.splitlines()[0].split(' ')
                prodinfo.number = local_info[2]
                sleep(5)
        return prodinfo

    @catch_except
    def generate_product_structure(self, assets, master_asset=None, asset_type=None,
                                   prod_id='Auto_Default', serial_num='Default_SN_manu',
                                   manufact='cat', prod_family='', model=''):
        """ Overall method to Create the Product Structure. """
        self.create_product_strucutre()
        sleep(1)
        self.select_prodstruct_asset_type(asset_type)
        self.select_prodstruct_icon()
        self.enter_prodstruct_prodid(prod_id)
        self.enter_prodstruct_serialnum(serial_num)
        self.enter_prodstruct_manufacturer(manufact)
        self.enter_prodstruct_prodfamily(prod_family)
        self.enter_prodstruct_model(model)
        sleep(2)
        self.go_to_prodstruct_next()
        sleep(2)
        self.select_assets_ps(assets)
        sleep(2)
        if master_asset:
            self.set_prodstruct_asset_master(master_asset)
            sleep(1)
        self.go_to_prodstruct_next()
        sleep(1)
        self.click_prodstruct_create()
        sleep(1)
        self.parent.clear_web_alerts()
        self.parent.wait_till_delay('.//*[@ng-click="createProdPage()"]')
        return True

    @catch_except
    def delete_product_structure(self, serial_num):
        """ Method to Delete the complex asset. """
        self.search_complex_asset_in_product_page(serial_num)
        self.parent.click(".//*[@class='groupDeleteButton ng-scope']")
        sleep(3)
        self.parent.clear_web_alerts()
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(10)
        return True

    @catch_except
    def edit_product_structure(self, serial_num):
        """ Method to Edit the product structures. """
        self.search_complex_asset_in_product_page(serial_num)
        self.parent.click(".//*[@ng-click='editRecord($event,group)']")
        self.parent.wait_till_delay(".//*[@ng-click='generateSelectedAssets()']")
        sleep(3)

    @catch_except
    def search_complex_asset_in_product_page(self, serial_num):
        """ Method to Search the complex asset. """
        self.parent.input('.//*[@ng-model="search.key"]', serial_num)
        sleep(10)
        return True

    @catch_except
    def is_product_structures_present(self, prod_struct_name, asset):
        """ Method to verify whether the Complex asset is present or not. """
        self.search_complex_asset_in_product_page(asset)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            for _ in range(3):
                element.clear()
                sleep(0.2)
                for i in asset:
                    element.send_keys(i)
                    sleep(0.2)
                sleep(10)
            if prod_struct_name in element.text:
                return True
        return False

    @catch_except
    def filter_asset_ps(self, assetname):
        """ Method to Filter the asset in Select equipment pane """
        element = self.parent.find_element_by_xpath('//*[@ng-if="gridData"]//*[@id="searchInputCCat"]')
        self.parent.scroll_to_view_element(element)
        for _ in range(2):
            element.clear()
            sleep(0.2)
            for i in assetname:
                element.send_keys(i)
                sleep(0.2)
            sleep(2)
        return True

    @catch_except
    def select_assets_ps(self, asset_name):
        """ Method to select the Asset(s) in Select equipment Pane. """
        if isinstance(asset_name, list):
            for asset in asset_name:
                self.filter_asset_ps(asset)
                sleep(0.5)
                self.parent.click("//*[@inner-html-text='data[val.attribute]']")
                sleep(0.5)
                self.parent.click('.//*[@onclick="window.customConfirm.ok()"]')
                sleep(1)
        else:
            self.filter_asset_ps(asset_name)
            sleep(0.5)
            self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
            sleep(0.7)
            self.parent.click('.//*[@onclick="window.customConfirm.ok()"]')
            sleep(1)

    @catch_except
    def get_product_struct_info(self, assetname):
        """ Method to Get Product Structure details """

        class ProdDetails(object):
            """ Class to hold the product details data of Product structure """
            def __init__(self):
                self.prodid = None
                self.serialnum = None
                self.manufacturer = None
                self.prodfamily = None
                self.model = None
                self.icon = None

        proddetails = ProdDetails()
        self.search_complex_asset_in_product_page(assetname)
        self.edit_product_structure(assetname)
        self.go_to_prodstruct_next()
        self.go_to_prodstruct_next()
        sleep(5)
        proddetails.prodid = self.parent.get_value('//*[@id="PsProdIdValue"]')
        proddetails.serialnum = self.parent.get_value('//*[@id="PsSerNumValue"]')
        proddetails.manufacturer = self.parent.get_value('//*[@id="PsManuFactValue"]')
        proddetails.prodfamily = self.parent.get_value('//*[@id="PsProdFamilyValue"]')
        proddetails.model = self.parent.get_value('//*[@id="PsModelValue"]')
        proddetails.icon = self.parent.get_attribute_value('//*[@id="PsAssetIcon"]/div[2]', 'style')
        sleep(5)
        return proddetails

    @catch_except
    def edit_prodstruct_icon(self):
        """ Method to select the Icon. """
        self.parent.click(".//*[@ng-model='assetIconImage']")
        sleep(5)
        self.parent.click(".//*[text()='Custom']")
        sleep(1)
        self.parent.click(".//*[@class='iconImage']")
        sleep(1)
        self.parent.click(".//*[@ng-click='ok()']")
        sleep(2)

    @catch_except
    def get_prodstruct_icon(self):
        """ Method to get the icon xpath """
        icon = self.parent.get_attribute_value('//*[@id="prodAssetIcon"]/div/div[2]', 'style')
        sleep(2)
        return icon

    @catch_except
    def validate_prodstruct_asset_type_edit(self):
        """ Method to select Asset type for the Product Structures. """
        status = self.parent.click(".//*[@ng-model='assetTypeName']/option[text()='{}']")
        sleep(2)
        if not status:
            return True

    @catch_except
    def retrieve_asset(self):
        """Method to retreive asset in a complex asset"""
        self.parent.click('//*[@class="pull-right accordionicon ng-scope accordionDown"]')
        sleep(10)
        asset_list = []
        for item in range(1, 6):
            element = self.parent.get_value('//*[@class="bodyContents"]/div[%s]/div/div[2]'%item)
            sleep(2)
            if element is False:
                break
            asset_list.append(element)
        return asset_list


    @catch_except
    def get_asset_details(self, assetname):
        """Method to retreive asset details in a complex asset for a single asset"""
        class AssetDetails(object):
            """ Class to hold the product details data of Product structure """
            def __init__(self):
                self.eq_id = None
                self.serialnum = None
                self.make = None
                self.model = None
        self.search_complex_asset_in_product_page(assetname)
        self.parent.click('//*[@class="pull-right accordionicon ng-scope accordionDown"]')

        assetdetails = AssetDetails()
        assetdetails.eq_id = self.parent.get_value('//*[@class="bodyContents"]/div/div/div[1]/div')
        assetdetails.serialnum = self.parent.get_value('//*[@class="bodyContents"]/div/div/div[2]')
        assetdetails.make = self.parent.get_value('//*[@class="bodyContents"]/div/div/div[3]')
        assetdetails.model = self.parent.get_value('//*[@class="bodyContents"]/div/div/div[4]')
        sleep(10)
        return assetdetails

    @catch_except
    def validate_manage_ps(self):
        """ Method to validate manage product structures"""
        val = self.parent.get_value('//*[@id="breadcrumbs"]')
        return val

    @catch_except
    def cancel_button(self):
        """"Method to click on Cancel Button"""
        self.parent.click('//*[@id="pageNavigatorsTop"]//*[contains(text(), "Cancel")]')
        sleep(2)
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(10)

    @catch_except
    def click_cancel_button(self):
        """ Method to validate manage product structures"""
        self.parent.click(".//*[@ng-click='setBackToProManageGroups()']")
        sleep(1)
        self.parent.click('.//*[@class="btn btn-success confirm"]')
        self.parent.wait_till_delay(".//*[@ng-click='createProdPage()']")
        return self.parent.iselement_enabled(".//*[@ng-click='createProdPage()']")
