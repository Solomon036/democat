"""
Module to perform operation and data extraction in Report Wizard page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/reportwizardpage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Report Wizard Page for Product Link Application.
# **
# ** AUTHOR:
# **     Mani Shankar Venkatachalam
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """


from time import sleep
from lib.webinterface import catch_except


class ReportWizard(object):
    """ Parent class for Report Wizard Page. """
    def __init__(self, parent, admin):
        self.parent = parent
        self.admin = admin

    @catch_except
    def click_create_report(self):
        """ Method to Click Create button for Report Wizard. """
        self.parent.click(".//*[text()='Create Reports']")
        self.parent.wait_till_delay(".//*[@ng-model='reportName']", 5)
        sleep(5)

    @catch_except
    def enter_report_name(self, report_name):
        """ Method to Enter the Report Name. """
        self.parent.input(".//*[@ng-model='reportName']", report_name)
        sleep(2)

    @catch_except
    def select_report_type(self, report_type):
        """ Method to Select the Report Type. """
        element_list = self.parent.driver.find_elements_by_xpath(".//*[@class='list-group']")
        report_type_element = element_list[0]
        report_type_dict = {"Fleet": ".//*[text()='Fleet']",
                            "Data Viz": ".//*[text()='Data Visualization']",
                            "KPI": ".//*[text()='Key Performance Indicator']",
                            "EquipmentDetails": ".//*[text()='Equipment Details']"}
        if report_type.lower() == "all":
            for rep_type in report_type_dict:
                report_type_element.find_element_by_xpath(report_type_dict[rep_type]).click()
                sleep(1)
        else:
            report_type_element.find_element_by_xpath(report_type_dict[report_type]).click()
        sleep(3)

    @catch_except
    def select_fleet_parameters(self, para_type):
        """ Method to Select the Fleet Parameters in Report Wizard. """
        parameter_types_dict = {"Alerts": ".//*[@id='Alerts']",
                                "Fault Codes": ".//*[@id='Fault Codes']",
                                "Operation History": ".//*[@id='Operations History']",
                                "Summary": ".//*[@id='Summary']",
                                "Utilization": ".//*[@id='Utilization']"}
        element_list = self.parent.driver.find_elements_by_xpath(".//*[@class='list-group']")
        report_type_element = element_list[1]
        if para_type.lower() == "all":
            for rep_type in parameter_types_dict:
                report_type_element.find_element_by_xpath(parameter_types_dict[rep_type]).click()
                sleep(1)
        else:
            report_type_element.find_element_by_xpath(parameter_types_dict[para_type]).click()
        sleep(3)

    @catch_except
    def select_equipdetails_parameters(self, para_type):
        """ Method to Select the Equipment Details Parameter in Report Wizard. """
        parameter_types_dict = {"Alerts": ".//*[@id='Alerts']",
                                "Fault Codes": ".//*[@id='Fault Codes']",
                                "Fuel": ".//*[@id='Fuel']",
                                "Power": ".//*[@id='Power']",
                                "Tracking Points": ".//*[@id='Tracking Points']"}
        element_list = self.parent.find_elements_by_xpath(".//*[@class='list-group']")
        report_type_element = element_list[1]
        if para_type.lower() == "all":
            for rep_type in parameter_types_dict:
                report_type_element.find_element_by_xpath(parameter_types_dict[rep_type]).click()
                sleep(1)
        else:
            report_type_element.find_element_by_xpath(parameter_types_dict[para_type]).click()
        sleep(3)

    @catch_except
    def select_data_viz_chart_report(self, wiz_report_name):
        """ Select the Data Vizualization Chart for Report. """
        self.parent.click(".//*[@id='{}']".format(wiz_report_name))
        sleep(2)

    @catch_except
    def select_data_kpi_chart_report(self, wiz_report_name):
        """ Select the KPI for Report Wizard. """
        self.parent.click(".//*[@id='{}']".format(wiz_report_name))
        sleep(2)


    @catch_except
    def select_reporting_schedule(self, sch_type):
        """ Method to Select the Reporting Schedule.\n
        Schedule type will be of : Daily, Weekly, Monthly, One Time.
        """
        sch_type_dict = {"Daily": ".//*[@value='Daily']",
                         "Weekly": ".//*[@value='Weekly']",
                         "Monthly": ".//*[@value='Monthly']",
                         "One Time": ".//*[@value='One Time']"}
        self.parent.click(sch_type_dict[sch_type])
        sleep(3)

    @catch_except
    def set_reporting_time(self, hours, minutes):
        """ Method to Set the Reporting Time for Report Wizard. """
        self.parent.click(".//*[@id='timepickerPopOverButton']")
        sleep(1)
        self.parent.input(".//*[@ng-model='hours']", hours)
        sleep(1)
        self.parent.input(".//*[@ng-model='minutes']", minutes)
        sleep(1)
        self.parent.click(".//*[text()='Ok']")
        sleep(2)

    @catch_except
    def select_week_day(self, day="Wednesday"):
        """ Method to Select the Week Day in Report Wizard. \n
        By Default "Wednesday" will be selected.
        """
        self.parent.click(".//*[@value='{}']".format(day))
        sleep(2)

    @catch_except
    def select_month_status(self, month_behaviour, date_behaviour=''):
        """ Method to Select the Month Status. \n
        Parameters: Every First Day of the month, Every Mid Day of the month, \n
        Every Last Day of the month, Every Month on the
        """
        self.parent.click(".//*[@class='caret']")
        sleep(2)
        self.parent.click(".//*[text()='{}']".format(month_behaviour))
        sleep(2)
        if date_behaviour != '':
            self.parent.click(".//*[@value='{}']".format(date_behaviour))
            sleep(2)

    @catch_except
    def enter_report_info(self, subject_value, generated_by, report_msg):
        """ Method to Enter the Report Information like Subject, Generated by, Report Message. """
        self.parent.driver.execute_script('window.scrollTo(0, 50);')
        sleep(2)
        self.parent.input(".//*[@ng-model='subject']", subject_value)
        sleep(1)
        self.parent.input(".//*[@ng-model='gerneratedBy']", generated_by)
        sleep(1)
        self.parent.input(".//*[@ng-model='reportMessage']", report_msg)
        sleep(1)
        self.parent.driver.execute_script('window.scrollTo(0, 0);')
        sleep(1)

    @catch_except
    def enter_recipient_details(self, name, email_id):
        """ Method to Enter the Recipient Details. """
        self.parent.input(".//*[@ng-model="
                          "'recipient.recipientName']", name)
        sleep(2)
        self.parent.input(".//*[@ng-model="
                          "'recipient.recipientEmailID']", email_id)
        sleep(1)
        self.parent.click(".//*[@ng-click='add(recipient)']")
        sleep(2)
        self.parent.click(".//*[@ng-click='update(recipient)']")
        sleep(2)

    @catch_except
    def edit_recipient(self):
        """ Method to Edit the Recipient"""
        self.parent.click(".//*[@ng-click='edit(_recipient,$index)']")
        sleep(2)

    @catch_except
    def delete_recipient(self):
        """ Method to Delete the Recipient. """
        self.parent.click(".//*[@ng-click='delete($index)']")
        sleep(2)
        self.parent.click(".//*[@onclick='window.customConfirm.ok()']")
        sleep(2)

    @catch_except
    def select_dash_board_data_wiz(self, dash_board_name):
        """ Method to Select the Dash Board Data Wizard. """
        self.parent.click(".//*[@id='{}']".format(dash_board_name))
        sleep(2)

    @catch_except
    def create_report_wiz(self):
        """ Method to Click final create Report Wizard. """
        self.parent.click(".//*[@ng-click='multiPageConfig.onCreateBtn();']")
        sleep(15)
        self.parent.click(".//*[@onclick='window.customAlert.ok()']")
        sleep(2)

    @catch_except
    def select_assets_in_report_wiz(self, asset_name):
        """ Method to Select the asset(s) for reporting. """
        self.parent.select_assets(asset_name)

    @catch_except
    def next_button(self):
        """Method to click on next button in Admin-> Report Wizard page"""
        self.parent.click('//*[@id="wizardFooterTop"]//*[contains(text(), "Next")]')
        sleep(2)
