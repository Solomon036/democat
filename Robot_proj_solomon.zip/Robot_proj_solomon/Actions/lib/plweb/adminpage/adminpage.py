"""
Module to perform operation and data extraction in Admin Page.
"""
# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/adminpage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Admin Page for Product Link Application.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except
from lib.plweb.adminpage.alertpage import AlertPage
from lib.plweb.adminpage.groupspage import GroupsPage
from lib.plweb.adminpage.geoboundariespage import GeoBoundaries
from lib.plweb.adminpage.productstructurespage import ProductStructures
from lib.plweb.adminpage.viewassignment import ViewAssignment
from lib.plweb.adminpage.reportwizardpage import ReportWizard
from lib.plweb.adminpage.deviceconfig.reportingconfigpage import ReportingConfig
from lib.plweb.adminpage.deviceconfig.configmanagepage import ConfigManage
from lib.plweb.adminpage.deviceconfig.switchconfigpage import SwitchConfig


class AdminPage(object):
    """ Parent Class for Admin Page. """
    def __init__(self, plweb_handle):
        """ Method to initialize the instance of Admin Page. """
        self.parent = plweb_handle
        self.alertpage = AlertPage(self.parent, self)
        self.geoboundariespage = GeoBoundaries(self.parent, self)
        self.groupspage = GroupsPage(self.parent, self)
        self.prodstructpage = ProductStructures(self.parent, self)
        self.viewassignment = ViewAssignment(self.parent, self)
        self.reportconfigpage = ReportingConfig(self.parent, self)
        self.configmanagepage = ConfigManage(self.parent, self)
        self.switchconfigpage = SwitchConfig(self.parent, self)
        self.reportwizardpage = ReportWizard(self.parent, self)
        self.switch_slot = 0

    @catch_except
    def go_to_admin_page(self):
        """ Method to go to Admin Page. """
        self.switch_slot = 0
        self.parent.click('.//*[@id="navlist"]/li[4]/a')
        sleep(2)
        self.parent.click(".//*[@ng-href='#/GeoBoundaries']")
        self.parent.wait_till_delay('.//*[@ng-click="createGeoBoundaryFooterOptions.'
                                    'closeClickHandler()"]')
        sleep(1)

    @catch_except
    def go_to_view_assignment_page(self):
        """ Method to go to View Assignment. """
        self.parent.click('.//*[@id="navlist"]/li[4]/a')
        sleep(2)
        self.parent.jclick(".//*[@ng-href='#/manageViewAssignment']")
        self.parent.wait_till_delay(".//*[@ng-click='createViewAssignmentPage()']", 30)
        return self.parent.is_displayed(".//*[@ng-click='createViewAssignmentPage()']")

    @catch_except
    def go_to_alert_rule_page(self):
        """ Method to go to Alert Rule Page. """
        if self.parent.get_admin_url:
            self.parent.enter_url(self.parent.get_admin_url)
        self.parent.click('.//*[@id="navlist"]/li[4]/a')
        sleep(1.5)
        self.parent.click(".//*[@ng-href='#/manageAlertRule']")
        sleep(5)
        return True

    @catch_except
    def go_to_device_configuration(self):
        """ Method to go to Device Configuration Page. """
        self.parent.go_to_home_page()
        self.parent.enter_url(self.parent.base_url + '#/reportingConfiguration')
        sleep(2)
        return True

    @catch_except
    def go_to_configuration_manager(self):
        """ Method to go to Device Configuration Page. """
        self.parent.go_to_home_page()
        self.parent.enter_url(self.parent.base_url + '#/CustomConfiguration')
        sleep(2)
        return True

    @catch_except
    def go_to_reporting_configuration(self):
        """ Method to go to Reporting Configuraiton. """
        self.go_to_device_configuration()
        sleep(5)

    @catch_except
    def go_to_product_structure_page(self):
        """ Method to go to Product Structure Page. """
        if self.parent.get_admin_url:
            self.parent.enter_url(self.parent.get_admin_url)
            sleep(5)
        self.parent.click('//*[@id="navlist"]/li[4]/a')
        sleep(1)
        self.parent.click(".//*[@ng-href='#/ManageProductStructure']")
        sleep(5)
        return True

    @catch_except
    def go_to_switch_configuration(self):
        """ Method to go to Switch Configuration Page. """
        self.parent.enter_url(self.parent.base_url + '#/SwitchConfiguration')
        sleep(5)
        return True

    @catch_except
    def go_to_group_page(self):
        """ Method to go to Group Page. """
        self.parent.click('.//*[@id="navlist"]/li[4]/a')
        sleep(2)
        self.parent.click(".//*[@ng-href='#/manageview']")
        return True

    @catch_except
    def go_to_report_wizard(self):
        """ Method to go to Report Wizard Page."""
        self.parent.click('.//*[@id="navlist"]/li[4]/a')
        sleep(1)
        self.parent.click(".//*[@ng-href='#/ReportWizard']")
        self.parent.wait_till_delay(".//*[text()='Create Reports']", 5)
        return True

    @catch_except
    def remove_selected_assets(self, asset_name):
        """ Method to Remove the Selected Assets based on the Asset Name provided. """
        parent_element = self.parent.find_element_by_xpath(".//*[@id = 'selectedEquipmentSection']")
        child_element = parent_element.find_element_by_xpath(".//*[@class='selectedAssets']")
        search_element = child_element.find_element_by_xpath(".//*[@ng-model='searchText']")
        search_element.clear()
        sleep(0.25)
        search_element.send_keys(asset_name)
        sleep(3)
        click_element = child_element.\
            find_element_by_xpath(".//*[@ng-click='options.rowClickCallBackFun($event,data);']")
        sleep(3)
        click_element.click()
        sleep(1)
        search_element.clear()

    @catch_except
    def alert_popup_text(self):
        """ Method to get the Alert Popup text. """
        if self.parent.is_displayed(".//*[@style='display: block;']"):
            alert_text = self.parent.get_value(".//*[@id='customAlert']/div[2]")
        else:
            alert_text = None
        return alert_text

    @catch_except
    def confirm_popup_text(self):
        """ Method to Confirm the pop-up text. """
        if self.parent.is_displayed(".//*[@style='display: block;']"):
            alert_text = self.parent.get_value(".//*[@id='customConfirm']/div[2]")
        else:
            alert_text = None
        return alert_text

    @catch_except
    def confirm_popup_click(self, yes_no=''):
        """ Method to Confirm Pop-up Click. """
        if self.parent.is_displayed(".//*[@style='display: block;']"):
            if yes_no == 'Yes':
                self.parent.click(".//*[@class='btn btn-success confirm']")
            elif yes_no == 'No':
                self.parent.click(".//*[@class='btn btn-danger cancel']")

    @catch_except
    def filter_asset(self, assetname):
        """ Method to Filter the asset. """
        element = self.parent.find_element_by_xpath(".//*[@ng-model='searchText']")
        self.parent.scroll_to_view_element(element)
        for _ in range(2):
            element.clear()
            sleep(0.2)
            for i in assetname:
                element.send_keys(i)
                sleep(0.2)
            sleep(2)
        return True

    @catch_except
    def click_configure(self):
        """ Method to Click Configure."""
        self.parent.click(".//*[@class='configureBtnDiv "
                          "configureBtnDivPadding']")
        sleep(5)

    @catch_except
    def expand_complex_asset(self):
        """ Method to Expand the Complex Asset. """
        self.parent.click(".//*[contains(@class,'avatar_plus')]")
        sleep(1)

    @catch_except
    def select_assets(self, asset_name):
        """ Method to select the Asset(s). """
        if isinstance(asset_name, list):
            for asset in asset_name:
                self.filter_asset(asset)
                sleep(0.2)
                self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
                sleep(0.05)
        else:
            self.filter_asset(asset_name)
            sleep(0.2)
            self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
            sleep(0.5)

    @catch_except
    def select_standalone_in_complex_asset(self, asset_name):
        """ Method to Select the Standalone asset in Complex asset. """
        if isinstance(asset_name, list):
            for asset in asset_name:
                self.filter_asset(asset)
                sleep(2)
                self.parent.find_element_by_xpath(".//*[contains(@class,"
                                                  "'avatar_plus')]").click()
                sleep(2)
                parent_element = self.parent.\
                    find_element_by_xpath(".//*[@id='{}CAT']".format(asset))
                parent_element.\
                    find_element_by_xpath(".//*[text()='{}']".format(asset)).click()
                sleep(2)
        else:
            self.filter_asset(asset_name)
            sleep(2)
            self.parent.\
                find_element_by_xpath(".//*[contains(@class,'avatar_plus')]").click()
            sleep(2)
            parent_element = self.parent.\
                find_element_by_xpath(".//*[@id='{}CAT']".format(asset_name))
            parent_element.\
                find_element_by_xpath(".//*[text()='{}']".format(asset_name)).click()
            sleep(2)

    @catch_except
    def modify_SMH_hours(self, asset_name):
        """ Method to Select the Standalone asset in Complex asset. """
        self.parent.input(".//*[@ng-model='searchText']", asset_name)
        sleep(5)
        self.parent.click(".//*[contains(@id,'"+asset_name+"')]//child::input[@type='checkbox']")
        self.parent.click(".//*[contains(text(),'Configure')]")
        sleep(3)
        self.parent.click(".//*[@class='leftPanel']//*[contains(text(),'SMHHours')]")
        self.parent.input(".//*[@class='inputBVT']//input[contains(@type,'text')]", asset_name)


