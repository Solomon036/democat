"""
Module to perform operation and data extraction in Alert Rule page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/alertpage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Alert Page for Product Link Application.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

from time import sleep
from lib.webinterface import catch_except
from lib.plweb.adminpage import or_adminpage


class AlertPage(object):
    """ Parent Class for the Alerts Page of Admin Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of alerts page. """
        self.parent = parent
        self.admin = admin

    @catch_except
    def verify_clone(self, asset, alert_name):
        status = False
        self.parent.driver.refresh()
        self.admin.go_to_alert_rule_page()
        self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        sleep(3)
        try:
            for i in range(0, 5):
                try:
                    sleep(1)
                    count = len(self.parent.driver.find_elements_by_xpath(
                        "//*[@id='accordionControllerContainer']/accordion/div/div[*]/div[1]/h4/a/div[1]/i"))
                    self.parent.find_element_by_xpath(
                        "//*[@id='accordionControllerContainer']/accordion/div/div[" + str(count) + "]/div[1]/h4/a/div[1]/i")
                except:
                    pass
        except:
            pass
        sleep(5)
        if self.parent.is_displayed(or_adminpage.BTN_ARROW.replace("#", alert_name)):
            status = True
        return status


    @catch_except
    def other_user_search_existing_alert_rules(self, clone, existing_alert, alert_rule_name='',
                                rule_type = '', asset=None, arg=None, is_complex=False):

        """"Methods to search the existing alert rules and cloning the alert rule
        clone (String) >> this argument to provide the clone name
        existing_alert (String) >> this argument to find the existing alert for the Alert rules
        alert_rule_name (String) >> Type of rule e.g : contacts
        rule_type (String) >> Alert code e.g : Fault Codes
        asset (String) >> asset name
        arg (String) >> level of alert
        """
        status = False
        edit = True
        delete = True
        verify_edit = "Edit - Available"
        verify_delete = "Delete - Available"
        if not asset:
            asset = list()
        if not arg:
            arg = list()
        self.parent.driver.refresh()
        sleep(8)
        self.admin.go_to_alert_rule_page()
        self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        sleep(5)
        if self.parent.is_displayed(or_adminpage.BTN_EDIT.replace("#", existing_alert)):
            edit = False
        else:
            verify_edit = " ' -- Verified - Edit option is not available --' "
        if self.parent.is_displayed(or_adminpage.BTN_DELETE.replace("#", existing_alert)):
            delete = False
        else:
            verify_delete = " ' -- Verified - Delete option is not available -- ' "
        if edit and delete:
            status = True
        verification = [verify_edit,verify_delete]
        return [status, verification]

    @catch_except
    def search_existing_alert_rules(self, clone, existing_alert, alert_rule_name='',
                                rule_type='', asset=None, arg=None, is_complex=False):
        """"Methods to search the existing alert rules and cloning the alert rule

        clone (String) >> this argument to provide the clone name
        existing_alert (String) >> this argument to find the existing alert for the Alert rules
        alert_rule_name (String) >> Type of rule e.g : contacts
        rule_type (String) >> Alert code e.g : Fault Codes
        asset (String) >> asset name
        arg (String) >> level of alert
        """
        status = False
        contact_status = False
        equipment_status = False
        contact = "Contact - Not Available"
        equipment = "equipment - Not Available"
        try:
            if not arg:
                arg = list()
            self.parent.driver.refresh()
            sleep(8)
            self.admin.go_to_alert_rule_page()
            self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
            try:
                for i in range(0, 5):
                    sleep(1)
                    count = len(self.parent.driver.find_elements_by_xpath(
                        "//*[@id='accordionControllerContainer']/accordion/div/div[*]/div[1]/h4/a/div[1]/i"))
                    self.parent.find_element_by_xpath(
                        "//*[@id='accordionControllerContainer']/accordion/div/div[" + str(
                            count) + "]/div[1]/h4/a/div[1]/i")
            except:
                pass
            sleep(5)
            self.parent.click(or_adminpage.BTN_ARROW.replace("#", existing_alert))
            sleep(3)
            if clone == "contact":
                self.parent.click(or_adminpage.CHK_BX_CONTACTS)
                self.parent.click(or_adminpage.BTN_CLONE)
            if clone == "equipment":
                self.parent.click(or_adminpage.CHK_BX_EQUIP)
                self.parent.click(or_adminpage.BTN_CLONE)
            if clone == "both":
                self.parent.click(or_adminpage.CHK_BX_CONTACTS)
                self.parent.click(or_adminpage.CHK_BX_EQUIP)
                self.parent.click(or_adminpage.BTN_CLONE)
            sleep(5)
            self.enter_alert_rule_name(alert_rule_name)
            sleep(3)
            if self.select_alert_type(rule_type):
                if rule_type.lower() == 'fault codes':
                    self.select_fault_code_severity(*arg)
                elif rule_type.lower() == 'geo boundary':
                    self.select_geo_boundary(*arg)
                elif rule_type.lower() == 'engine status':
                    self.select_engine_status(*arg)
                elif rule_type.lower() == 'device status':
                    self.select_device_status(*arg)
                elif rule_type.lower() == 'battery voltage':
                    self.select_battery_voltage()
                elif rule_type.lower() == 'power loss':
                    self.select_power_loss(*arg)
                elif rule_type.lower() == 'low fuel level':
                    self.select_low_fuel_alert()
                self.click_next()
                sleep(2)
                self.parent.wait_till_delay(".//*[@ng-model='searchText']")
                self.parent.wait_till_inactive_delay(".//*[@class='loadingIconCls']", 45)
                if is_complex:
                    self.select_complex_assets_in_alert_rule_and_confirm(asset)
                else:
                    self.select_assets_in_alert_rule(asset)
                sleep(7)
                if clone == "equipment" or clone == "both":
                    if self.parent.is_displayed(or_adminpage.ELE_EQUIP.replace("#", str(asset))):
                        equipment = "Equipment Alert"
                        equipment_status = True
                self.click_next()
                sleep(2)
                if clone == "contact" or clone == "both":
                    if self.parent.is_displayed(or_adminpage.ELE_CONTACT.replace("#", existing_alert)):
                        contact = "Contact Alert"
                        contact_status = True
                sleep(1)
                self.click_next()
                sleep(1)
                self.click_alert_create()
                self.parent.wait_till_delay(".//*[@ng-click="
                                            "'callAlertCreate()']", 60)
                if clone == "both":
                    if contact_status and equipment_status:
                        status = True
                if clone == "contact":
                    if contact_status:
                        status = True
                if clone == "equipment":
                    if equipment_status:
                        status = True
                clone_status = [contact, equipment]
        except:
            clone_status = [contact, equipment]
            return [status, clone_status]
        return [status, clone_status]

    @catch_except
    def manage_alert_rule_click(self):
        """ Method to Click the Manage Alert Rule Button. """
        self.parent.wait_till_delay('.//*[@ng-if="alertBtnVisibility.manageAlertBtn"]')
        self.parent.click('.//*[@ng-if="alertBtnVisibility.manageAlertBtn"]')
        sleep(2)
        self.parent.click(".//*[@onclick='window.customConfirm.ok()']")
        sleep(5)
        return True

    @catch_except
    def create_alert_rule(self):
        """ Method to Click a Create alert rule button. """
        self.parent.wait_till_delay(".//*[@ng-click='callAlertCreate()']")
        sleep(5)
        if not self.parent.iselement_enabled(".//*[@ng-click='callAlertCreate()']"):
            self.admin.go_to_alert_rule_page()
            self.parent.wait_till_delay(".//*[@ng-click='callAlertCreate()']")
        self.parent.click(".//*[@ng-click='callAlertCreate()']")
        self.parent.wait_till_delay(".//*[@id='entrAlertName']")
        sleep(2)
        return True

    @catch_except
    def enter_alert_rule_name(self, alert_name):
        """ Method to Enter the Alert Rule Name. """
        self.parent.input(".//*[@id='entrAlertName']", alert_name)
        sleep(0.5)
        return True

    @catch_except
    def delete_alert_rule(self, asset_name, alert_rule_name):
        """ Method to Delete the Alert Rule, based on the alert_rule_name """
        if isinstance(alert_rule_name, list):
            for alerts in alert_rule_name:
                self.search_alert_rule(alerts)
                self.parent.click(".//*[@class='groupDeleteButton ng-scope']")
                sleep(0.3)
                self.parent.click('.//*[@class="btn btn-success confirm"]')
                sleep(2)
                self.parent.clear_web_alerts()
                sleep(2)
        else:
            self.search_alert_rule(asset_name)
            sleep(3)
            for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
                if alert_rule_name in element.text:
                    element.find_element_by_xpath(".//*[@class='groupDeleteButton ng-scope']").click()
                    sleep(0.3)
                    self.parent.click('.//*[@class="btn btn-success confirm"]')
                    sleep(2)
                    self.parent.clear_web_alerts()
                    sleep(2)

    @catch_except
    def select_alert_type(self, alert_type):
        """ Method to Select the Alert Type. """
        status = False
        alert_type = alert_type.lower()
        if alert_type == 'Fault Codes'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[1]", "class"):

                return self.parent.click(".//*[@class='alertBodyDiv']/div[1]")
            else:

                return True
        if alert_type == 'Geo Boundary'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[2]", "class"):
                return self.parent.click(".//*[@class='alertBodyDiv']/div[2]")
            else:
                return True
        if alert_type == 'Engine Status'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[3]", "class"):
                return self.parent.click(".//*[@class='alertBodyDiv']/div[3]")
            else:
                return True
        if alert_type == 'Device Status'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[4]", "class"):
                return self.parent.click(".//*[@class='alertBodyDiv']/div[4]")
            else:
                return True
        if alert_type == 'Battery Voltage'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[5]", "class"):
                return self.parent.click(".//*[@class='alertBodyDiv']/div[5]")
            else:
                return True

        if alert_type == 'Power Loss'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[6]", "class"):
                return self.parent.click(".//*[@class='alertBodyDiv']/div[6]")
            else:
                return True
        if alert_type == 'Low Fuel Level'.lower():
            if "alertTypeActive" not in self.parent.get_attribute_value(".//*[@class='alertBodyDiv']/div[7]", "class"):
                return self.parent.click(".//*[@class='alertBodyDiv']/div[7]")
            else:
                return True
        sleep(2)
        return status

    @catch_except
    def select_fault_code_severity(self, severity='all'):
        """ Method to Select the Fault Code alert type with Severity. """
        self.parent.click(".//*[@class='alertBodyDiv']/div[2]")
        sleep(1)
        self.parent.click(".//*[@class='alertBodyDiv']/div[1]")
        sleep(1)
        severity = severity.lower()
        if severity == 'all':
            self.parent.click(".//*[@ng-model='dtcSev.high']")
            sleep(0.25)
            self.parent.click(".//*[@ng-model='dtcSev.med']")
            sleep(0.25)
            self.parent.click(".//*[@ng-model='dtcSev.low']")
            sleep(0.25)
        elif severity == 'high':
            self.parent.click(".//*[@ng-model='dtcSev.high']")
            sleep(0.25)
        elif severity == 'medium':
            self.parent.click(".//*[@ng-model='dtcSev.med']")
            sleep(0.25)
        elif severity == 'low':
            self.parent.click(".//*[@ng-model='dtcSev.low']")
            sleep(0.25)
        return True

    @catch_except
    def select_geo_boundary(self, geoname, select_type='all'):
        """ Method to Select the Geo Boundary alert. """
        self.parent.wait_till_delay(".//*[@id='simple-btn-keyboard-nav']")
        self.parent.click(".//*[@id='simple-btn-keyboard-nav']")
        sleep(0.25)
        self.parent.click(".//*[text()='{}']".format(geoname))
        sleep(0.25)
        if select_type == 'all':
            self.parent.click(".//*[@ng-model='geoMovement.entry']")
            sleep(0.25)
            self.parent.click(".//*[@ng-model='geoMovement.exit']")
            sleep(0.25)
        elif select_type.lower() == 'entry':
            self.parent.click(".//*[@ng-model='geoMovement.entry']")
            sleep(0.25)
        elif select_type.lower() == 'exit':
            self.parent.click(".//*[@ng-model='geoMovement.exit']")
            sleep(0.25)
        return True

    @catch_except
    def select_engine_status(self, status='all'):
        """ Method to Select the Engine Status alert type. """
        status = status.lower()
        status_types = \
            {
                'engine stopped': ".//*[@ng-model='engStat.Stopped']",
                'engine running': ".//*[@ng-model='engStat.Running']",
                'engine in cool down': ".//*[@ng-model='engStat.CoolDown']",
                'not ready to run': ".//*[@ng-model='engStat.NotReady']"
            }
        if status == 'all':
            for value in status_types.values():
                self.parent.click(value)
                sleep(0.25)
        elif isinstance(status, list):
            for stat_val in status:
                self.parent.click(status_types[stat_val])
                sleep(0.25)
        else:
            self.parent.click(status_types[status])
            sleep(0.25)
        return True

    @catch_except
    def select_device_status(self, status_type='Days', day_hour="7"):
        """ Method to Select the Device Status Alert. """
        self.parent.click(".//*[@ng-model='devNotRes.durationType']")
        sleep(0.1)
        self.parent.click(".//*[text()='{}']".format(status_type))
        sleep(0.2)
        self.parent.click(".//*[@ng-model='devNotRes.durationVal']")
        sleep(0.1)
        self.parent.click(".//*[text()='{}']".format(day_hour))
        sleep(0.2)
        return True

    @catch_except
    def select_battery_voltage(self):
        """ Method to Select the Battery Voltage Alert. """
        self.parent.click(".//span[2][contains(text(),'Battery Voltage')]")
        sleep(0.2)
        self.parent.click(".//*[@ng-model='alertRuleValues.batVoltageLowAlert']")
        return True

    @catch_except
    def select_power_loss(self, reason='all'):
        """ Method to Select the Power Loss Alert. """
        reason_types = \
            {
                'asset move': ".//*[@ng-model='pl.astMove']",
                'power loss': ".//*[@ng-model='pl.powLoss']",
                'power restore': ".//*[@ng-model='pl.powRestore']",
            }
        if reason == 'all':
            for value in reason_types.values():
                self.parent.click(value)
                sleep(0.1)
        elif isinstance(reason, list):
            for keys in reason:
                self.parent.click(reason_types[keys])
                sleep(0.1)
        else:
            self.parent.click(reason_types[reason])
            sleep(0.1)
        return True

    @catch_except
    def select_low_fuel_alert(self):
        """ Method to Select the Low Fuel Alert. """
        self.parent.click(".//*[@ng-model='alertRuleValues.lowFuelLevel']")
        sleep(0.2)
        return True

    @catch_except
    def click_next(self):
        """ Method to do the click Next operation. """
        self.parent.click(".//*[@ng-click='moveNext();']")
        sleep(0.2)
        return True

    @catch_except
    def select_assets_in_alert_rule(self, asset_name):
        """ Method to select the assets in alert rule, by asset name. """
        self.parent.wait_till_delay(".//*[@id='assetAvatar']")
        if isinstance(asset_name, list):
            for asset in asset_name:
                self.admin.filter_asset(asset)
                sleep(1)
                self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
                sleep(0.5)
        else:
            self.admin.filter_asset(asset_name)
            sleep(5)
            self.parent.wait_till_inactive_delay(".//*[@class='loadingIconCls']")
            sleep(2)
            if not self.parent.is_displayed(".//*[@inner-html-text='data[val.attribute]']"):
                return False
            self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
            sleep(0.5)
        return True

    @catch_except
    def select_complex_assets_in_alert_rule_and_confirm(self, complex_asset_serial):
        """ Method to select the Complex asset for the alert rule. """
        class ProdStruct(object):
            """ Class to hold the information of product strucuture. """
            def __init__(self):
                self.name = None
                self.number = None
        prodinfo = ProdStruct()
        self.parent.wait_till_delay(".//*[@id='assetAvatar']")
        self.admin.filter_asset(complex_asset_serial)
        if self.parent.iselement_enabled(".//*[@title="
                                         "'There is no master asset "
                                         "for this Product Structure.']"):
            prodinfo.number = 'Not Present'
            prodinfo.name = 'Not Present'
        else:
            self.parent.click(".//*[@ng-click='expandAsset($event)']")
            sleep(2)
            element = self.parent.\
                find_element_by_xpath(".//*[@id='{}cat']".format(complex_asset_serial))
            prodinfo.number = \
                element.find_element_by_xpath\
                    (".//*[@class='ng-scope ng-isolate-scope']").text
            prodinfo.name = self.parent.\
                get_value(".//*[@class='assetAvatarText ng-scope ng-isolate-scope']")
        sleep(0.5)
        self.parent.click(".//*[@inner-html-text='data[val.attribute]']")
        return prodinfo

    @catch_except
    def enter_recipient_name(self, name):
        """ Method to enter the Recipient Name for the alert rule. """
        self.parent.input(".//*[@ng-model='addRecipientsData.recipientName']",
                          name)
        sleep(0.2)

    @catch_except
    def enter_mail_or_mobile_info(self, email='', rep_type='email'):
        """ Method to enter the Email ID for the alert rule. """
        if rep_type == 'email':
            self.parent.click(".//*[@name='byEmail']")
        else:
            self.parent.click(".//*[@name='byEmailTextMsg']")
        sleep(3)
        self.parent.input(".//*[@type='email']", email)
        sleep(0.2)

    @catch_except
    def add_recipient(self):
        """ Method to add the Recipient name. """
        self.parent.click(".//*[@ng-click='addDataVal()']")
        sleep(0.2)

    @catch_except
    def click_alert_create(self):
        """ Method to click the Create button to do the  final alert rule creation."""
        self.parent.click(".//*[@ng-click='multiPageConfig.onCreateBtn();']")
        return True

    @catch_except
    def generate_new_alert_rule(self, alert_rule_name='',
                                rule_type='', asset=None, arg=None,
                                alert_type='email', recipient_name='',
                                recipient_email='', is_complex=False):
        """ Method to cover overall process of Alert Rule Creation. """
        if not asset:
            asset = list()
        if not arg:
            arg = list()
        self.admin.go_to_alert_rule_page()
        sleep(1)
        self.parent.clear_web_alerts()
        if self.is_alert_rule_present(asset, alert_rule_name):
            return True
        self.create_alert_rule()
        sleep(0.5)
        self.enter_alert_rule_name(alert_rule_name)
        if self.select_alert_type(rule_type):
            if rule_type.lower() == 'fault codes':
                self.select_fault_code_severity(*arg)
            elif rule_type.lower() == 'geo boundary':
                self.select_geo_boundary(*arg)
            elif rule_type.lower() == 'engine status':
                self.select_engine_status(*arg)
            elif rule_type.lower() == 'device status':
                self.select_device_status(*arg)
            elif rule_type.lower() == 'battery voltage':
                self.select_battery_voltage()
            elif rule_type.lower() == 'power loss':
                self.select_power_loss(*arg)
            elif rule_type.lower() == 'low fuel level':
                self.select_low_fuel_alert()
            self.click_next()
            sleep(2)
            self.parent.wait_till_delay(".//*[@ng-model='searchText']")
            self.parent.wait_till_inactive_delay(".//*[@class='loadingIconCls']", 45)
            if is_complex:
                self.select_complex_assets_in_alert_rule_and_confirm(asset)
            else:
                self.select_assets_in_alert_rule(asset)
            sleep(2)
            self.click_next()
            sleep(2)
            if isinstance(recipient_name, list):
                for _, recipient_index in enumerate(recipient_name):
                    self.enter_recipient_name(recipient_name[recipient_index])
                    self.enter_mail_or_mobile_info(recipient_email[recipient_index],
                                                   alert_type)
                    self.add_recipient()
            elif recipient_name:
                self.enter_recipient_name(recipient_name)
                self.enter_mail_or_mobile_info(recipient_email, alert_type)
                self.add_recipient()
            sleep(1)
            self.parent.screenshot = self.parent.getscreenshot()
            self.click_next()
            sleep(1)
            self.click_alert_create()
            self.parent.wait_till_delay(".//*[@ng-click="
                                        "'callAlertCreate()']", 60)
            self.parent.clear_web_alerts()
            return self.is_alert_rule_present(asset, alert_rule_name)
        else:
            self.admin.go_to_alert_rule_page()
            return False

    @catch_except
    def search_alert_rule(self, asset_name):
        """ Method to Search the alert rule in the Alert Page. """
        self.parent.wait_till_delay(".//*[@ng-click='callAlertCreate()']")
        if not self.parent.iselement_enabled(".//*[@ng-click='callAlertCreate()']"):
            self.admin.go_to_alert_rule_page()
            self.parent.driver.refresh()
            self.parent.wait_till_delay(".//*[@ng-click='callAlertCreate()']")
        for _ in range(1):
            element = self.parent.\
                find_element_by_xpath(".//*[@id='accordionSearchBar']/input")
            self.parent.scroll_to_view_element(element)
            element.clear()
            sleep(0.5)
            for i in asset_name:
                element.send_keys(i)
                sleep(0.05)
            sleep(2)
        return True

    @catch_except
    def is_alert_rule_present(self, asset_name, alert_rule_name):
        """ Method to verify, whether the alert rule is present or not. """
        self.search_alert_rule(asset_name)
        sleep(3)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if alert_rule_name in element.text:
                return True
        return False

    @catch_except
    def click_cancel(self):
        """Method to Click on Cancel Button and 'YES' on Confirmation Pop Up"""
        xpath = str("//*[@class='pull-right cancelBtnCls cat-btn cat-btn-secondary ng-binding']")
        self.parent.jclick(xpath)
        sleep(2)
        self.parent.clear_web_alerts()
        self.parent.click("//*[@class='btn btn-success confirm']")
        sleep(2)
        self.parent.click(".//*[@class='btn btn-danger cancel']")
        return True

    @catch_except
    def click_save(self):
        """ Method to do the click save operation. """
        self.parent.click(".//*[@ng-click='multiPageConfig.onEditSaveBtn();']")
        sleep(0.2)
        return True

    @catch_except
    def edit_alertrule_name(self, asset_name, alert_rule_name, new_alert_name):
        """ Method to Edit the Alert Rule, based on the alert_rule_name """
        self.search_alert_rule(asset_name)
        sleep(3)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if alert_rule_name in element.text:
                element.find_element_by_xpath(".//*[@class='groupEditButton ng-scope']").click()
                sleep(0.3)
                self.enter_alert_rule_name(new_alert_name)
                sleep(2)
                self.click_next()
                sleep(2)
                self.click_next()
                sleep(2)
                self.click_next()
                sleep(2)
                self.click_save()
                sleep(2)
        return True

    @catch_except
    def edit_alert(self, asset_name, alert_rule_name):
        """ Method to click edit the Alert Rule."""
        self.search_alert_rule(asset_name)
        sleep(3)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if alert_rule_name in element.text:
                element.find_element_by_xpath(".//*[@class='groupEditButton ng-scope']").click()
                sleep(2)
                return True

    @catch_except
    def edit_alertrule_type(self, asset_name, alert_rule_name, alerttype):
        """ Method to Edit the Alert Type, based on the alert_rule_name """
        status = "Not Selected"
        self.search_alert_rule(asset_name)
        sleep(3)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if alert_rule_name in element.text:
                element.find_element_by_xpath(".//*[@class='groupEditButton ng-scope']").click()
                sleep(2)
                status = "Selected" if self.select_alert_type(alerttype) else "Not Selected"
                return status
        return status

    @catch_except
    def click_update_button(self):
        """ Method to do the click Update button """
        self.parent.click(".//*[@ng-click='updateDataVal()']")
        sleep(3)
        return True

    @catch_except
    def edit_recipient(self, edited_recipient_name, edited_email='', rep_type=""):
        """ Method to edit recipient. """
        self.parent.click(".//*[@ng-click='editRecipentsFn(k)']")
        self.enter_recipient_name(edited_recipient_name)
        self.enter_mail_or_mobile_info(edited_email, rep_type="")
        if rep_type == 'email':
            self.parent.click(".//*[@name='byEmail']")
        else:
            self.parent.click(".//*[@name='byEmailTextMsg']")
            sleep(2)
            self.parent.input('.//*[contains(@ng-blur,"sms")]', edited_email)

    @catch_except
    def delete_recipient(self):
        """ Method to delete the recipient """
        self.parent.click(".//*[@ng-click='deleteRecipentFn(k)']")
        sleep(3)
        self.parent.click(".//*[@onclick='window.customConfirm.ok()']")
        return True

    @catch_except
    def select_gmt_time_zone(self, timezone="GMT"):
        """
        Method to select GMt time zone"
        @timezone <string> GMT specified time Zone
        @:return Boolean
        """
        self.parent.click(".//*[@ng-model='tzcode']")
        sleep(0.1)
        self.parent.click(".//*[text()='{}']".format(timezone))
        sleep(0.5)
        return True

    @catch_except
    def revert_selected_assets_in_alert_rule(self):
        """
        Method to revert the selected assets and move them back to available equipmwnt pane
        :return: Boolean
        """
        self.parent.click("//*[@id='revertAll']")
        sleep(0.1)
        return True

    @catch_except
    def number_of_rows_displayed_select_equipment(self, rows="20"):
        """
        Method to select number of rows to be selected
        :return: Boolean
        """
        self.parent.click(".//*[@id='selectEquipmentSection']/grid/div/div[3]/div[2]/div/select")
        sleep(0.1)
        self.parent.click(".//*[text()='{}']".format(rows))
        return True

    @catch_except
    def check_prev_page_button_equipment_pane(self):
        """
        Method to verify Prev page button is displayed and navigates to Prev page
        :return: Boolean
        """
        prev_page_element_enabled = self.parent.iselement_enabled(".//*[@id='selectEquipmentSection']/grid/div/div[3]/div[2]/ul/li[2]")
        sleep(0.1)
        if prev_page_element_enabled is True:
            self.parent.click(".//*[@id='selectEquipmentSection']/grid/div/div[3]/div[2]/ul/li[2]")
            sleep(0.1)
        else:
            return False
        return True

    @catch_except
    def check_next_page_button_equipment_pane(self):
        """
        Method to verify Next page button is displayed and navigates to next page
        :return: Boolean
        """
        next_page_element_enabled = \
            self.parent.iselement_enabled(".//*[@id='selectEquipmentSection']/grid/div/div[3]/div[2]/ul/li[4]")
        sleep(0.1)
        if next_page_element_enabled is True:
            self.parent.click(".//*[@id='selectEquipmentSection']/grid/div/div[3]/div[2]/ul/li[4]")
        else:
            return False
        return True

    @catch_except
    def is_filters_label_available(self):
        """
        Method to check if filters label is available
        :return Boolean
        """
        self.parent.click(".//*[@id='filter_label']")
        sleep(0.1)
        return True

    @catch_except
    def is_filter_section_element_present(self):
        """
        :return Boolean
        """
        sleep(0.1)
        return True

    @catch_except
    def clear_all_filters(self):
        """
        Method to clear all the filters selected
        :return: Boolean
        """
        self.parent.click(".// *[ @ ng - click = 'handleClearAllClick()']")
        sleep(0.2)
        return True

    @catch_except
    def saved_group_dropdown_selected(self):
        """
        Method to click on saved group drop down and select one of the top element
        :return: Boolean
        """
        self.parent.click("//*[@id='filterSection']/filters/div/div/div[4]/accordion/div/div[2")
        sleep(0.2)
        self.parent.click("//*[@id='filterSection'']/filters/div/div/div[4]/accordion/div/div[1]/div[2]/div/div/div[1]/input")
        sleep(0.2)
        return True

    @catch_except
    def minimize_filters_panel(self):
        """
        Method to minimize the filters panel
        :return: Boolean
        """
        return True

    @catch_except
    def cancel_button(self):
        """Method to click on cancel button in Admin-> alerts page"""
        self.parent.click('//*[@id="wizardFooterTop"]//*[contains(text(), "Cancel")]')
        self.parent.clear_web_alerts()
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(2)

    @catch_except
    def alert_is_panel_present(self, *panels_list):
        """Method to check Panels in Geo Boundaries Page are present"""
        panels = {
            'Filter_panel': str(".//*[@id='filterSection']"),
            'EquipmentList_panel': str(".//*[@id='selectEquipmentSection']"),
            'SelectEquipmentList_panel': str(".//*[@id='selectedEquipmentSection']")}
        result = dict()
        for panel in panels_list:
            xpath = panels.get(panel, "")
            self.parent.wait_till_delay(xpath, 10)
            result[panel] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_time_zone_present(self):
        """ Method to verify cancel button in create alert rule page"""
        return self.parent.is_element_present(
            ".//*[@id='manageViewGroupContainer']/div[2]/div/div/div/div[4]/div[3]/div/div/div/div[1]"
            "/div/div/div[2]/select")

    @catch_except
    def alert_select_all_assets(self):
        """Method to select all assets in creating alert rule equipment panel"""
        # Max is 300 so I type letters in the filter to lower the number
        self.parent.wait_till_delay(".//*[@ng-model='searchText']")
        self.parent.click("//*[@id='pushAll']")
        self.parent.wait_till_delay(".//*[@ng-click='moveNext();']")
        return True

    @catch_except
    def view_edit_delete(self, existing_alert, asset=None):

        """"Methods to search the existing alert rules and cloning the alert rule
        clone (String) >> this argument to provide the clone name
        existing_alert (String) >> this argument to find the existing alert for the Alert rules
        alert_rule_name (String) >> Type of rule e.g : contacts
        rule_type (String) >> Alert code e.g : Fault Codes
        asset (String) >> asset name
        arg (String) >> level of alert
        """

        status = False
        view = False
        edit = False
        delete = False
        edited_alert_name = existing_alert
        verify_view = "View - not Available"

        if not asset:
            asset = list()
        self.parent.driver.refresh()
        sleep(5)
        self.admin.go_to_alert_rule_page()
        sleep(6)
        self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        sleep(5)
        try:
             for i in range(0, 5):
                count = len(self.parent.driver.find_elements_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[*]/div[1]/h4/a/div[1]/i"))
                self.parent.find_element_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[" + str(count) + "]/div[1]/h4/a/div[1]/i")
        except:
            pass
        # view

        if self.parent.is_displayed(or_adminpage.BTN_ARROW.replace("#", existing_alert)):
            view = True
        else:
            verify_view = " ' -- Verified - View Alert Rules is not Available --' "

        # Edit

        if self.parent.is_displayed(or_adminpage.BTN_EDIT.replace("#", existing_alert)):
            edit_status = self.edit_alert(existing_alert, asset=asset)
            edited_alert_name = str(edit_status[1])
            if edit_status[0]:
                edit = True
                verify_edit = " ' -- Verified - Edit option is available and validated edited data --' "
            else:
                verify_edit = " ' -- Verified - Edit option is available, but unable to validated edited data --' "
        else:
            verify_edit = " ' -- Verified - Edit option is not available --' "

        sleep(5)
        try:
            for i in range(0, 5):
                count = len(self.parent.driver.find_elements_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[*]/div[1]/h4/a/div[1]/i"))
                self.parent.find_element_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[" + str(count) + "]/div[1]/h4/a/div[1]/i")
        except:
            pass
        # Delete

        if self.parent.is_displayed(or_adminpage.BTN_DELETE.replace("#", edited_alert_name)):
            delete_status = self.delete_alert(edited_alert_name, asset=asset)
            if delete_status:
                delete = True
                verify_delete = " ' -- Verified - Delete option is available and validated deleted data --' "
            else:
                verify_delete = " ' -- Verified - Delete option is available, but unable to validated deleted data --' "
        else:
            verify_delete = " ' -- Verified - Delete option is not available -- ' "

        # Overall Verification

        if view and edit and delete:
            status = True
        verification = [verify_view, verify_edit, verify_delete]
        return [status, verification]

    @catch_except
    def view_no_edit_no_delete(self, existing_alert, asset=None):

        """"Methods to search the existing alert rules and cloning the alert rule
        clone (String) >> this argument to provide the clone name
        existing_alert (String) >> this argument to find the existing alert for the Alert rules
        alert_rule_name (String) >> Type of rule e.g : contacts
        rule_type (String) >> Alert code e.g : Fault Codes
        asset (String) >> asset name
        arg (String) >> level of alert
        """

        status = False
        view = False
        edit = True
        delete = True
        verify_view = "View - Not Available"
        verify_edit = "Edit - Available"
        verify_delete = "Delete - Available"
        if not asset:
            asset = list()
        self.parent.driver.refresh()
        sleep(8)
        self.admin.go_to_alert_rule_page()
        self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        sleep(5)
        try:
            for i in range(0, 5):
                count = len(self.parent.driver.find_elements_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[*]/div[1]/h4/a/div[1]/i"))
                self.parent.find_element_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[" + str(count) + "]/div[1]/h4/a/div[1]/i")
        except:
            pass

        if self.parent.is_displayed(or_adminpage.BTN_ARROW.replace("#", existing_alert)):
            view = True
        else:
            verify_view = " ' -- Verified - View Alert Rules is Available --' "
        if self.parent.is_displayed(or_adminpage.BTN_EDIT.replace("#", existing_alert)):
            edit = False
        else:
            verify_edit = " ' -- Verified - Edit option is not available --' "
        if self.parent.is_displayed(or_adminpage.BTN_DELETE.replace("#", existing_alert)):
            delete = False
        else:
            verify_delete = " ' -- Verified - Delete option is not available -- ' "
        if view and edit and delete:
            status = True
        verification = [verify_view, verify_edit, verify_delete]
        return [status, verification]

    @catch_except
    def no_view_no_edit_no_delete(self, existing_alert, asset=None):

        """"Methods to search the existing alert rules and cloning the alert rule
        clone (String) >> this argument to provide the clone name
        existing_alert (String) >> this argument to find the existing alert for the Alert rules
        alert_rule_name (String) >> Type of rule e.g : contacts
        rule_type (String) >> Alert code e.g : Fault Codes
        asset (String) >> asset name
        arg (String) >> level of alert
        """

        status = False
        edit = True
        delete = True
        view = True
        verify_view = "View -Available"
        verify_edit = "Edit - Available"
        verify_delete = "Delete - Available"
        if not asset:
            asset = list()
        self.parent.driver.refresh()
        sleep(8)
        self.admin.go_to_alert_rule_page()
        self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        sleep(5)
        if self.parent.is_displayed(or_adminpage.BTN_ARROW.replace("#", existing_alert)):
            view = False
        else:
            verify_view = " ' -- Verified - View Alert Rules is  not Available --' "
        if self.parent.is_displayed(or_adminpage.BTN_EDIT.replace("#", existing_alert)):
            edit = False
        else:
            verify_edit = " ' -- Verified - Edit option is not available --' "
        if self.parent.is_displayed(or_adminpage.BTN_DELETE.replace("#", existing_alert)):
            delete = False
        else:
            verify_delete = " ' -- Verified - Delete option is not available -- ' "
        if view and edit and delete:
            status = True
        verification = [verify_view, verify_edit,verify_delete]
        return [status, verification]

    @catch_except
    def edit_alert(self, existing_alert, asset=None, arg=None):

        """" Edit the existing Alert rule """

        edit = False
        edit_name = existing_alert+str(1)
        if not asset:
            asset = list()
        if not arg:
            arg = list()
        sleep(8)
        # self.admin.go_to_alert_rule_page()
        # self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        # sleep(5)
        if self.parent.is_displayed(or_adminpage.BTN_EDIT.replace("#", existing_alert)):
            self.parent.click(or_adminpage.BTN_EDIT.replace("#", existing_alert))
            sleep(5)

            self.enter_alert_rule_name(edit_name)
            sleep(2)
            self.click_next()
            sleep(2)
            self.click_next()
            sleep(2)
            self.click_next()
            sleep(2)
            self.click_alert_save()
            sleep(2)
            edit = True
            #self.parent.driver.refresh()
            sleep(8)
            self.admin.go_to_alert_rule_page()
            self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
            sleep(5)
            if self.parent.is_displayed(or_adminpage.BTN_ARROW.replace("#", edit_name)):
                edit = True
        return [edit, edit_name]

    @catch_except
    def delete_alert(self, existing_alert, asset=None):

        """" Edit the existing Alert rule """

        delete = False
        if not asset:
            asset = list()
        self.parent.driver.refresh()
        sleep(8)
        self.admin.go_to_alert_rule_page()
        self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
        sleep(5)
        try:
            for i in range(0, 5):
                count = len(self.parent.driver.find_elements_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[*]/div[1]/h4/a/div[1]/i"))
                self.parent.find_element_by_xpath(
                    "//*[@id='accordionControllerContainer']/accordion/div/div[" + str(count) + "]/div[1]/h4/a/div[1]/i")
        except:
            pass
        sleep(3)
        if self.parent.is_displayed(or_adminpage.BTN_DELETE.replace("#", existing_alert)):
            self.parent.click(or_adminpage.BTN_DELETE.replace("#", existing_alert))
            sleep(2)
            self.parent.click(or_adminpage.BTN_POPUP_YES)
            sleep(2)
            self.admin.go_to_alert_rule_page()
            sleep(2)
            self.parent.input(or_adminpage.TXTBX_SEARCH, asset)
            sleep(3)
            try:
                if self.parent.is_displayed(or_adminpage.BTN_ARROW.replace("#", existing_alert + str(1))):
                    delete = False
                else:
                    delete = True
            except:
                delete = True
        return delete
