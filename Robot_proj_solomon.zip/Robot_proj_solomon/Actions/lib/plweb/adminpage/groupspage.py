"""
Module to perform operation and data extraction in Groups page.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/groupspage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Groups Page for Product Link Application.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for structure.
# **
# *******************************************************************************
# """


from time import sleep
from lib.webinterface import catch_except


class GroupsPage(object):
    """ Parent class for Groups Page. """
    def __init__(self, parent, admin):
        self.parent = parent
        self.admin = admin

    @catch_except
    def create_group(self):
        """ Method to create a Groups Page. """
        self.parent.wait_till_delay(".//*[@ng-click='createGroupsPage()']")
        sleep(2)
        self.parent.click(".//*[@ng-click='createGroupsPage()']")
        sleep(5)
        self.parent.wait_till_delay(".//*[@ng-model='GrpNames']")
        sleep(5)
        return True

    @catch_except
    def enter_group_name(self, group_name):
        """ Method to Enter the Group Name. """
        self.parent.wait_till_delay(".//*[@ng-model='GrpNames']")
        sleep(2)
        self.parent.input(".//*[@ng-model='GrpNames']", group_name)
        sleep(3)
        return True

    @catch_except
    def create_group_end(self):
        """ Method to finalize the Group the creation. """
        self.parent.wait_till_delay(".//*[@ng-click='createSelectedAssets()']")
        self.parent.click(".//*[@ng-click='createSelectedAssets()']")
        sleep(5)
        return True

    @catch_except
    def generate_group_of_assets(self, group_name, assets):
        """ Method to cover the complete creation of Groups. """
        self.admin.go_to_group_page()
        self.create_group()
        self.enter_group_name(group_name)
        self.admin.select_assets(assets)
        self.create_group_end()
        self.parent.clear_web_alerts()
        return True

    @catch_except
    def manage_groups(self):
        """ Method to click the Manage group page. """
        self.parent.click(".//*[@href='#/manageview']")
        sleep(2)
        self.parent.clear_web_alerts()
        sleep(3)

    @catch_except
    def is_group_present(self, asset_name, group_name):
        """ Method to verify whether the Group is present.
        Asset Name is used for search of Group. """
        self.search_group(asset_name)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if group_name in element.text:
                return True
        return False

    @catch_except
    def search_group(self, asset_name):
        """ Method to Search the Group in page."""
        self.parent.wait_till_delay(".//*[@ng-click='createGroupsPage()']")
        if not self.parent.iselement_enabled(".//*[@ng-click='createGroupsPage()']"):
            self.admin.go_to_group_page()
            self.parent.wait_till_delay(".//*[@ng-click='createGroupsPage()']")
            sleep(2)
        #self.parent.input(".//*[@id='accordionSearchBar']/input", asset_name)
        self.parent.wait_till_delay(".//*[@id='accordionSearchBar']/input")
        self.parent.input(".//*[@id='accordionSearchBar']/input", asset_name)
        sleep(5)
        return True

    @catch_except
    def delete_group(self, assetname, gp_name):
        """ Method to delete the group """
        self.search_group(assetname)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if gp_name in element.text:
                self.parent.click("//*[contains(text(),'%s')]/ancestor::a[@class='accordion-toggle']"
                                  "//div[@class='buttonControls ng-scope']"
                                  "//div[@class='groupDeleteButton ng-scope']" %gp_name)
                self.parent.click("//*[@class='groupDeleteButton ng-scope']")
                sleep(3)
                self.parent.clear_web_alerts()
                self.parent.click(".//*[@class='btn btn-success confirm']")
                sleep(5)
                if self.is_group_present(assetname, gp_name):
                    return False
                return True
        self.search_group(assetname)
        return False
    @catch_except
    def edit_group_name(self, gp_name, assetname):
        """"Method to edit the group name"""
        self.enter_group_name(gp_name)
        sleep(0.5)

    @catch_except
    def edit_group(self, gp_name, assetname):
        """"Method to click on edit button"""
        self.search_group(assetname)
        self.parent.click("//*[contains(text(),'%s')]/ancestor::a[@class='accordion-toggle']"
                          "//div[@class='buttonControls ng-scope']"
                          "//div[@class='groupEditButton ng-scope']" %gp_name)
        self.parent.click("//*[@class='groupEditButton ng-scope']")
        sleep(3)


    @catch_except
    def select_group_type(self, arg):
        """"Method to select the group type"""
        if arg == 'public':
            self.parent.click('//*[contains (text(),"Public")]')
        else:
            self.parent.click('//*[contains (text(),"Private")]')
        return True

    @catch_except
    def save_group(self):
        """"Method to click on Save Button"""
        self.parent.click("//*[@class='prodName ng-binding']//*[@ng-click='saveSelectedAssets()']")
        sleep(10)

    @catch_except
    def cancel_button(self):
        """Method to click on cancel button in Admin-> Groups page"""
        self.parent.click('//*[@class="prodName ng-binding"]//*[contains(text(), "Cancel")]')
        self.parent.clear_web_alerts()
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(5)

    @catch_except
    def confirm_group_creation(self, serial_num, group_name):
        """ Method to confirm the Product Structure. """

        class GroupStruct(object):
            """ Class to hold the product structure data. """

            def __init__(self):
                self.name = None
                self.number = None

        groupinfo = GroupStruct()
        self.search_group(serial_num)
        for element in self.parent.driver.find_elements_by_xpath(".//*[@ng-if='group']"):
            if group_name in element.text:
                groupinfo.name = self.parent.get_value('//*[@class="prodName ng-binding ng-scope"]')
                groupinfo.number = self.parent.get_value('//*[@class="creator ng-binding ng-scope"]')
                local_info = groupinfo.number.splitlines()[0].split(' ')
                groupinfo.number = local_info[2]
                sleep(5)
                return groupinfo
        return False

    @catch_except
    def edit_gp_button(self, gp_name, assetname):
        """Method to check the existence of Edit Button"""
        self.search_group(assetname)
        return self.parent.is_displayed("//*[contains(text(),'%s')]/ancestor::a[@class='accordion-toggle']"
                          "//div[@class='buttonControls ng-scope']"
                          "//div[@class='groupEditButton ng-scope']" % gp_name)

    @catch_except
    def delete_gp_button(self, gp_name, assetname):
        """Method to check the existence of Delete Button"""
        self.search_group(assetname)
        return self.parent.is_displayed("//*[contains(text(),'%s')]/ancestor::a[@class='accordion-toggle']"
                                  "//div[@class='buttonControls ng-scope']"
                                  "//div[@class='groupDeleteButton ng-scope']" % gp_name)

    @catch_except
    def retrieve_asset(self, gp_name, assetname):
        """Method to retreive asset in a group"""
        self.search_group(assetname)
        self.parent.click("//*[contains(text(),'%s')]/ancestor::a[@class='accordion-toggle']"
                          "//i[@class='pull-right accordionicon ng-scope accordionDown']" % gp_name)
        sleep(10)
        asset_list = []
        for item in range(1, 6):
            element = self.parent.get_value('//*[@class="bodyContents"]/div[%s]/div/div[2]' % item)
            sleep(2)
            if element is False:
                break
            asset_list.append(element)
        return asset_list

    @catch_except
    def remove_selected_assets_gp(self, asset_name):
        """ Method to Remove the Selected Assets based on the Asset Name provided. """
        search_element = self.parent.find_element_by_xpath('//*[@id="selectedEquipmentSection"]//*[@ng-model="searchText"]')
        search_element.clear()
        sleep(0.25)
        search_element.send_keys(asset_name)
        sleep(3)
        click_element = self.parent.find_element_by_xpath("//*[@id='selectedEquipmentSection']//*[@ng-click='options.rowClickCallBackFun($event,data);']")
        sleep(3)
        click_element.click()
        sleep(1)
        search_element.clear()

