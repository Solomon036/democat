"""
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     plweb/adminpage/geoboundariespage.py
# **
# ** DESCRIPTION:
# **     Package for data extraction and to validate various functionalities in
# **     Geo Boundaries Page for Product Link Application.
# **
# ** AUTHOR:
# **    Shanthi Kalidass.
# ** HISTORY:
# ** Change 00  2017-03-27 (kalids2)
# **     Created the Initial Version of the file structure.
# **
# *******************************************************************************
# Calculate the square root of a number.
#
#     Args:
#         n: the number to get the square root of.
#     Returns:
#         the square root of n.
#     Raises:
#         TypeError: if n is not a number.
#         ValueError: if n is negative.
#
"""

from time import sleep
from lib.webinterface import catch_except


class GeoBoundaries(object):
    """ Parent Class for the Geo Boundaries Page of Admin Page. """
    def __init__(self, parent, admin):
        """ Method to initialize the instance of Geo Boundaries page. """
        self.parent = parent
        self.admin = admin

    @catch_except
    def is_label_present(self, *labels_list):
        """Method to check Labels in Geo Boundaries Page are present"""
        labels = {
            'geo_boundary': str(".//*[@class ='createGeoBoundaryPanel']"
                                "/label[text()='Geo Boundaries']"),
            'search': str(".//*[@class ='createGeoBoundaryPanel']"
                          "/label[text()='Search Geo Boundaries']"),
            'geo_list': str(".//*[@class ='createGeoBoundaryPanel']"
                            "/label[text()='Geo Boundaries List']"),
            'geo_dropdown': str(".//*[@class ='createGeoBoundaryPanel']"
                                "/label[text()='Double click to edit Geo Boundary']"),
            'create_geo': str(".//*[@class ='createGeoBoundaryPanel']"
                              "/label[text()='Create Or Edit Geo Boundary']"),
            'geo_title': str(".//*[@class ='createGeoBoundaryPanel']"
                             "/label[text()='Geo Boundary Title']"),
            'choose_color': str(".//*[@class='createEditGeoBoundaryPopover']"
                                "/create-geo-boundary-form/div/label[text()='Choose Color']"),
            'choose_shape': str(".//*[@class ='createEditGeoBoundaryPopover']"
                                "/create-geo-boundary-form/div/label[text()='Choose Shape']")}
        result = dict()
        for label in labels_list:
            xpath = labels.get(label, "")
            self.parent.wait_till_delay(xpath, 10)
            result[label] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_panel_present(self, *panels_list):
        """Method to check Panels in Geo Boundaries Page are present"""
        panels = {
            'search_panel': str(".//*[@class ='createEditGeoBoundaryPopover']"
                                "/create-geo-boundary-list/div/form/div"),
            'create_panel': str(".//*[@class ='createEditGeoBoundaryPopover']"
                                "/create-geo-boundary-form/div/form/div"),
            'dropdown_panel': str(".//*[contains(@class,'createGeoBoundaryList noselect')]"),
            'dropdown_item': str(".//*[contains(@class,'createGeoBoundaryList noselect')]/li[1]")}
        result = dict()
        for panel in panels_list:
            xpath = panels.get(panel, "")
            self.parent.wait_till_delay(xpath, 10)
            result[panel] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_textbox_present(self, *textbox_list):
        """Method to check Text Boxes in Geo Boundaries Page are present"""
        textboxes = {
            'search': str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-list"
                          "//input[contains(@placeholder,'Enter')]"),
            'create': str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-form"
                          "//input[contains(@placeholder,'Enter')]")}
        result = dict()
        for textbox in textbox_list:
            xpath = textboxes.get(textbox, "")
            self.parent.wait_till_delay(xpath, 10)
            result[textbox] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_button_present(self, *buttons_list):
        """Method to check Buttons in Geo Boundaries Page are present."""
        buttons = {
            'create_edit': str(".//*[@id='createEditGeoBoundaryButton']"),
            'show_hide': str(".//*[@id='navbar']/ul[contains(@class,'GeoBoundaryNav')]/li[2]/a"),
            'cancel': str(".//*[@class='createGeoBoundaryFooter']/button[text()='Cancel']"),
            'close': str(".//*[@class='createGeoBoundaryFooter']//button[text()='Close']"),
            'save': str(".//*[@class='createGeoBoundaryFooter']/button[text()='Save']"),
            'road': str(".//*[contains(@class,'NavBar_modeSelectorControlContainer')]"),
            'road_icon': str(".//*[@class='NavBar_dropIcon']"),
            'create_cross': str(".//*[@class ='createEditGeoBoundaryPopover']"
                                "/create-geo-boundary-form//span[contains(@class,'glyphicon')]"),
            'search_cross': str(".//*[@class ='createEditGeoBoundaryPopover']"
                                "/create-geo-boundary-list//span[contains(@class,'glyphicon')]"),
            'edit': str("(.//*[contains(@class,'ng-hide')])[1]"),
            'delete': str("(.//*[contains(@class,'ng-hide')])[2]")}
        result = dict()
        for button in buttons_list:
            xpath = buttons.get(button, "")
            self.parent.wait_till_delay(xpath, 10)
            result[button] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_color_present(self, *colors_list):
        """Method to check Colors in Geo Boundaries Page are present."""
        colors = {
            'yellow': str(".//*[@class='createEditGeoBoundaryPopover']"
                          "/create-geo-boundary-form/div/div[1]/button[1]"),
            'blue': str(".//*[@class='createEditGeoBoundaryPopover']"
                        "/create-geo-boundary-form/div/div[1]/button[2]"),
            'green': str(".//*[@class='createEditGeoBoundaryPopover']"
                         "/create-geo-boundary-form/div/div[1]/button[3]"),
            'red': str(".//*[@class='createEditGeoBoundaryPopover']"
                       "/create-geo-boundary-form/div/div[1]/button[4]")}
        result = dict()
        for color in colors_list:
            xpath = colors.get(color, "")
            self.parent.wait_till_delay(xpath, 10)
            result[color] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_shape_present(self, *shapes_list):
        """Method to check Shape Buttons in Geo Boundaries Page are present."""
        shapes = {
            'square': str(".//*[ @ data-toggle='buttons']//label[1]"),
            'polygon': str(".//*[@data-toggle='buttons']//label[2]")}
        result = dict()
        for shape in shapes_list:
            xpath = shapes.get(shape, "")
            self.parent.wait_till_delay(xpath, 10)
            result[shape] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_road_options_present(self, *options_list):
        """Method to check Road Options are present in the Road DropDown Button."""
        options = {
            'road': str(".//*[text()='Road']"),
            'bird_eye': str(".//*[contains(text(),'eye')]"),
            'automatic': str(".//*[text()='Automatic']")}
        result = dict()
        for option in options_list:
            xpath = options.get(option, "")
            self.parent.wait_till_delay(xpath, 10)
            result[option] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def is_map_navigation(self, *navbar_list):
        """Method to check Navigation Bars are present in the Map."""
        nav_bars = {
            'zoom_in': str(".//*[@class='NavBar_zoomControlContainer']/a[@title='Zoom in']"),
            'zoom_out': str(".//*[@class='NavBar_zoomControlContainer']/a[@title='Zoom out']"),
            'directions': str(
                ".//*[@class ='NavBar_compassControlContainer']"
                "/a[@title='Click to pan in any direction']")}
        result = dict()
        for nav in navbar_list:
            xpath = nav_bars.get(nav, "")
            self.parent.wait_till_delay(xpath, 10)
            result[nav] = self.parent.is_element_present(xpath)
        return result

    @catch_except
    def click_zoom_in(self):
        """Method to Zoom In"""
        xpath = str(".//*[@class='NavBar_zoomControlContainer']/a[@title='Zoom in']")
        self.parent.click(xpath)
        return True

    @catch_except
    def click_zoom_out(self):
        """Method to Zoom Out"""
        xpath = str(".//*[@class='NavBar_zoomControlContainer']/a[@title='Zoom out']")
        self.parent.jclick(xpath)
        return True

    @catch_except
    def road_option_data(self):
        """Method to get the Road Option Text Data"""
        xpath = str(".//*[contains(@class,'NavBar_modeSelectorControlContainer')]")
        element_value = self.parent.get_value(xpath)
        return element_value

    @catch_except
    def click_road_button(self):
        """Method to click on Road Button"""
        xpath = str(".//*[@class='NavBar_typeButtonLabel NavBar_MapType_r']")
        self.parent.jclick(xpath)
        sleep(2)
        return True

    @catch_except
    def click_automatic_button(self):
        """Method to click on Road Button"""
        xpath = str(".//*[@class='NavBar_itemContainer NavBar_itemContainer_auto']")
        self.parent.jclick(xpath)
        sleep(2)
        return True

    @catch_except
    def click_bird_eye_button(self):
        """Method to click on Road Button"""
        xpath = str(".//*[@class='NavBar_itemContainer NavBar_itemContainer_be']")
        self.parent.jclick(xpath)
        sleep(2)
        return True

    @catch_except
    def click_road_drop_button(self):
        """Method to click on Road Drop Down Icon"""
        xpath = str(".//*[@class='NavBar_dropIconContainer']")
        self.parent.jclick(xpath)
        sleep(2)
        return True

    @catch_except
    def map_assets_present(self):
        """Method to check Map with Assets are present."""
        xpath = str(".//*[@id='assetMap']")
        self.parent.wait_till_delay(xpath, 10)
        element_status = self.parent.is_element_present(xpath)
        return element_status

    @catch_except
    def is_location_search_present(self):
        """Method to check Location Search Bar is present."""
        xpath = str(".//*[contains(@placeholder,'Location')]")
        self.parent.wait_till_delay(xpath, 10)
        element_status = self.parent.is_element_present(xpath)
        return element_status

    @catch_except
    def close_create_panel(self):
        """Method to close the Create/Edit Geo Boundary Pane."""
        xpath = str(".//*[@class='createGeoBoundaryFooter']//button[text()='Close']")
        self.parent.click(xpath)
        sleep(2)
        return True

    @catch_except
    def click_create_edit_geo_boundary(self):
        """Method to Click Create/Edit Geo Boundary Button."""
        xpath = str(".//*[@id='createEditGeoBoundaryButton']")
        self.parent.jclick(xpath)
        sleep(2)
        return True

    @catch_except
    def refresh_admin_page(self):
        """Method to Refresh the Admin Page"""
        self.parent.refreshdriver()
        sleep(2)
        return True

    @catch_except
    def click_delete(self, get_alert_data=None):
        """Method to Click on Delete Button and 'YES' on Confirmation Pop Up"""
        xpath = str("(.//*[contains(@class,createGeoBoundaryListItemRollOVerConatiner)]"
                    "/a[2]/span)[2]")
        self.parent.click(xpath)
        sleep(5)
        self.parent.clear_web_alerts()
        alert_value = [self.parent.get_attribute_inner_text(".//*[@id='customConfirm']/div[2]")]
        self.parent.click(".//*[@class='btn btn-success confirm']")
        sleep(2)
        alert_value.append(self.parent.get_attribute_inner_text(".//*[@id='customAlert']/div[2]"))
        self.parent.click(".//*[@class='btn btn-primary']")
        if get_alert_data:
            return alert_value
        return True

    @catch_except
    def click_edit(self):
        """Method to Click on Edit Button and 'YES' on Confirmation Pop Up"""
        xpath = str("(.//*[contains(@class,createGeoBoundaryListItemRollOVerConatiner)]"
                    "//*[@tooltip='Edit'])[1]")
        self.parent.click(xpath)
        sleep(2)
        self.parent.clear_web_alerts()
        self.parent.click(".//*[@class='btn btn-primary']")
        return True

    @catch_except
    def location_search(self, location='France', zoom_in=None):
        """Method to Search a particular Location in the Map"""
        xpath = str(".//*[@id = 'findLocationInput']|.//*[@placeholder = 'Location Search...']")
        self.parent.input(xpath, str(location))
        sleep(5)
        self.parent.jclick(".//span[contains(@class,'glyphicon-search')]")
        sleep(10)
        if zoom_in:
            for _ in range(5):
                sleep(1)
                self.parent.click(str(".//*[@class='NavBar_zoomControlContainer']"
                                      "/a[@title='Zoom in']"))
        return True

    @catch_except
    def input_boundary_name(self, boundary_name='test', flag='search'):
        """Method to input the boundary name in the Search Text Box"""
        xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-list"
                    "//input[contains(@placeholder,'Enter')]")
        if flag == 'create':
            xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-form"
                        "//input[contains(@placeholder,'Enter')]")

        self.parent.input(xpath, boundary_name)
        sleep(2)
        return True

    @catch_except
    def click_select_color(self, color='yellow'):
        """Method to Select a Color"""
        colors = {
            'yellow': str(".//*[@class='createEditGeoBoundaryPopover']"
                          "/create-geo-boundary-form/div/div[1]/button[1]"),
            'blue': str(".//*[@class='createEditGeoBoundaryPopover']"
                        "/create-geo-boundary-form/div/div[1]/button[2]"),
            'green': str(".//*[@class='createEditGeoBoundaryPopover']"
                         "/create-geo-boundary-form/div/div[1]/button[3]"),
            'red': str(".//*[@class='createEditGeoBoundaryPopover']"
                       "/create-geo-boundary-form/div/div[1]/button[4]")}
        if color == 'yellow':
            self.parent.click(colors[color])
        if color == 'blue':
            self.parent.click(colors[color])
        if color == 'green':
            self.parent.click(colors[color])
        if color == 'red':
            self.parent.click(colors[color])
        return True

    @catch_except
    def click_shape(self, shape='square'):
        """Method to Select a Shape"""
        shapes = {
            'square': str(".//*[ @ data-toggle='buttons']//label[1]"),
            'polygon': str(".//*[@data-toggle='buttons']//label[2]")}
        if shape == 'square':
            self.parent.click(shapes[shape])
        if shape == 'polygon':
            self.parent.click(shapes[shape])
        return True

    @catch_except
    def click_save_button(self, get_alert_data=None):
        """Method to Click on Save Button"""
        xpath = str(".//*[@class='createGeoBoundaryFooter']/button[text()='Save']")
        self.parent.jclick(xpath)
        sleep(2)
        self.parent.clear_web_alerts()
        alert_value = [self.parent.get_attribute_inner_text(".//*[@id='customAlert']/div[2]")]
        self.parent.jclick(".//*[@class='btn btn-primary']")
        if get_alert_data:
            return alert_value
        return True

    @catch_except
    def click_cancel_button(self, get_alert_data=None):
        """Method to Click on Cancel Button"""
        xpath = str(".//*[@class='createGeoBoundaryFooter']/button[text()='Cancel']")
        self.parent.click(xpath)
        sleep(2)
        alert_value = [self.parent.get_attribute_inner_text(".//*[@id='customConfirm']/div[2]")]
        self.parent.click(".//*[@class='btn btn-success confirm']")
        if get_alert_data:
            return alert_value
        return True

    @catch_except
    def click_close_button(self, get_alert_data=None):
        """Method to Click on Close Button"""
        xpath = str(".//*[@class='createGeoBoundaryFooter']//button[text()='Close']")
        self.parent.click(xpath)
        sleep(2)
        alert_value = [self.parent.get_attribute_inner_text(".//*[@id='customConfirm']/div[2]")]
        self.parent.click(".//*[@class='btn btn-success confirm']")
        if get_alert_data:
            return alert_value
        return True

    @catch_except
    def click_on_map(self):
        """Method to Click on any particular location in the Map"""
        xpath = ".//*[@class='MicrosoftMap MapTypeId_auto large']|//*[@class='MicrosoftMapDrawing']"
        self.parent.jclick(xpath)
        return True

    @catch_except
    def click_confirm(self):
        self.parent.click(".//*[@class='btn btn-success confirm']")
        return True

    @catch_except
    def close_dup_create_popup(self):
        """Method to Close the PopUp which pops up while Creating a duplicate Geo Boundary """
        xpath = str(".//*[@class='btn btn-primary']")
        self.parent.click(xpath)
        return True

    @catch_except
    def click_remove_boundary_name(self, flag='search'):
        """Method to click the cross button to Remove the
        Searched Boundary Name from the Search Text box"""
        xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-list"
                    "//span[contains(@class,'glyphicon')]")
        if flag == 'create':
            xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-form"
                        "//span[contains(@class,'glyphicon')]")

        self.parent.click(xpath)
        sleep(2)
        return True

    @catch_except
    def press_esc_boundary_name(self, flag='search'):
        """Method to Remove the Searched Boundary Name from the
        Search Text Box by pressing ESC button"""
        xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-list"
                    "//input[contains(@placeholder,'Enter')]")
        if flag == 'create':
            xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-form"
                        "//input[contains(@placeholder,'Enter')]")
        self.parent.press_esc_button(xpath)
        sleep(2)
        return True

    @catch_except
    def get_attribute_value(self, flag='search'):
        """Method to get the value of the Placeholder Attribute"""
        if flag == 'search':
            xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-list"
                        "//input[contains(@placeholder,'Enter')]")
            search_box_value = self.parent.get_attribute_value(xpath, 'placeholder')
        if flag == 'length':
            xpath = str(".//*[@id='geoNameInput']|.//*[@class='createEditGeoBoundaryPopover']/"
                        "create-geo-boundary-form/div/form/div/input")
            search_box_value = self.parent.get_attribute_value(xpath, 'maxlength')
        if flag == 'create':
            xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-form"
                        "//input[contains(@placeholder,'Enter')]")
            search_box_value = self.parent.get_attribute_value(xpath, 'placeholder')
        if flag == 'color':
            xpath = str(".//*[contains(@class,'colorSelected')]")
            search_box_value = self.parent.get_attribute_value(xpath, 'ng-click')
        if flag == 'shape':
            xpath = str(".//*[contains(@class,'createGeoBoundaryShapeOption  active')]/input")
            search_box_value = self.parent.get_attribute_value(xpath, 'ng-click')
        return search_box_value

    @catch_except
    def get_xpath_value(self, flag='search'):
        """Method to get the value from the xpath"""
        xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-list"
                    "//input[contains(@placeholder,'Enter')]")
        if flag == 'create':
            xpath = str(".//*[@class ='createEditGeoBoundaryPopover']/create-geo-boundary-form"
                        "//input[contains(@placeholder,'Enter')]")
        if flag == 'drop_item':
            xpath = str(".//*[contains(@class,'createGeoBoundaryList noselect')]"
                        "/li[1]/div/label[1]")
        element_value = self.parent.get_value(xpath)
        return element_value

    @catch_except
    def double_click_element(self):
        """Method to double click on an element"""
        xpath = str(".//*[contains(@class,'createGeoBoundaryList noselect')]/li[1]")
        self.parent.double_click(xpath)
        return True

    @catch_except
    def create_polygon(self, point=3, inc=0):
        """Method to Create Geo Polygon"""
        for _ in range(5):
            source = self.parent.driver.find_element_by_id('null')
            print source
            source.click()
            sleep(1)
        if point == 2:
            self.parent.move_to_element_with_offset(source=source, x_offset=120+int(inc), y_offset=-80+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=0+int(inc), y_offset=120+int(inc))
            sleep(2)
        if point == 3:
            self.parent.move_to_element_with_offset(source=source, x_offset=120+int(inc), y_offset=-80+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=0+int(inc), y_offset=120+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=-120+int(inc), y_offset=-80+int(inc))
            sleep(2)
        if point == 6:
            self.parent.move_to_element_with_offset(source=source, x_offset=120+int(inc), y_offset=-80+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=120+int(inc), y_offset=20+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=0+int(inc), y_offset=120+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=-120+int(inc), y_offset=20+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=-120+int(inc), y_offset=-80+int(inc))
            sleep(2)
            self.parent.move_to_element_with_offset(source=source, x_offset=0+int(inc), y_offset=-150+int(inc))
            sleep(2)
        return True

    @catch_except
    def move_point(self, x_offset, y_offset):
        for _ in range(5):
            source = self.parent.driver.find_element_by_class_name('MapPushpinBase')
            source.click()
            sleep(2)
        self.parent.click_and_drag(locator=source, x_offset=int(x_offset), y_offset=int(y_offset))
        return True

    def add_point(self, x_offset, y_offset):
        for _ in range(5):
            source = self.parent.driver.find_element_by_class_name('MapPushpinBase')
            source.click()
            sleep(2)
        self.parent.move_to_element_with_offset(source=source, x_offset=int(x_offset), y_offset=int(y_offset))
        return True

    @catch_except
    def right_click(self):
        xpath = str("(.//*[@class='MapPushpinBase'])[2]")
        self.parent.right_click(xpath)
        return True

    @catch_except
    def move_geo_point(self):
        source = self.parent.driver.find_element_by_id('null')
        self.parent.drag_and_drop_by_offset(source, x_offset=120+10, y_offset=-80-10)
        return True

    @catch_except
    def delete_push_pin(self):
        xpath = str(".//*[@class='binMapContextMenu']/li/a")
        self.parent.jclick(xpath)
        return True

    @catch_except
    def fifty_point(self, inc=0):
        for _ in range(3):
            source = self.parent.driver.find_element_by_id('null')
            source.click()
        self.parent.move_to_element_with_offset(source=source, x_offset=120 + int(inc), y_offset=-80 + int(inc))
        sleep(2)
        self.parent.move_to_element_with_offset(source=source, x_offset=0 + int(inc), y_offset=120 + int(inc))
        sleep(2)
        self.parent.move_to_element_with_offset(source=source, x_offset=-120 + int(inc), y_offset=-80 + int(inc))
        sleep(2)
        return True

