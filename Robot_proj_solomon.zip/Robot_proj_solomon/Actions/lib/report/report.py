import calendar
import datetime
import arrow
import os
import csv
import logging
from ..webinterface import catch_except
from . import LMTTestReport


class Report(object):

    def __init__(self):
        self.filename = ""
        self.foldername = ""
        self.device_under_test = ""
        self.device_type = ""
        self.environment = None
        self.currentstatus = "[green]*Pass*"
        self.result_table = self.get_report_table_header()
        self.html_report = None
        self.teststatus = "skip"
        self.html_report_file_path = ""
        self.csv_file_handle = None

    @catch_except
    def _open(self, suite_name="test suite", description="test run"):
        self.test_suite_name = " ".join([self.filename.replace("_", " ").title(), suite_name.capitalize()])
        self.test_run_name = " ".join([self.filename.replace("_", " ").title(), description.title()])

    @catch_except
    def initialize_report_path(self, pri, sec, environment="QA"):
        current_date = str(datetime.date.isoformat(datetime.date.today()))
        current_date = current_date.split('-')
        current_date[1] = calendar.month_abbr[int(current_date[1])]
        foldername = (str(pri).upper() + "_" + str(sec)
                      + "_" + arrow.utcnow().format("DDdddMMMYYHHmmss"))
        fpath = r".\testresults\{}".format(foldername)
        self.environment = environment
        self.device_under_test = pri
        self.device_type = sec
        if not os.path.isdir(fpath):
            os.makedirs(fpath)
        self.foldername = fpath

    @catch_except
    def create_result_path(self):
        result_path = r"\\".join([self.foldername, self.filename])
        if not os.path.isdir(result_path):
            os.makedirs(result_path)
        return result_path

    @catch_except
    def initialize_log_file(self, filename):
        current_time = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        self.filename = filename
        self._open()
        self.filename = self.filename + "_" + current_time
        # self.foldername = self.create_result_path()
        self.html_report = LMTTestReport()
        self.csv_file_handle = open(r"{}\{}_{}_{}.csv".format(self.foldername,
                                                              self.device_under_test,
                                                              self.device_type,
                                                              arrow.utcnow().
                                                              format("DDdddMMMYYHHmmss")), 'wb')

    @catch_except
    def close_log_file(self):
        pass

    @catch_except
    def setstatus(self, status):
        if self.teststatus != "fail":
            self.teststatus = status
        if "pass" == status.lower():
            self.currentstatus = "[green]*Pass*"
        elif "fail" == status.lower():
            self.currentstatus = "[red]*Fail*"
        elif "skip" == status.lower():
            self.currentstatus = "[blue]*Skip*"
        elif "broken" == status.lower():
            self.currentstatus = "[gray]*Broken*"

    @catch_except
    def get_report_table_header(self):
        return [['Domain', 'Channel', 'Excepted Value', 'Acutal Value', 'Status']]

    @catch_except
    def log_to_html_report_text(self, text):
        if self.html_report:
            self.html_report.add_text(str(text))
        if self.csv_file_handle:
            self.csv_file_handle.write("{},,,,,\n".format(str(text)))

    @catch_except
    def log_to_html_report_subtest(self, text):
        if self.html_report:
            self.html_report.add_subtest(str(text), self.teststatus)
            self.teststatus = "skip"
        if self.csv_file_handle:
            self.csv_file_handle.write("{},{},,,,\n".format(str(text), self.teststatus))

    @catch_except
    def log_to_html_report_note(self, text):
        if self.html_report:
            self.html_report.add_note(str(text))
        if self.csv_file_handle:
            self.csv_file_handle.write("Note:,{},,,,\n".format(str(text)))

    @catch_except
    def log_to_html_report_header(self, text):
        if self.html_report:
            self.html_report.add_header(str(text))
        if self.csv_file_handle:
            self.csv_file_handle.write("Header:,{},,,,\n".format(str(text)))

    @catch_except
    def reset_html_report_table(self):
        if self.html_report:
            self.result_table[:] = self.get_report_table_header()

    @catch_except
    def log_add_to_table(self, value):
        if self.html_report:
            if value[-1] != "":
                self.setstatus(value[-1])
                value[-1] = self.currentstatus
            self.result_table.append(value)

    @catch_except
    def log_to_html_report_table(self, table_header):
        if self.html_report:
            self.html_report.add_table(table_header, self.result_table)
        if self.csv_file_handle:
            try:
                for rowval in self.result_table:
                    self.csv_file_handle.write(",".join([str(x) if x is not None else "" for x in rowval]))
                    self.csv_file_handle.write("\n")
            except Exception as err:
                logging.error(str(err))
        self.reset_html_report_table()

    @catch_except
    def log_header(self, string):
        if self.html_report:
            self.log_to_html_report_header(string)
        if self.csv_file_handle:
            self.csv_file_handle.write("Header:,{},,,,\n".format(str(string)))

        return True

    @catch_except
    def log_image_to_html(self, image_file, text=""):
        if self.html_report:
            self.html_report.add_image(image_file, text)
            return True

    @catch_except
    def log_error_to_html(self, error_string):
        if self.html_report:
            self.html_report.add_caution(error_string)
        if self.csv_file_handle:
            self.csv_file_handle.write("Error:,{},,,,\n".format(str(error_string)))
        return True

    @catch_except
    def close_html_report(self):
        self.html_report_file_path = False
        if self.html_report:
            self.html_report_file_path = \
                self.html_report.end(self.filename, self.test_suite_name,
                                     self.test_run_name, self.environment,
                                     self.foldername, self.device_under_test,
                                     self.device_type)
        if self.csv_file_handle:
            self.csv_file_handle.close()
        return self.html_report_file_path
