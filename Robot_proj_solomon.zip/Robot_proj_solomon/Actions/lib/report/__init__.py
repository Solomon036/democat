import os
import shutil
import sys
import tempfile
import time
import uuid

from lib.report.asciidoc.asciidocapi import AsciiDocAPI


class LMTTestReport(object):
    def __init__(self):
        self.start_time = time.time()

        self.text_file_text = None

        self.subtest_results = list()

        self.image_list = list()

    def add_text(self, text):
        if self.text_file_text:
            self.text_file_text = self.text_file_text + text + "\n\n"
        else:
            self.text_file_text = text + "\n\n"

    def add_pass_text(self):
        self.add_text("[green]#(PASS)#")

    def add_fail_text(self):
        self.add_warning("[red]#(FAIL)#")

    def add_note(self, text):
        self.add_text("NOTE: " + text)

    def add_important(self, text):
        self.add_text("IMPORTANT: " + text)

    def add_warning(self, text):
        self.add_text("WARNING: " + text)

    def add_caution(self, text):
        self.add_text("CAUTION: " + text)

    def add_tip(self, text):
        self.add_text("TIP: " + text)

    def add_header(self, text, description='', level=1):

        if 1 >= level:
            temp = "== "
        elif 2 == level:
            temp = "=== "
        elif 3 == level:
            temp = "==== "
        else:
            temp = "===== "

        self.add_text(temp + text)
        self.add_text(description)

    def add_image(self, image, text="", remove=True):

        # Copy image to new location with a unique name
        temp_file_name = str(uuid.uuid1().hex) + str(os.path.splitext(image)[1])
        temp_file = os.path.join(tempfile.gettempdir() + "\\" + temp_file_name)
        shutil.copy2(image, temp_file)

        # Remove the orginal if requested
        if remove:
            os.remove(image)

        self.image_list.append(temp_file)
        self.add_text(".{}".format(text))
        txt_add = 'image::{0}[height=100,alt="not bad.",align="left",' \
                  'float="left",role="thumb left",link="images/{0}"]'.format(temp_file_name)
        self.add_text(txt_add)

    def add_subtest(self, text, result):
        if result.lower() == 'skip':
            temp = "*" + text + " [blue]#(SKIP)#*"
            self.subtest_results.append([text, -1])
            status = True
        elif result.lower() == 'broken':
            temp = "*" + text + " [gray]#(BROKEN)#*"
            self.subtest_results.append([text, -2])
            status = True

        elif result.lower() == 'pass':
            temp = "*" + text + " [green]#(PASS)#*"
            self.subtest_results.append([text, 1])
            status = True
        else:
            temp = "*" + text + " [red]#(FAIL)#*"
            self.subtest_results.append([text, 0])
            status = False
        temp = temp[:1].lower() + temp[1:].capitalize()
        self.add_header(temp)
        return status

    def add_table(self, table_title, table_data):
        # Set the table title
        temp_text = "." + table_title + "\n"
        temp_text += "[options=\"header\"]\n"

        # Determine the maximum number of characters (including '|' symbols)
        temp_table_length = 0
        for row in table_data:
            temp = len(row) - 1

            for cell in row:
                temp += len(str(cell))

            if temp > temp_table_length:
                temp_table_length = temp

        # Write ASCII doc table pattern
        temp_text += "|"
        y = 0
        while y < temp_table_length:
            temp_text += "="
            y += 1

        # Write table cell data
        y = 0
        for first in table_data:
            temp_text += "\n"

            x = 0
            for value in first:
                temp_text = temp_text + "|" + str(table_data[y][x])
                x += 1
            y += 1

        # Write ASCII doc table pattern
        temp_text += "\n|"
        y = 0
        while y < temp_table_length:
            temp_text += "="
            y += 1
        self.add_text(temp_text)

    def end(self, file_name, feat_name, feat_descrip,
            mach_model, report_dir, dut="", duttype=""):
        # Want to get the summary table to the top of the report. Then everything else.
        non_sum_text = self.text_file_text
        self.text_file_text = None

        # Create title
        if 0 == len(self.subtest_results):
            self.text_file_text = feat_name + "\n"
        else:
            if -2 in [x[1] for x in self.subtest_results]:
                temp = " [gray]*(Broken)*" + "\n"
            else:
                temp = " [blue]*(Skipped)*" + "\n"
            for subtest in self.subtest_results:
                if subtest[1] == 1:
                    temp = " [green]*(Passed)*" + "\n"
                elif subtest[1] == 0:
                    temp = " [red]*(Failed)*" + "\n"
                    break
            self.text_file_text = feat_name + temp

        # Add the ASCIIdoc syntax for a title
        y = len(self.text_file_text) - 1
        temp = ""
        while y >= 0:
            temp += "="
            y -= 1
        self.add_text(temp)

        self.add_header("Description", feat_descrip)

        # Create the test summary table
        pass_num = 0
        fail_num = 0
        skip_num = 0
        broken_num = 0
        summ_table = list()
        summ_table.append(["Test Name", "Result"])
        for subtest in self.subtest_results:
            if subtest[1] == 1:
                summ_table.append([subtest[0], "[green]*Pass*"])
                pass_num += 1
            elif subtest[1] == 0:
                summ_table.append([subtest[0], "[red]*Fail*"])
                fail_num += 1
            elif subtest[1] == -1:
                summ_table.append([subtest[0], "[blue]*Skip*"])
                skip_num += 1
            elif subtest[1] == -2:
                summ_table.append([subtest[0], "[gray]*Broken*"])
                broken_num += 1

        tc_num = len(summ_table) - 1
        # self.pass_percent = "0"
        # self.fail_percent = "0"
        # self.pass_count = "0"
        # self.fail_count = "0"
        # self.total_testcase = "0"

        if not 0 == tc_num:
            self.pass_percent = str(round(float(pass_num) * 100 / float(tc_num), 1)) + "%"
            self.fail_percent = str(round(float(tc_num - pass_num - skip_num - broken_num) * 100 / float(tc_num), 1)) + "%"
            self.skip_percent = str(round(float(tc_num - pass_num - fail_num - broken_num) * 100 / float(tc_num), 1)) + "%"
            self.broken_percent = str(round(float(tc_num - pass_num - skip_num - fail_num) * 100 / float(tc_num), 1)) + "%"
            self.pass_count = pass_num
            self.skip_count = skip_num
            self.fail_count = round(float(fail_num))
            self.broken_count = round(float(broken_num))
            self.total_testcase = tc_num

            # Create the pass/fail text and add it to report
            pass_fail_txt = "Pass: [green]#" + str(pass_num) + "/" + str(tc_num) + " (" + self.pass_percent + ")#\n\n"
            pass_fail_txt += "Fail: [red]#" + str(fail_num) + "/" + str(tc_num) + " (" + self.fail_percent + ")#\n\n"
            pass_fail_txt += "Skip: [blue]#" + str(skip_num) + "/" + str(tc_num) + " (" + self.skip_percent + ")#\n\n"
            pass_fail_txt += "Broken: [gray]#" + str(broken_num) + "/" + str(tc_num) + " (" + self.broken_percent + ")#\n\n"

            # if not pass_num == tc_num:
            #     pass_fail_txt = pass_fail_txt + "Fail: [red]#" + str(tc_num - pass_num) + "/" + str(
            #         tc_num) + " (" + self.fail_percent + ")#"
            # else:
            #     pass_fail_txt = pass_fail_txt + "Fail: " + str(tc_num - pass_num) + "/" + str(
            #         tc_num) + " (" + self.fail_percent + ")"
            self.add_header("Summary", pass_fail_txt, 1)

            # Add the summary table to the report
            self.add_table("Test Summary", summ_table)
        else:
            self.add_header("Summary", "There are no test cases!", 1)

        # Gather git information. We store the cwd we started with so it can be restored once all
        # the git information has been gathered.
        temp = os.getcwd()
        # # print shlex.split("git describe --always --tags")
        # ps_d = subprocess.Popen(shlex.split("git describe --always --tags"), stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        # ps_d_scripts_Stdout, ps_d_scripts_myStderr = ps_d.communicate()
        # print ps_d_scripts_Stdout, ps_d_scripts_myStderr
        #
        # ps_l = subprocess.Popen(shlex.split("git log -1 --format=\"%H\""), stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        # ps_l_scripts_Stdout, ps_l_scripts_myStderr = ps_l.communicate()
        #
        # os.chdir(r'C:\Automation\TURD\TURD\TURD_Workspace')
        # pb_d = subprocess.Popen(shlex.split("git describe --always --tags"), stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        # pb_d_scripts_Stdout, pb_d_scripts_myStderr = pb_d.communicate()
        #
        # pb_l = subprocess.Popen(shlex.split("git log -1 --format=\"%H\""), stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        # pb_l_scripts_Stdout, pb_l_scripts_myStderr = pb_l.communicate()
        os.chdir(temp)

        end_time = time.time()

        duration = time.strftime("%H:%M", time.gmtime(end_time - self.start_time))
        self.start_time = time.strftime("%a, %d %b %Y %H:%M", time.localtime(self.start_time))
        end_time = time.strftime("%a, %d %b %Y %H:%M", time.localtime(end_time))

        # Create section showing configuration stuff
        temp = "*Start Time:*        " + self.start_time + "\n\n" + \
               "*End Time:*     " + end_time + "\n\n" + \
               "*Duration:*     " + duration + " Hours \n\n" + \
               "*Device Under Test:*        " + str(dut) + "\n\n" + \
               "*Device Type:*        " + str(duttype) + "\n\n" + \
               "*User:*         " + os.environ['USERNAME'] + "\n\n" + \
               "*Computer:*     " + os.environ['COMPUTERNAME'] + "\n\n" + \
               "*Program:*      " + "Product Link" + "\n\n" + \
               "*Environement:*        " + str(mach_model) + "\n\n"

        # "*Git script repo:*\n\n"         + "+Tag:+ " + ps_d_scripts_Stdout + "\n\n+Hash:+ " + ps_l_scripts_Stdout + "\n\n" + \
        # "*Git bench setup repo:*\n\n"    + "+Tag:+ " + pb_d_scripts_Stdout + "\n\n+Hash:+ " + pb_l_scripts_Stdout

        self.add_header("Misc. Information", temp)

        # # Print error information to the report if we failed at gathering all required git information.
        # if ps_d.returncode:
        #     self.add_warning("Could not retrieve all Git information for the scripts repo. " + ps_d_scripts_myStderr)
        #
        # if ps_l.returncode:
        #     self.add_warning("Could not retrieve all Git information for the scripts repo. " + ps_l_scripts_myStderr)
        #
        # if pb_d.returncode:
        #     self.add_warning("Could not retrieve all Git information for the bench setups repo. " + pb_d_scripts_myStderr)
        #
        # if pb_l.returncode:
        #     self.add_warning("Could not retrieve all Git information for the bench setups repo. " + pb_l_scripts_myStderr)

        # Write the non summary information now
        if non_sum_text:
            self.add_text(non_sum_text)

        temp_file = os.path.join(tempfile.gettempdir() + "\\" + str(uuid.uuid1().hex) + ".txt")
        text_file = open(temp_file, 'w')
        text_file.write(self.text_file_text)
        text_file.close()

        report_file = report_dir + "\\" + file_name

        # temp = report_dir + r"\images"
        # if os.path.exists(temp):
        #     shutil.rmtree(temp)

        # shutil.copytree(r"C:\GIT_REPOS\asciidoc\images", temp)

        temp = report_dir + "\\" + "images\\"
        temp_icon = report_dir + "\\" + "images\\icons"

        if not os.path.exists(temp):
            os.mkdir(temp)
            #shutil.rmtree(temp)

        if not os.path.exists(temp_icon):
            # os.mkdir(temp_icon)
            shutil.copytree((os.path.dirname(os.path.realpath(__file__))) + "/icons", temp_icon)

        for image in self.image_list:
            shutil.copy2(image, temp)
            os.remove(image)

        report_class = AsciiDocAPI()
        report_class.attributes['toc2'] = "defined"
        # report_class.attributes['numbered'] = "defined"
        report_class.attributes['icons'] = "defined"
        # report_class.attributes['iconsfont'] = "font-awesome"
        report_class.attributes['theme'] = "flask"
        report_class.attributes['imagesdir'] = "images"
        report_class.execute(temp_file, report_file + ".html")
        if not 0 == tc_num:
            self.add_over_status_chart(report_file+".html")
        os.remove(temp_file)
        return report_file + ".html"

    def add_over_status_chart(self, report_file_name):
        import bs4
        from datetime import datetime
        strjavascript = str("""FusionCharts.ready(function () {
            var revenueChart = new FusionCharts({
                type: "doughnut2d",
                renderAt: "chart-container",
                width: "600",
                height: "600",
                dataFormat: "json",
                dataSource: {
                    "chart": {
                        "caption": "Over All Test Run Status",
                        "subCaption": "DATE_TIME",
                        "numberPrefix": "",
                        "paletteColors": "#008000,#ff0000,#0000ff,#808080,#8e0000",
                        "bgColor": "#ffffff",
                        "showBorder": "0",
                        "use3DLighting": "0",
                        "showShadow": "1",
                        "enableSmartLabels": "1",
                        "startingAngle": "310",
                        "showLabels": "1",
                        "showPercentValues": "1",
                        "showLegend": "1",
                        "legendShadow": "0",
                        "legendBorderAlpha": "0",
                        "defaultCenterLabel": "Total No. of Test Cases: NUM_TEST_CASE",
                        "centerLabel": "Total No. of $label: $value%",
                        "centerLabelBold": "1",
                        "showTooltip": "1",
                        "decimals": "0",
                        "captionFontSize": "17",
                        "subcaptionFontSize": "17",
                        "subcaptionFontBold": "0"
                    },
                    "data":
                    [
                        {
                            "label": "Pass",
                            "value": "PASS_VAL%"
                        },
                        {
                            "label": "Fail",
                            "value": "FAIL_VAL%"
                        },
                        {
                            "label": "Skipped",
                            "value": "SKIP_VAL%"
                        },
                        {
                            "label": "Broken",
                            "value": "BROKE_VAL%"
                        },
                    ]
                }
            }).render();
        });""")
        strjavascript = strjavascript.replace("PASS_VAL", str(self.pass_percent))
        strjavascript = strjavascript.replace("FAIL_VAL", str(self.fail_percent))
        strjavascript = strjavascript.replace("SKIP_VAL", str(self.skip_percent))
        strjavascript = strjavascript.replace("BROKE_VAL", str(self.broken_percent))
        strjavascript = strjavascript.replace("NUM_TEST_CASE", str(self.total_testcase))
        d_ti = datetime.utcnow().strftime("%a %b %d %Y %I:%M:%S %p")
        strjavascript = strjavascript.replace("DATE_TIME", d_ti)

        with open(report_file_name) as ht:
            txt = ht.read()
            soup = bs4.BeautifulSoup(txt, "html.parser")
        scrip = soup.new_tag("script", type="text/javascript",
                             src="http://static.fusioncharts.com/code/latest/fusioncharts.js")
        soup.head.insert(6, scrip)
        scrip = soup.new_tag("script", type="text/javascript",
                             src="http://static.fusioncharts.com/code/latest/fusioncharts.theme.fint.js")
        soup.head.insert(7, scrip)
        bod = soup.find(id="_summary")
        scrip_div = soup.new_tag("div", id="chart-container", align="center")
        scrip_div.string = ""
        bod.string.insert_after(scrip_div)
        func_call = soup.new_tag("script", type="text/javascript")
        func_call.string = strjavascript
        soup.head.insert(9, func_call)
        with open(report_file_name, "w") as outf:
            outf.write(str(soup))
