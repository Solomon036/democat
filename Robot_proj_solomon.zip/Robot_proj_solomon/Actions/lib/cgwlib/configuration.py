"""
*******************************************************************************
* COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
-------------------------------------------------------------------------------
**
** FILE NAME:
**     cgwlib/configuration.py
**
** DESCRIPTION:
**     File to get the information of the configuration page from Cat Gateway 2.0.
**
** AUTHOR:
**    Mani Shankar Venkatachalam(venkam5)
** HISTORY:
** Change 00  2017-01-15 (venkam5)
**     Created the Initial Version of the file for strucuture.
**
*******************************************************************************
"""


from time import sleep
from lib.webinterface import catch_except
import time


class Configure(object):
    """ Class to do the operations on Configuration Page."""
    def __init__(self, parent):
        self.parent = parent

    @catch_except
    def get_command_queue(self):
        """ Method that returns the commands queued in the Command Queue. """
        self.parent.go_to_flashlog()
        self.parent.go_to_configure()
        self.parent.wait_till_delay('.//*[@data-ng-repeat="queue in commandqueueList"]')
        sleep(2)
        return self.parent.get_value(("id", "queueTable"))

    @catch_except
    def set_daterange(self):
        "Method to select the today's date range in CGW"
        self.parent.click('.//*[@id="datetimepickerFrom"]')
        date = time.strftime("%d")

    @catch_except
    def wakeup(self, wake="Cellular"):
        """ 
        Method to do the Wake up operation. 
        wake <str> = Type of wakeup to be given based on device type
        """
        comm_type = ["CELLULAR WAKEUP", "SATELLITE WAKEUP", "WIFI/LAN WAKEUP"]
        for comm in comm_type:
            if wake.lower() in comm.lower():
                self.parent.click(".//*[text()='{}']".format(comm))
                sleep(1)
                self.parent.confirm_popup()
                sleep(3)

    @catch_except
    def clear_command_queue(self):
        """  Method to clear the command queue. """
        self.parent.click('.//*[@ng-click="selectAll()"]')
        sleep(0.5)
        self.parent.click('.//*[@id="commandQueueDeleteButton"]')
        sleep(2)
        self.parent.confirm_popup()
        sleep(2)

    @catch_except
    def expand_general_commands(self):
        """ Method to expand the General command section. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@data-ng-click="openConfirmation(5)"]'):
            self.parent.click(("id", "generalCommandsIcon"))
            sleep(0.5)

    @catch_except
    def expand_configuration_files(self):
        """ Method to expand the Configuration file section. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@data-ng-model="selectedConfigurationFileType"]'):
            self.parent.click(("id", "configFilesIcon"))
            sleep(0.5)

    @catch_except
    def expand_firmware(self):
        """ Method to expand the Configuration of the Firmware section. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@data-ng-click="openConfirmation(15)"]'):
            self.parent.click(("id", "firmwareIcon"))
            sleep(0.5)

    @catch_except
    def expand_subscription(self):
        """ Method to expand the Subscription section of the Configuration page."""
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@data-ng-model="selectedOnboardSubscription"]'):
            self.parent.click(("id", "subscriptionChangeIcon"))
            sleep(0.5)

    @catch_except
    def expand_preferred_network(self):
        """ Method to expand the Preferred network section. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@data-ng-click="openConfirmation(37)"]'):
            self.parent.click(("id", "otaspIcon"))
            sleep(0.5)

    @catch_except
    def expand_cdma_radio_configuration(self):
        """ Method to expand the CDMA radio configuration. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@id="VerizonBody"]'):
            self.parent.click(("id", "verizonIcon"))
            sleep(0.5)

    @catch_except
    def expand_gsm_radio_configuration(self):
        """ Method to expand the GSM radio Configuration. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@id="vodafoneBody"]'):
            self.parent.click(("id", "vodafoneIcon"))
            sleep(0.5)

    @catch_except
    def expand_iridium_radio_configuration(self):
        """ Method to expand the iridium radio configuration. """
        self.parent.go_to_configure()
        if self.parent.is_element_present('.//*[@id="iridiumBody"]'):
            self.parent.click(("id", "iridiumIcon"))
            sleep(0.5)


class GeneralCommands(Configure):
    """ Class to do General Commands operation. """
    def __init__(self, parent):
        super(GeneralCommands, self).__init__(parent)

    def _settle_at_general_commands(self):
        """ Method to go to General Commands section. """
        self.parent.go_to_configure()
        self.expand_general_commands()
        sleep(1)

    @catch_except
    def device_reboot(self):
        """ Method to request the device reboot from CGW. """
        self._settle_at_general_commands()
        self.parent.wait_till_delay('.//*[@data-ng-click="openConfirmation(5)"]')
        self.parent.click('.//*[@data-ng-click="openConfirmation(5)"]')
        sleep(1)
        self.parent.confirm_popup()

    @catch_except
    def asset_update_on_demand(self):
        """ Method to request Asset update on Demand from the CGW. """
        self._settle_at_general_commands()
        self.parent.click('.//*[@data-ng-click="openConfirmation(6)"]')
        sleep(1)
        self.parent.confirm_popup()

    @catch_except
    def remote_queue_check_timer(self, timer):
        """ Method to request the remote queue checking timer. """
        self._settle_at_general_commands()
        self.parent.input('.//*[@id="remoteQueueCheckingTimer"]', timer)
        self.parent.click('.//*[@data-ng-click="openConfirmation(7)"]')
        sleep(1)
        self.parent.confirm_popup()

    @catch_except
    def send_command_to_device(self, command_type, command):
        """ 
        Method to send the command to the device.
        command_type <str> = The type id of the command  
        command <str> = The Base 64 format of the command
        """
        self._settle_at_general_commands()
        self.parent.input('.//*[@id="fileTypeNumber"]', command_type)
        self.parent.input('.//*[@id="dataBase64"]', command)
        sleep(1)
        self.parent.click('.//*[@data-ng-click="openConfirmation(8)"]')
        sleep(2)
        self.parent.confirm_popup()

    @catch_except
    def send_short_message_on_demand_to_device(self, message):
        """ Method to request for the Short message on demand. """
        self._settle_at_general_commands()
        self.parent.click(("id", "selectionShortMessageOnDemand"))
        self.parent.click('.//*[@id="selectionShortMessageOnDemand"]/option[text()="{}"]'.format(message))
        self.parent.click('.//*[@data-ng-click="openConfirmation(9)"]')
        sleep(1)
        self.parent.confirm_popup()

    @catch_except
    def data_file_on_demand(self, message):
        """ Method to request data file on demand. """
        self._settle_at_general_commands()
        self.parent.click(("id", "selectionDataFileOnDemand"))
        self.parent.click('.//*[@id="selectionDataFileOnDemand"]/option[text()="{}"]'.format(message))
        self.parent.click('.//*[@data-ng-click="openConfirmation(10)"]')
        sleep(1)
        self.parent.confirm_popup()

    @catch_except
    def send_new_saber_key(self, version=2):
        """ Method to send the New Saber Key to the file.
        By default, Version 2 file will be pushed to the device."""
        self._settle_at_general_commands()
        self.parent.click(("id", "selectionSendNewSABERKeyToDevice"))
        self.parent.click('.//*[@id="selectionSendNewSABERKeyToDevice"]/option[value="{}"]'.format(version))
        self.parent.click('.//*[@data-ng-click="openConfirmation(11)"]')
        sleep(1)
        self.parent.confirm_popup()

    @catch_except
    def transfer_override(self):
        """ Method to request for the transfer override. """
        self._settle_at_general_commands()
        self.parent.click(("id", "selectionTransferOverride"))
        self.parent.click('.//*[@data-ng-click="openConfirmation(34)"]')
        sleep(1)
        self.parent.confirm_popup()


class ConfigurationFile(Configure):
    """ Class to do the operation of the Configuration file. """
    def __init__(self, parent):
        super(ConfigurationFile, self).__init__(parent)

    @catch_except
    def _settle_at_configuration_file(self):
        """ Method to go to the Configuration file. """
        self.parent.go_to_configure()
        sleep(1)
        self.expand_configuration_files()
        sleep(0.5)

    @catch_except
    def upload_file(self, filetype, filepath):
        """ Method to upload a file to CGW."""
        self._settle_at_configuration_file()
        self.parent.click(("data-ng-model", "selectedConfigurationFileType"))
        sleep(1)
        self.parent.click('.//*[@data-ng-model="selectedConfigurationFileType"]/option[@label="{}"]'.format(filetype))
        sleep(2)
        element = self.parent.find_element_by_xpath('.//*[@id="fileinputConfigurationFile"]')
        if element:
            element.send_keys(filepath)
        sleep(2)
        self.parent.click('.//*[@ng-click="openConfirmation(12)"]')
        sleep(1)
        self.parent.confirm_popup()
        sleep(2)
        self.parent.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1 * 60)


class Firmware(Configure):
    """ Class to do the operation of the Firmware. """
    def __init__(self, parent):
        super(Firmware, self).__init__(parent)

    def _settle_at_firmware(self):
        """ Method to go to Firmware Page. """
        self.parent.go_to_configure()
        sleep(1)
        self.expand_firmware()
        sleep(1)

    @catch_except
    def get_current_firware(self):
        """ Mehod to get the last updated firmware infromation from CGW. """
        self._settle_at_firmware()
        return self.parent.get_value('//*[@id="deviceFirmWareBody"]/div/div[2]/div[1]')

    @catch_except
    def request_current_firware(self):
        """ Method to request the current firmware version from the device. """
        self._settle_at_firmware()
        self.parent.click('.//*[@data-ng-click="openConfirmation(15)"]')
        sleep(2)
        self.parent.confirm_popup()

    @catch_except
    def get_firmware_flash_status(self):
        """ Method to get the firmware flash status. """
        self._settle_at_firmware()
        return (self.parent.get_value('//*[@id="deviceFirmWareBody"]/div/div[3]/div[1]'),
                self.parent.get_value('//*[@id="deviceFirmWareBody"]/div/div[4]/label'))

    @catch_except
    def request_firware_flash_status(self):
        """ Method to get the frimware flash status from the device. """
        self._settle_at_firmware()
        self.parent.click('.//*[@data-ng-click="openConfirmation(16)"]')
        sleep(2)
        self.parent.confirm_popup()

    @catch_except
    def upload_frimware(self, firmwarepath):
        """ Method to upload the flash file infromation to the device. """
        self._settle_at_firmware()
        element = self.parent.find_element_by_xpath('.//*[@id="fileinputFirmwareFile"]')
        if element:
            element.send_keys(firmwarepath)
        sleep(2)
        self.parent.click('.//*[@data-ng-click="openConfirmation(14)"]')
        sleep(1)
        self.parent.confirm_popup()
        sleep(2)
        self.parent.wait_till_inactive_delay('.//*[@id="loading-bar"]', 2 * 60)




class Subscription(Configure):
    """ Class file to do the Subscription operation in CGW. """
    def __init__(self, parent):
        super(Subscription, self).__init__(parent)

    @catch_except
    def _settle_at_subscription(self):
        """ Method to go to Subscription Page. """
        self.parent.go_to_configure()
        sleep(1)
        self.expand_subscription()
        sleep(0.5)

    @catch_except
    def get_subscription_status(self):
        """ Method to get the Subscription Status. """
        self._settle_at_subscription()
        return (self.parent.get_value('//*[@id="subscriptionChangeBody"]/div/div[2]/div'),
                self.parent.get_value('//*[@id="subscriptionChangeBody"]/div/div[3]/div[1]'))

    @catch_except
    def request_subscription_status(self):
        """" Method to request the Subscrpition Status from Device. """
        self._settle_at_subscription()
        self.parent.click('.//*[@data-ng-click="openConfirmation(17)"]')
        sleep(1)


class PreferredNetwork(Configure):
    """ Class to perform the operation in Preferred Network. """
    def __init__(self, parent):
        super(PreferredNetwork, self).__init__(parent)

    @catch_except
    def _settle_at_preferred_network(self):
        """ Method to go to Preferred Network. """
        self.parent.go_to_configure()
        sleep(1)
        self.expand_preferred_network()
        sleep(0.5)

    @catch_except
    def get_preferred_network(self):
        """ Method to get the Preferred Network. """
        self._settle_at_preferred_network()
        return self.parent.get_value('.//*[@id="deviceOTASPBody"]/div/div[2]/div')

    @catch_except
    def request_preferred_network(self):
        """ Method to request the preferred network. """
        self._settle_at_preferred_network()
        self.parent.click('.//*[@data-ng-click="openConfirmation(37)"]')
        sleep(2)
        return True

    @catch_except
    def set_preferred_network(self, gsm_or_cdma='gsm'):
        """ Method to set the Preferred Network to the device."""
        self._settle_at_preferred_network()
        if gsm_or_cdma.lower() == 'gsm':
            self.parent.click('.//*[@data-ng-click="openConfirmation(33)"]')
        elif gsm_or_cdma.lower() == 'cdma':
            self.parent.click('.//*[@data-ng-click="openConfirmation(32)"]')
        sleep(2)
        return True


class RadioConfiguration(Configure):
    """ Class to do the operation on Radion Configuration Page."""
    def __init__(self, parent):
        super(RadioConfiguration, self).__init__(parent)

    @catch_except
    def _settle_at_radio_configuration(self, gsm_or_cdma_or_sat='gsm'):
        """ Method to go to the Radio configuration page in CGW. """
        self.parent.go_to_configure()
        sleep(1)
        if gsm_or_cdma_or_sat.lower() == 'gsm':
            self.expand_gsm_radio_configuration()
        elif gsm_or_cdma_or_sat.lower() == 'cdma':
            self.expand_cdma_radio_configuration()
        elif gsm_or_cdma_or_sat.lower() == 'sat':
            self.expand_iridium_radio_configuration()

    @catch_except
    def get_cdma_info(self):
        """ Method to get the CDMA info. """
        self._settle_at_radio_configuration('cdma')
        data = {
            "Device ID": self.parent.get_value('.//*[@id="VerizonBody"]/div/div[2]/div[1]'),
            "MEID": self.parent.get_value('.//*[@id="VerizonBody"]/div/div[2]/div[2]'),
            "Equipment Serial Number": self.parent.get_value('//*[@id="VerizonBody"]/div/div[3]/div[1]'),
            "IMSI": self.parent.get_value('//*[@id="VerizonBody"]/div/div[3]/div[2]')
        }
        return data

    @catch_except
    def get_cdma_current_info(self):
        """ Method to request of the CDMA Currnet Info. """
        self._settle_at_radio_configuration('cdma')
        return self.parent.get_value('.//*[@ng-hide="xmlHolder"]')

    @catch_except
    def get_gsm_info(self):
        """ Method to get the GSM info. """
        self._settle_at_radio_configuration('gsm')
        data = {
            "Device ID": self.parent.get_value('//*[@id="vodafoneBody"]/div/div[2]/div[1]'),
            "MEID": self.parent.get_value('.//*[@id="vodafoneBody"]/div/div[2]/div[2]'),
            "Equipment Serial Number": self.parent.get_value('//*[@id="vodafoneBody"]/div/div[3]/div[1]'),
            "IMSI": self.parent.get_value('//*[@id="vodafoneBody"]/div/div[3]/div[2]')
        }
        return data

    @catch_except
    def get_gsm_trans_status(self):
        """ Method to get the GSM transmission Status. """
        self._settle_at_radio_configuration('gsm')
        return self.parent.get_value('.//*[@id="vodafoneBody"]/div/div[4]/div[2]/div[2]/label')

    @catch_except
    def set_transform_to_brazil_sim(self):
        """ Method to Set the Transfrom to brazil SIM."""
        self._settle_at_radio_configuration('gsm')
        self.parent.click('.//*[@data-ng-click="openConfirmation(25)"]')
        sleep(2)
        return True
