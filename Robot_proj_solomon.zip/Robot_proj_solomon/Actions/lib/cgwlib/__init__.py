"""
Package for data extraction from Cat Gateway 2.0.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     cgwlib/__init__.py
# **
# ** DESCRIPTION:
# **     Package for data extraction from Cat Gateway 2.0.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """

import os
import logging
from time import sleep
from lib.cgwlib import configuration, reports, manage
from lib.cgwlib.transactions import transactions, messageinfo
from lib.webinterface import WebInterface, catch_except, Keys


class CatGateway(WebInterface):
    """ Parent Class for Cat Gateway Library.
        :argument WebInterface:  Inherits the Webinterface Class.
    """
    def __init__(self):
        super(CatGateway, self).__init__()
        self.transaction = transactions.Transaction(self)
        self.messages = messageinfo.MessageInfo(self)
        self.configure = configuration.Configure(self)
        self.generalcmd = configuration.GeneralCommands(self)
        self.configfile = configuration.ConfigurationFile(self)
        self.firmware = configuration.Firmware(self)
        self.preferrednetwork = configuration.PreferredNetwork(self)
        self.subscription = configuration.Subscription(self)
        self.radioconfig = configuration.RadioConfiguration(self)
        self.reports = reports.Reports(self)
        self.manage = manage.Manage(self)
        self.device_inventory = manage.DeviceInventory(self)
        self.promotions = manage.Promotions(self)
        self.subscription_services = manage.SubcriptionServices(self)
        self.base_url = None
        self.assetname = None

    @catch_except
    def login(self, url, user_name, password):
        """
        Method for Login function.
        url: URL of the website.
        user_name = UserName for login.
        password = Password for login.
        """
        self.init_driver()
        self.base_url = url
        logged_in = False
        login_error = False
        while not logged_in and not login_error:
            self.enter_url(url)
            sleep(2)
            self.wait_till_delay(".//*[@id='cwsUID']")
            self.input(".//*[@id='cwsUID']", user_name)
            self.input(".//*[@id='cwsPwd']", password)
            self.submit()
            self.wait_till_delay('.//*[@id="imgCaterpillar"]')
            logged_in = self.is_element_present('.//*[@id="imgCaterpillar"]')
            login_error = self.is_element_present('.//*[@id="login_status"]')
            if login_error:
                logging.error("Incorrect Username Password Error!! for CatGateway.")
                # os._exit(1)
                return False
        self.wait_till_delay('.//*[@id="searchBox"]')
        return True

    @catch_except
    def submit(self):
        """ Method for submit the user credential. """
        self.click(".//*[@id='submitButton']")
        return True

    @catch_except
    def cgw_search_conf_data(self, serialnum):
        """ Method to go to dash board page"""
        self.input("//*[@id='searchBox']", serialnum)
        self.click("//*[contains(text(),'"+serialnum+"']")
        self.click("//*[@id='configTab']/a")
        return True

    @catch_except
    def verify_cgw_subscription_command(self, subscription):
        """ Method to click equip care advisor """
        status = False

        if "|" in subscription:
            val = subscription.split("|")
            subscription = val[0]
        if subscription in self.get_value("//*[@id='queueTable']/table/tbody"):
            status = True
        return [status, subscription]

    @catch_except
    def get_cgw_subs_command(self):
        """ Method to click equip care advisor """
        val = self.get_value("//*[@id='queueTable']/table/tbody")
        return val

    @catch_except
    def cgw_clear_terminal(self):
        """ Method to click equip care advisor """

        val = self.get_value("//*[@id='queueTable']/table/tbody")
        if val == "":
            print ""
        else:
            self.click("//*[@id='tabContent']/div/div[3]/div[2]/div/button[1]/span")
            sleep(3)
            self.click("//*[@class='page ng-scope']//*[@id='commandQueueDeleteButton']/span")
            sleep(3)
            self.click("//button[contains(text(),'Confirm')]")
            sleep(7)

    @catch_except
    def get_cgw_xml_command(self, xmlfile):
        """ Method to click equip care advisor """
        return xmlfile in self.get_value("//*[@id='queueTable']/table/tbody")

    @catch_except
    def search_asset(self, asset_name, mac_address):
        """
        Method to Search the asset.
        asset_name = Equipment Serial Number for Search.
        mac_address = MAC address of the asset, without colon (:).
        """
        page_loaded = False
        iteration = 0
        while not page_loaded:
            self.input(("id", "searchBox"), asset_name)
            sleep(2)
            self.find_element_by_id("searchBox").send_keys(Keys.ENTER)
            self.wait_till_delay(("title", "{}".format(asset_name)))
            self.wait_till_delay('.//*[contains(@title, "{}")]'.format(mac_address))
            self.click('.//*[contains(@title, "{}")]'.format(mac_address))
            self.wait_till_delay(("id", "divTransactionList"), 1*20)
            page_loaded = self.is_element_present(("id", "divTransactionList"))
            if iteration > 10 or page_loaded:
                break
            else:
                self.refreshdriver()
                sleep(5)
                iteration += 1
        return True

    @catch_except
    def cgw_search_sn(self, asset_name):
        """
        Method to Search the asset.
        asset_name = Equipment Serial Number for Search.
        mac_address = MAC address of the asset, without colon (:).
        """
        self.driver.refresh()
        self.input("//*[@id='searchBox']", asset_name)
        sleep(2)
        self.click('//*[@id="liBtnSearchGroup"]/div/i')
        sleep(5)
        try:
            self.click("//*[contains(text(),':N')]")
            sleep(2)
            self.click("//*[contains(text(),'" + asset_name + "')]")
        except:
            sleep(2)
            self.click("//*[contains(text(),'" + asset_name + "')]")
        sleep(2)
        self.click("//*[@id='configTab']/a")
        self.wait_till_delay('.//*[@id="loading-bar"]')
        self.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1*60)
        sleep(5)
        return True

    @catch_except
    def go_to_transactions(self):
        """ Method to go to Transaction page to read Messages. """
        self.click(("id", "transactionsTab"))
        sleep(2)
        # self.wait_till_delay('.//*[@id="loading-bar"]')
        self.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1*60)
        sleep(5)
        return True

    @catch_except
    def go_to_configure(self):
        """ Method to go to Configuration Page. """
        self.click(('id', "configTab"))
        sleep(2)
        self.wait_till_delay('.//*[@id="loading-bar"]')
        self.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1*60)
        sleep(5)
        self.wait_till_delay('.//*[text()="CELLULAR WAKEUP"]')
        self.wait_till_delay(("id", "queueTable"))
        sleep(2)
        return True

    @catch_except
    def go_to_flashlog(self):
        """ Method to go to Flash Log Page."""
        self.click(('id', "reportsTab"))
        sleep(1)
        self.click(('id', "flashLogTab"))
        sleep(2)
        self.wait_till_delay('.//*[@ng-repeat="report in flashLogList"]')
        return True

    @catch_except
    def go_to_rate_plan_log(self):
        """" Method to go to Rate Plan Log. """
        self.click(('id', "reportsTab"))
        sleep(1)
        self.click(('id', "ratePlanLogTab"))
        sleep(2)
        self.wait_till_delay(("id", "tabContent"))
        return True

    @catch_except
    def go_to_device_inventory(self):
        """" Method to go Device Inventory. """
        self.click(("id", "manageTab"))
        sleep(1)
        self.click(("id", "devInvTab"))
        self.wait_till_delay(("id", "resTable"))
        sleep(2)
        return True

    @catch_except
    def go_to_firmware_library(self):
        """" Method to Go to Firmware Library. """
        self.click(("id", "manageTab"))
        sleep(1)
        self.click(("id", "firmwareTab"))
        self.wait_till_delay(("id", "firmwareStickyHeader"))
        sleep(2)
        return True

    @catch_except
    def go_to_promotions(self):
        """ Method to Go to Promotions Page."""
        self.click(("id", "manageTab"))
        sleep(1)
        self.click(("id", "promotionsTab"))
        self.wait_till_delay(("id", "promotionalProgramId"))
        sleep(2)
        return True

    @catch_except
    def go_to_subscription(self):
        """  Method to go to subscription page. """
        self.click(("id", "manageTab"))
        sleep(1)
        self.click(("id", "searchTab"))
        self.wait_till_delay(("id", "subs_id"))
        return True

    @catch_except
    def confirm_popup(self):
        """ Method to confirm any action pop-ups. """
        self.click('.//*[text()="Confirm"]')
        sleep(2)
        for loop in self.driver.find_elements_by_xpath('.//*[@class="glyphicon glyphicon-remove"]'):
            loop.click()
            sleep(0.5)
        sleep(1)

    @catch_except
    def continue_session(self):
        """ Method to continue the session, when the page got time-out. """
        self.click(("ng-click", "closeAndResume()"))
        sleep(2)
        return True

    @catch_except
    def logout(self):
        """ Method to log-out the Cat Gateway. """
        count = 0
        self.click(("ng-click", "logout($event)"))
        while self.get_page_title() != "Login" and count < 20:
            sleep(0.5)
            count += 1
        self.close()
        return True
