"""
*******************************************************************************
* COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
-------------------------------------------------------------------------------
**
** FILE NAME:
**     cgwlib/manage.py
**
** DESCRIPTION:
**     File to get the information of the Manage page from Cat Gateway 2.0.
**
** AUTHOR:
**    Mani Shankar Venkatachalam(venkam5)
** HISTORY:
** Change 00  2017-01-15 (venkam5)
**     Created the Initial Version of the file for strucuture.
**
*******************************************************************************
"""

from time import sleep
from lib.webinterface import catch_except


class Manage(object):
    """ Class to do the operation on Manage Page. """
    def __init__(self, parent):
        self.parent = parent

    @catch_except
    def _settle_at_device_inventory(self):
        """ Method to go to Device Inventory."""
        self.parent.go_to_device_inventory()
        sleep(1)
        return True

    @catch_except
    def settle_at_firmware_library(self):
        """ Method to go to firmware library. """
        self.parent.go_to_firmware_library()
        sleep(1)
        return True


class DeviceInventory(Manage):
    """ Class to do the operation in Device Inventory. """
    def __init__(self, parent):
        super(DeviceInventory, self).__init__(parent)

    @catch_except
    def get_device_inventory_info(self):
        """ Method to get Device Inventory Info. """
        self._settle_at_device_inventory()
        row = self.parent.driver.find_element_by_xpath('.//*[@id="searchResult"]')
        cols = row.find_elements_by_tag_name('td')
        info = {
            "Device ID": self.parent.get_value_by_element(cols[0]),
            "Module Type": self.parent.get_value_by_element(cols[1]),
            "Onboarded Date": self.parent.get_value_by_element(cols[2]),
            "Module Serial Number": self.parent.get_value_by_element(cols[3]),
            "Equipment Make": self.parent.get_value_by_element(cols[4]),
            "Equipment Serial Number": self.parent.get_value_by_element(cols[5]),
        }
        return info

    @catch_except
    def _get_element_status(self, xpath):
        """ Method to get the Element Status. """
        element = self.parent.find_element_by_xpath(xpath)
        return catch_except(element.get_attribute)('disabled')

    @catch_except
    def _get_value_if_enabled(self, xpath):
        """ Method to get the value of the element if it is enabled. """
        if self._get_element_status(xpath):
            return self.parent.get_value(xpath)
        return False

    @catch_except
    def get_device_inventory_detailed_info(self):
        """ Method to get the Device Inventory Detailed info"""
        self.parent.click('.//*[@data-ng-click="openDeviceInventoryInfo(deviceInventory.device_id)"]')
        sleep(1)
        self.parent.wait_till_delay('.//*[@role="alertdialog"]', 60)
        sleep(2)
        return (self.get_static_device_parameters(), self.get_dynamic_device_parameters(),
                self.get_cellular_radio_parameters(), self.get_satellite_radio_parameters())

    @catch_except
    def get_static_device_parameters(self):
        """ Method to get he static device parameters. """
        class StaticDeviceParameter(object):
            """ Class to hold the infromation of the Staic Device parameter. """
            device_id = None
            onboarded_date = None
            module_type = None
            last_updated_id = None
            suspended_device = None
            last_suspension_update_user_id = None
            enable_engineering_swaps = None

        info = StaticDeviceParameter()
        info.device_id = self.parent.get_value('.//*[@id="deviceIdValue"]')
        info.onboarded_date = self.parent.get_value('.//*[@id="deviceOnboardedDateValue"]')
        info.module_type = self.parent.get_value('.//*[@id="moduleTypeValue"]')
        info.last_updated_id = self.parent.get_value('.//*[@id="lastUpdatedIdValue"]')
        info.suspended_device = self._get_element_status('.//*[@id="suspendedDeviceValue"]/input')
        info.last_suspension_update_user_id = self.parent.get_value('.//*[@id="lastSuspensionUpdateUserIdValue"]')
        info.enable_engineering_swaps = self._get_element_status('.//*[@id="enableEngineeringSwapsValue"]/input')
        return info

    @catch_except
    def get_dynamic_device_parameters(self):
        """ Method to get the Dynamic Device Parameters. """
        class DynamicDeviceParameters(object):
            """ Class to get the Dynamic Device Parameters. """
            equipment_make = None
            module_make = None
            equipment_serial_number = None
            module_serial_number = None
            software_part_number = None

        info = DynamicDeviceParameters()
        info.equipment_make = self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.eq_make"]')
        info.module_make = self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.md_make"]')
        info.equipment_serial_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.eq_sn"]')
        info.module_serial_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.eq_make"]')
        info.software_part_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.eq_make"]')
        return info

    @catch_except
    def get_cellular_radio_parameters(self):
        """ Method to get the Cellular radio parameters. """
        class CellularRadioParameters(object):
            """ Class to hold the Cellular Radio Parameter."""
            cell_radio_type = None
            cell_software_part_number = None
            cell_radio_serial_number = None
            cell_hardware_part_number = None
            cell_port = None
            cell_time_stamp = None
            cell_imei = None
            cell_iccid = None
            cell_meid = None
            cell_imsi = None
            mdn = None
            esn = None
            cdma_preferred = None
            cell_radio_device_id = None
            disable_auto_preferred = None

        info = CellularRadioParameters()
        info.cell_radio_type = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_type"]')
        info.cell_software_part_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_soft_pn"]')
        info.cell_radio_serial_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_sn"]')
        info.cell_hardware_part_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_hard_pn"]')
        info.cell_port = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_port"]')
        info.cell_time_stamp = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_ts"]')
        info.cell_imei = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_imei"]')
        info.cell_iccid = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_iccid"]')
        info.cell_meid = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_meid"]')
        info.cell_imsi = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_imsi"]')
        info.mdn = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_mdn"]')
        info.esn = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_esn"]')
        info.cell_radio_device_id = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.cell_id"]')
        info.cdma_preferred = \
            self._get_element_status('.//*[@id="cdmaPreferredValue"]/input')
        info.disable_auto_preferred = \
            self._get_element_status('.//*[@id="preferredNetworkValue"]/input')

    @catch_except
    def get_satellite_radio_parameters(self):
        """ Method to get the Satellite radio Parameters. """
        class SatelliteRadioParameter(object):
            """ Class to hold the Satellite Radio Parameter. """
            sat_radio_type = None
            sat_software_part_number = None
            sat_radio_serial_number = None
            sat_hardware_part_number = None
            sat_port = None
            sat_imei = None
            sat_time_stamp = None
            sta_iccid = None
            sat_msisdn = None
            sat_radio_device_id = None

        info = SatelliteRadioParameter()
        info.sat_radio_type = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_type"]')
        info.sat_software_part_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_soft_pn"]')
        info.sat_radio_serial_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_sn"]')
        info.sat_hardware_part_number = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_hard_pn"]')
        info.sat_port = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_port"]')
        info.sat_time_stamp = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_ts"]')
        info.sat_imei = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_imei"]')
        info.sta_iccid = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_iccid"]')
        info.sat_msisdn = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_msisdn"]')
        info.sat_radio_device_id = \
            self._get_value_if_enabled('.//*[@data-ng-model="selectedDeviceInventory.detail.sat_id"]')
        return info

    @catch_except
    def export_filtered(self):
        """ Method to export the filtered messages. """
        self.parent.click('.//*[@id="exportPromotionButton"]')
        sleep(10)


class FirmwareLibrary(Manage):
    """ Class to do operation in Firmware Library. """
    def __init__(self, parent):
        super(FirmwareLibrary, self).__init__(parent)

    @catch_except
    def _upload_firmware_to_library(self, file_path):
        """ Method to upload firmware to the library  of CGW. """
        self.parent.input('.//*[@id="fileinput"]', file_path)
        sleep(1)
        self.parent.click('.//*[@ng-click="uploadFile()"]')
        sleep(10)
        return True


class Promotions(Manage):
    """ Class to do operation in Promotions.
    This feature is not yet developed.
    """
    def __init__(self, parent):
        super(Promotions, self).__init__(parent)


class SubcriptionServices(Manage):
    """ Class to do operation in Subscription Services.
        This feature is not yet developed.
    """
    def __init__(self, parent):
        super(SubcriptionServices, self).__init__(parent)
