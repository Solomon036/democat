"""
Package for data extraction Message Info based on message type from Cat Gateway 2.0.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     cgwlib/transactions/messageinfo.py
# **
# ** DESCRIPTION:
# **     Package for data extraction Message Info based on message type from Cat Gateway 2.0.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# ** HISTORY:
# ** Change 00  2017-01-15 (venkam5)
# **     Created the Initial Version of the file for strucuture.
# **
# *******************************************************************************
# """


import logging
from xml.etree import ElementTree
from lib.webinterface import catch_except
from lib.cgwlib.transactions import messagestructure
from time import sleep

class MessageInfo(object):
    """ Class for getting Message Info for different messages. """
    def __init__(self, parent):
        self.parent = parent



    @staticmethod
    def _create_header_info_instance():
        """ Method to create a instance for header information of the message. """
        class MsgHeader(object):
            """ Class to hold the Message header information. """
            module_sn = ''
            module_type = ''
            module_device_id = ''
            message_id = ''
            file_type_id = ''
            message_gateway = ''
            device_gateway = ''
            message_protocol = ''
            transport_protocol = ''
            number_of_records = ''
        return MsgHeader()

    @staticmethod
    def _getattrib(root, tag, attrib):
        """
        Method to information from xml based on attributes.
        root: Root of the xml info of the message.
        tag: XML tag of the message.
        attrib: Attribute for which the value to be fetched.
        """
        try:
            return root.find(tag).attrib[attrib]
        except Exception as err:
            logging.error(str(err))
            return "No Data"

    @staticmethod
    def _gettext(root, tag):
        """
         Method to get the text information of a xml tag.
         root: Root of the xml.
         tag: Tag information of the xml.

        """
        try:
            return root.find(tag).text
        except Exception as err:
            logging.error(str(err))
            return "No Data"

    @staticmethod
    def _getrecordinfo(xml, record):
        """
        Method to get the header and data information of the xml based on message type.
        xml: XML to be parsed.
        record: Record to be used for getting data about the message.
        """
        root = ElementTree.fromstring(xml)
        headerroot = root.find('Header')
        dataroot = root.find('Data')
        datarecords = dataroot.findall('./{0}'.format(record))
        return headerroot, datarecords

    @catch_except
    def _get_message_header_info(self, headerrecordinfo):
        """ Method to parse the header information of the Message. """
        headerrecord = self._create_header_info_instance()
        headerrecord.module_sn = self._gettext(headerrecordinfo, 'ModuleSerialNumber')
        headerrecord.module_type = self._gettext(headerrecordinfo, 'ModuleType')
        headerrecord.module_device_id = self._gettext(headerrecordinfo, 'ModuleDeviceID')
        headerrecord.message_id = self._gettext(headerrecordinfo, 'MessageID')
        headerrecord.file_type_id = self._gettext(headerrecordinfo, 'FileTypeID')
        headerrecord.message_gateway = self._gettext(headerrecordinfo, 'MessageGateway')
        headerrecord.device_gateway = self._gettext(headerrecordinfo, 'DeviceGateway')
        headerrecord.message_protocol = self._gettext(headerrecordinfo, 'MessageProtocol')
        headerrecord.transport_protocol = self._gettext(headerrecordinfo, 'TransportProtocol')
        headerrecord.number_of_records = self._gettext(headerrecordinfo, 'NumberOfRecords')
        return headerrecord

    @catch_except
    def get_battery_voltage(self, xmlstring, record='BatteryVoltageRecord'):
        """  Method to get the battery voltage message information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_battey_voltage_instance()
            datarecord.utctimestamp = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.gps_latitiude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gps_longitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gps_location_status = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gps_source_not_available_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gps_status_invalid_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gps_filtered_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gps_altitude_type = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gps_fix_type = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gps_connection_available_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gps_fix_not_available_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.battery_voltage = self._gettext(recordinfo, 'BatteryVoltage')
            data['DataRecord'].append(datarecord)
        return data

    def get_ecminfo_v3(self, xmlstring, record='ECMInfoVer3Record'):
        """  Method to get the ECM Info V3 Message Information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_ecminfov3_instance()
            datarecord.utctimestamp = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.hardware_pn = self._gettext(recordinfo, 'ECMHardwarePartNumber')
            datarecord.serial_num = self._gettext(recordinfo, 'ECMSerialNumber')
            datarecord.software_pn = self._gettext(recordinfo, 'SoftwarePartNumber')
            datarecord.engine_ecm_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/EngineECMFlag')
            datarecord.transmission_ecm_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/TransmissionECMFlag')
            datarecord.cdl_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/CDLFlag')
            datarecord.j1939_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/J1939Flag')
            datarecord.j1939_deviceid_include_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/J1939DeviceIDIncludedFlag')
            datarecord.ethernet_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/EthernetFlag')
            datarecord.ethernet_deviceid_include_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/EthernetDeviceIDIncludedFlag')
            datarecord.public_name_include_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/PublicNameIncludedFlag')
            datarecord.acting_master_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/ActingMasterECMFlag')
            datarecord.sync_clock_protocol_supported_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/SynchClockProtocolSupportedFlag')
            datarecord.troubleshooting_code_protocol_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformationV3/TroubleshootingCodeProtocol')
            datarecord.public_name = self._getattrib(recordinfo, 'PublicName', 'hex')
            datarecord.identity_number = self._gettext(recordinfo, 'PublicName/IdentityNumber')
            datarecord.manufacturer_code = self._gettext(recordinfo, 'PublicName/ManufacturerCode')
            datarecord.ecu_instance = self._gettext(recordinfo, 'PublicName/ECUInstance')
            datarecord.function_instance = self._gettext(recordinfo, 'PublicName/FunctionInstance')
            datarecord.function = self._gettext(recordinfo, 'PublicName/Function')
            datarecord.vehicle_system = self._gettext(recordinfo, 'PublicName/VehicleSystem')
            datarecord.vehicle_system_instance = \
                self._gettext(recordinfo, 'PublicName/VehicleSystemInstance')
            datarecord.industry_group = self._gettext(recordinfo, 'PublicName/IndustryGroup')
            datarecord.arbitary_address_capable = \
                self._gettext(recordinfo, 'PublicName/ArbitraryAddressCapable')
            data['DataRecord'].append(datarecord)
        return data


    def get_fuel_basic(self, xmlstring, record='FuelBasicVer2Record'):
        """ Method to get the Fuel Basic Ver2 Record. """
        headerrecordinfo, datarecordinfo = \
            self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord':
                         self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_fuel_basic_instance()
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.utctimestamp = \
                self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.total_max_fuel = self._gettext(recordinfo, 'TotalMaxFuel')
            datarecord.total_idle_time = self._gettext(recordinfo, 'TotalIdleTime')
            datarecord.total_idle_fuel = self._gettext(recordinfo, 'TotalIdleFuel')
            datarecord.total_fuel_used = self._gettext(recordinfo, 'TotalFuelUsed')
            datarecord.num_of_engine_starts = \
                self._gettext(recordinfo, 'NumberOfEngineStarts')
            datarecord.lifetime_eng_rev = \
                self._gettext(recordinfo, 'LifetimeTotalEngineRevolutions')
            data['DataRecord'].append(datarecord)
        return data

    @catch_except
    def get_fuel_level(self, xmlstring, record='FuelLevelRecord'):
        """ Method to get the Fuel level Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
          if self._gettext(recordinfo, 'FuelLevel') != '255':
            datarecord = messagestructure.get_fuel_level_instance()
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.utctimestamp = \
                self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.fuel_level = self._gettext(recordinfo, 'FuelLevel')
            data['DataRecord'].append(datarecord)
        return data


    @catch_except
    def get_geotime_fence_status(self, xmlstring, record='GeoTimeFenceStatusRecord'):
        """ Method to get the Geo Fence Status Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord':
                         self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_geotimefence_status_instance()
            datarecord.fenceid = self._gettext(recordinfo, 'FenceID')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.gps_radio_sourceid = \
                self._gettext(recordinfo, 'GPSRadioSourceID')
            data['DataRecord'].append(datarecord)
        return data

    @catch_except
    def get_hoursloc(self, xmlstring, record='HoursLocRecord'):
        """ Method to get the HoursLoc Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord':
                         self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_hours_loc_instance()
            datarecord.utctimestamp = self._gettext(
                recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.total_operating_hours = \
                self._gettext(recordinfo, 'TotalOperatingHours')
            datarecord.latitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.longitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.height = self._gettext(recordinfo, 'GPSHeight')
            datarecord.location_status = \
                self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gps_source_not_available_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gps_status_invalid_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gps_filtered_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gps_altitude_type = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gps_fix_type = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gps_correction_available_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSCorrectionsAvailableFlag')
            datarecord.gps_fix_not_available_flag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.gps_directional_heading = \
                self._gettext(recordinfo, 'GPSDirectionalHeading')
            datarecord.last_good_gps_utctimestamp = \
                self._gettext(recordinfo, 'TimestampUTCLastGoodGPSLocation')
            data['DataRecord'].append(datarecord)
        return data

    def get_odometer_gps(self, xmlstring, record='OdometerGPSRecord'):
        """ Method to get the Odometer GPS Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord':
                         self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_odometer_gps_instance()
            datarecord.utctimestamp = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.total_distance_travelled = \
                self._gettext(recordinfo, 'TotalDistanceTraveled')
            data['DataRecord'].append(datarecord)
        return data

    def get_registration_info_v2(self, xmlstring, record='RegistrationInfoVer2Record'):
        """ Method to get the Registration Info V2 Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_radio_reg_info_instance()
            datarecord.utctimestamp = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.prodid = self._gettext(recordinfo, 'ProductID')
            datarecord.prod_ecuid = self._getattrib(recordinfo, 'ProductECUID', 'hex')
            datarecord.ecm_sn = self._gettext(recordinfo, 'ECMSerialNumber')
            datarecord.machine_sn = self._gettext(recordinfo, 'MachineSerialNumber')
            datarecord.equipment_id = self._gettext(recordinfo, 'EquipmentID')
            datarecord.num_of_radios = self._gettext(recordinfo, 'NumberOfRadios')
            for radio in recordinfo.findall('./Radio'):
                radioinfo = messagestructure.get_radio_info_instance()
                radioinfo.radio_sn = self._gettext(radio, 'RadioECMSerialNumber')
                radioinfo.type = self._gettext(radio, 'type')
                radioinfo.hardware_pn = self._gettext(radio, 'HdwePtno')
                radioinfo.software_pn = self._gettext(radio, 'SftwePtno')
                radioinfo.firmware_version = self._gettext(radio, 'FirmwareVer').upper()
                radioinfo.port = self._gettext(radio, 'port')
                radioinfo.cdma_preferred = self._gettext(radio, 'CDMAPreferred')
                radioinfo.imei = self._gettext(radio, 'IMEI')
                radioinfo.meid = self._gettext(radio, 'MEID')
                radioinfo.imsi = self._gettext(radio, 'IMSI')
                radioinfo.iccid = self._gettext(radio, 'ICCID')
                datarecord.radio_data.append(radioinfo)
            datarecord.num_of_products = self._gettext(recordinfo, 'NumberOfProducts')
            for prod in recordinfo.findall('./Product'):
                prodinfo = messagestructure.get_productinfo_instances()
                prodinfo.prod_ecuid = self._getattrib(prod, 'ProductECUID', 'hex')
                prodinfo.prod_id = self._gettext(prod, 'ProductID')
                datarecord.product_data.append(prodinfo)
            datarecord.num_of_engines = len(recordinfo.findall('./Engine'))
            datarecord.engine_ecuid = self._getattrib(recordinfo, 'Engine/EngineECUID', 'hex')
            datarecord.engine_sn = self._gettext(recordinfo, 'Engine/EngineSerialNumber')
            data['DataRecord'].append(datarecord)
        return data

    def get_smhinfo(self, xmlstring, record='SMHInfoRecord'):
        """ Method to get the SMH Info Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_smh_record_instance()
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.utctimestamp = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.total_operating_hours = self._gettext(recordinfo, 'TotalOperatingHours')
            data['DataRecord'].append(datarecord)
        return data

    def get_start_stop(self, xmlstring, record='StartStopRecord'):
        """ Method to get the Start-Stop record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_start_stop_instance()
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.utc_trigger_active = self._gettext(recordinfo, 'TimestampUTCTriggerActive')
            datarecord.utc_trigger_inactive = \
                self._gettext(recordinfo, 'TimestampUTCTriggerInactive')
            datarecord.machine_security_key_id = \
                self._gettext(recordinfo, 'MachineSecuritySystemKeyID')
            data['DataRecord'].append(datarecord)
        return data

    def get_transmission_info(self, xmlstring, record='TransmissionInfoRecord'):
        """  Method to get the Transmission Info record."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_transmissioninfo_record()
            datarecord.Transmission_Serial_Number = \
                self._gettext(recordinfo, 'TransmissionSerialNumber')
            datarecord.ECUID = self._getattrib(recordinfo, 'ECUID', 'hex')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_alert_event(self, xmlstring, record='AlertEventRecord'):
        """ Method to get the Alert Event record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_alert_event_info_instance()
            datarecord.alerteventid = self._gettext(recordinfo, 'AlertEventLevelID')
            datarecord.timestamputcactivation = self._gettext(recordinfo, 'TimestampUTCActivation')
            datarecord.alertlinkedmessageid = self._gettext(recordinfo, 'AlertLinkedMessageID')
            datarecord.alerteventid = self._gettext(recordinfo, 'AlertEventID')
            datarecord.alerteventoccurancecount = \
                self._gettext(recordinfo, 'AlertEventOccuranceCount')
            datarecord.alerteventuserid = self._gettext(recordinfo, 'AlertEventUserID')
            datarecord.alerteventnotificationtype = \
                self._gettext(recordinfo, 'AlertEventNotificationType')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_alert_registration(self, xmlstring, record='AlertRegistrationRecord'):
        """ Method to get the Alert Registration record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_alert_event_registration_instance()
            datarecord.alerteventid = self._gettext(recordinfo, 'AlertEventID')
            datarecord.alertlanguagecode = self._gettext(recordinfo, 'AlertLanguageCode')
            datarecord.alertdescription = self._gettext(recordinfo, 'AlertDescription')
            datarecord.alerteventlevelid = self._gettext(recordinfo, 'AlertEventLevelID')
            datarecord.alertstatus = self._gettext(recordinfo, 'AlertStatus')
            datarecord.alerttypecode = self._gettext(recordinfo, 'AlertTypeCode')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_config_file_registration(self, xmlstring,
                                             record='ConfigFileRegistrationRecord'):
        """ Method to get the Config File Registration record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_config_file_registration_record()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.filetype = self._gettext(recordinfo, 'FileType')
            datarecord.sha1 = self._gettext(recordinfo, 'SHA1')
            datarecord.statuscode = self._gettext(recordinfo, 'StatusCode')
            datarecord.modifiedbysystem = self._gettext(recordinfo, 'ModifiedBySystem')
            datarecord.modifiedbyuserid = self._gettext(recordinfo, 'ModifiedByUserID')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_disable_derate_tramper_reg(self, xmlstring,
                                               record=
                                               'DisableDerateTamperConfigRegistrationRecord'):
        """ Method to get the Disable Derate and Tamper record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_disablederate_tamperconfig_registration()
            datarecord.timestamputccurrent = \
                self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.machinestartmode = self._gettext(recordinfo, 'Machine/StartMode')
            datarecord.machinesource = self._gettext(recordinfo, 'Machine/Source')
            datarecord.tamperlevel = self._gettext(recordinfo, 'Tamper/Level')
            datarecord.tampersource = self._gettext(recordinfo, 'Tamper/Source')
            datarecord.tampertstatuscode = self._gettext(recordinfo, 'TamperStatusCode')
            datarecord.modifiedbysystem = self._gettext(recordinfo, 'ModifiedBySystem')
            datarecord.modifiedbyuserid = self._gettext(recordinfo, 'ModifiedByUserID')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_eod_registration_message(self, xmlstring, record='DailyReportTimeRecord'):
        """ Method to get the EOD Registration record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_daily_reporting_time_record_instance()
            datarecord.timestamputcurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.endofdayutctime = self._gettext(recordinfo, 'EndOfDayUTCTime')
            datarecord.endofdayisovrride = self._gettext(recordinfo, 'EndOfDayIsOverride')
            datarecord.modifiedbysystem = self._gettext(recordinfo, 'ModifiedBySystem')
            datarecord.modifiedbyuserid = self._gettext(recordinfo, 'ModifiedByUserID')
            datarecord.reporttimestatuscode = self._gettext(recordinfo, 'ReportTimeStatusCode')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_movement_config_reg(self, xmlstring,
                                        record='MovementConfigurationRegistrationRecord'):
        """ Method to get the Movement Configuration record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_acn_ods_movement_config_reg_instance()
            datarecord.timestampcurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.radius = self._gettext(recordinfo, 'Radius')
            datarecord.velocity = self._gettext(recordinfo, 'Velocity')
            datarecord.duration = self._gettext(recordinfo, 'Duration')
            datarecord.modifiedbysystem = self._gettext(recordinfo, 'ModifiedBySystem')
            datarecord.modifiedbyuserid = self._gettext(recordinfo, 'ModifiedByUserID')
            datarecord.statuscode = self._gettext(recordinfo, 'StatusCode')
            data['DataRecord'].append(datarecord)
        return data

    def get_acn_ods_switch_config_reg(self, xmlstring,
                                      record='SwitchConfigurationRegistrationRecord'):
        """ Method to get the Switch Configuration record from ACN-ODS communication."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_acn_ods_switch_config_reg()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.digitalinputid = self._gettext(recordinfo, 'Switch/DigitalInputID')
            datarecord.monitoringstate = self._gettext(recordinfo, 'Switch/MonitoringState')
            datarecord.monitoringcondition = \
                self._gettext(recordinfo, 'Switch/MonitoringCondition')
            datarecord.delaytime = self._gettext(recordinfo, 'Switch/DelayTime')
            datarecord.description = self._gettext(recordinfo, 'Switch/Description')
            datarecord.reportingcondition = \
                self._gettext(recordinfo, 'Switch/ReportingCondition')
            datarecord.modifiedbysystemid = self._gettext(recordinfo, 'ModifiedBySystem')
            datarecord.modifiedbyuserid = self._gettext(recordinfo, 'ModifiedByUserID')
            datarecord.statuscode = self._gettext(recordinfo, 'StatusCode')
            data['DataRecord'].append(datarecord)
        return data

    def get_additive_subscription_list(self, xmlstring, record="CurrentSubscriptionRecord"):
        """ Method to get the Additive Subscription list record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_additive_subscription_instance()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'SubscriptionID')
            data['DataRecord'].append(datarecord)
        return data

    def get_battery_threshold(self, xmlstring, record='BatteryThresholdRecord'):
        """  Method to get the Battery Votlage record information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_battery_threshold_record_instance()
            datarecord.batterythresholdvoltage = \
                self._gettext(recordinfo, 'BatteryThresholdVoltage')
            data['DataRecord'].append(datarecord)
        return data

    def get_config_file_hash_response(self, xmlstring, record='ConfigFileStatusRecord'):
        """ Method to get the Config file hash response. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_config_file_status_record()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.filetype = self._gettext(recordinfo, 'FileType')
            datarecord.sha1 = self._gettext(recordinfo, 'SHA1')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            data['DataRecord'].append(datarecord)
        return data

    def get_subscription_config(self, xmlstring, record='ConfigFileStatusRecord'):
        """ Method to get the Subscription Config information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_current_subscription_record_instance()
            datarecord.SubscriptionID = self._gettext(recordinfo, 'SubscriptionID')
            data['DataRecord'].append(datarecord)
        return data

    def get_diagnosticsv2(self, xmlstring, record='DiagnosticRecord'):
        """ Method to get the Diagnostics V2, message information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_diagnostics_recordv2()
            datarecord.diagnosticlevelid = self._gettext(recordinfo, 'DiagnosticLevelID')
            datarecord.timestamputcactivation = \
                self._gettext(recordinfo, 'TimestampUTCActivation')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpslocationstatus = \
                self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.componentid = self._gettext(recordinfo, 'ComponentID')
            datarecord.diagnosticsoccurnacecount = self._gettext(recordinfo, 'DiagnosticOccuranceCount')
            datarecord.diagnosticoperatorannuciation = self._gettext(recordinfo, 'DiagnosticOperatorAnnunciation')
            datarecord.diagnosticsfailuremodeidentifier = self._gettext(recordinfo, 'DiagnosticFailureModeIdentifier')
            datarecord.totaloperatinghours = self._gettext(recordinfo, 'TotalOperatingHours')
            data['DataRecord'].append(datarecord)
        return data

    def get_ecminfov2(self, xmlstring, record='ECMInfoVer2Record'):
        """ Method to get the ECMInfoV2 record information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_ecminfov2_record_instance()
            datarecord.utctimestamp = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.hardware_pn = self._gettext(recordinfo, 'ECMHardwarePartNumber')
            datarecord.serial_num = self._gettext(recordinfo, 'ECMSerialNumber')
            datarecord.software_pn = self._gettext(recordinfo, 'SoftwarePartNumber')
            datarecord.general_info = self._getattrib(recordinfo, 'ECMGeneralInformation', 'hex')
            datarecord.engine_ecm_flag = self._gettext(recordinfo, 'ECMGeneralInformation/EngineECMFlag')
            datarecord.transmission_ecm_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformation/TransmissionECMFlag')
            datarecord.cdl_flag = self._gettext(recordinfo, 'ECMGeneralInformation/CDLFlag')
            datarecord.j1939_flag = self._gettext(recordinfo, 'ECMGeneralInformation/J1939Flag')
            datarecord.acting_master_flag = self._gettext(recordinfo,
                                                          'ECMGeneralInformation/ActingMasterECMFlag')
            datarecord.sync_clock_protocol_supported_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformation/SynchClockProtocolSupportedFlag')
            datarecord.event_protocol_ver_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformation/EventProtocolVersionFlag')
            datarecord.diagnostics_protocol_ver_flag = \
                self._gettext(recordinfo, 'ECMGeneralInformation/DiagnosticProtocolVersionFlag')
            data['DataRecord'].append(datarecord)
        return data

    def get_engine_info(self, xmlstring, record='EngineInfoRecord'):
        """ Method to get the Engine Info message record."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_engine_info_instance()
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.engineserialnumber = self._gettext(
                recordinfo, 'EngineSerialNumber')
            data['DataRecord'].append(datarecord)
        return data

    def get_eventv2(self, xmlstring, record='EventRecord'):
        """ Metod to get the Event record information."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_event_record_instance()
            datarecord.eventlevelid = self._gettext(recordinfo, 'EventLevelID')
            datarecord.timestamputcactivation = self._gettext(recordinfo, 'TimestampUTCActivation')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpslocationstatus = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.eventid = self._gettext(recordinfo, 'EventID')
            datarecord.eventoccurancecount = self._gettext(recordinfo, 'EventOccuranceCount')
            datarecord.eventoperatorannunciation = self._gettext(recordinfo, 'EventOperatorAnnunciation')
            datarecord.totaloperatinghours = self._gettext(recordinfo, 'TotalOperatingHours')
            data['DataRecord'].append(datarecord)
        return data

    def get_fault_code(self, xmlstring, record='FaultCodeRecord'):
        """ Method to get the Fault Code Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_faultcode_record_instance()
            datarecord.eventlevelid = self._gettext(recordinfo, 'EventLevelID')
            datarecord.timestamputcactivation = self._gettext(recordinfo, 'TimestampUTCActivation')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpslocationstatus = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionsavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.totaloperatinghours = self._gettext(recordinfo, 'TotalOperatingHours')
            datarecord.faultecuid = self._getattrib(recordinfo, 'FaultECUID', 'hex')
            datarecord.faultecmservicemeterhours = self._gettext(recordinfo, 'FaultECMServiceMeterHours')
            datarecord.faulttype = self._gettext(recordinfo, 'FaultType')
            datarecord.diagnosticslevelid = self._gettext(recordinfo, 'DiagnosticLevelID')
            datarecord.componentid = self._gettext(recordinfo, 'ComponentID')
            datarecord.diagnosticsfailuremodeidentifier = \
                self._gettext(recordinfo, 'DiagnosticFailureModeIdentifier')
            datarecord.operatorannunciation = self._gettext(recordinfo, 'OperatorAnnunciation')
            datarecord.j1939dtclevelid = self._gettext(recordinfo, 'J1939DTCLevelID')
            datarecord.suspectparameternumber = self._gettext(recordinfo, 'SuspectParameterNumber')
            datarecord.dtcfailuremodeidentifier = self._gettext(recordinfo, 'DTCFailureModeIdentifier')
            datarecord.occurancecount = self._gettext(recordinfo, 'OccurrenceCount')
            datarecord.dtclampstatus = self._gettext(recordinfo, 'DTCLampStatus')
            datarecord.dtclampflash = self._gettext(recordinfo, 'DTCLampFlash')
            data['DataRecord'].append(datarecord)
        return data

    def get_geotime_fence_crossing_message(self, xmlstring, record='GeoTimeFenceEventRecord'):
        """ Method to get the Geotime fence Event record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_geotime_fence_event_instance()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.totaloperatinghours = self._gettext(recordinfo, 'TotalOperatingHours')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpslocationstatus = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionsavailableflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.gpslocationaccuracy = self._gettext(recordinfo, 'GPSLocationAccuracy')
            datarecord.gpsgroundspeed = self._gettext(recordinfo, 'GPSGroundSpeed')
            datarecord.timestamputclastgoodtimestamp = self._gettext(recordinfo, 'TimestampUTCLastGoodGPSLocation')
            datarecord.fenceid = self._gettext(recordinfo, 'FenceID')
            datarecord.offboardfenceid = self._gettext(recordinfo, 'OffboardFenceID')
            datarecord.offboardclientfenceid = self._gettext(recordinfo, 'OffboardClientFenceID')
            datarecord.offboardfenceid = self._gettext(recordinfo, 'OffboardClientID')
            data['DataRecord'].append(datarecord)
        return data

    def get_j1939_dtcv2(self, xmlstring, record='J1939DTCRecord'):
        """ Method to get J1939 DTC V2 record."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_j1939dtc_v2_info()
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.j1939dtclevelid = self._gettext(recordinfo, 'J1939DTCLevelID')
            datarecord.timestamputcactivation = self._gettext(recordinfo, 'TimestampUTCActivation')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpslocationstatus = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionsavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.totaloperatinghours = self._gettext(recordinfo, 'TotalOperatingHours')
            datarecord.suspectparameternumber = self._gettext(recordinfo, 'SuspectParameterNumber')
            datarecord.dtcoccurancecount = self._gettext(recordinfo, 'DTCOccuranceCount')
            datarecord.dtcfailuremodeidentifier = self._gettext(recordinfo, 'DTCFailureModeIdentifier')
            datarecord.dtclampstatus = self._gettext(recordinfo, 'DTCLampStatus')
            datarecord.dtclampflash = self._gettext(recordinfo, 'DTCLampFlash')
            data['DataRecord'].append(datarecord)
        return data

    def get_machine_idle_start_stop(self, xmlstring, record='MachineIdleStartStopRecord'):
        """ Method to get the information of the Machine IDLE Start Stop information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_machineidle_startstop_record()
            datarecord.ecuid = self._getattrib(recordinfo, 'MachineIdleInfo/ECUID', 'hex')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.machineidleflag = self._gettext(recordinfo, 'MachineIdleInfo/IdleFlag')
            datarecord.timestamputctriggerchange = self._gettext(recordinfo, 'MachineIdleInfo/TimestampUTCTriggerChange')
            data['DataRecord'].append(datarecord)
        return data

    def get_machine_info(self, xmlstring, record='MachineInfoRecord'):
        """ Method to get information from the Machine Info Record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_machine_info_instance()
            datarecord.timestamputccurrent = self._getattrib(recordinfo, 'TimestampUTCCurrent', 'hex')
            datarecord.machineserialnumber = self._gettext(recordinfo, 'MachineSerialNumber')
            datarecord.productid = self._gettext(recordinfo, 'ProductID')
            datarecord.dealerid = self._gettext(recordinfo, 'DealerID')
            data['DataRecord'].append(datarecord)
        return data

    def get_machine_start_mode(self, xmlstring, record='MachineStartModeRecord'):
        """ Method to get the Machine Start Mode information. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_machine_start_mode_instance()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.timestamputcactivation = self._gettext(recordinfo, 'TimestampUTCActivation')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpslocationstatus = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionsavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.machinestartstatus = self._gettext(recordinfo, 'MachineStartStatus')
            datarecord.machinestartstatustrigger = self._getattrib(recordinfo, 'MachineStartStatusTrigger', 'hex')
            datarecord.unknownnotconfigurednottriggered = \
                self._gettext(recordinfo, 'MachineStartStatusTrigger/UnknownNotConfiguredNotTriggered')
            datarecord.otacommand = self._gettext(recordinfo, 'MachineStartStatusTrigger/OTACommand')
            datarecord.onboardservicetoolrestorecommand = \
                self._gettext(recordinfo, 'MachineStartStatusTrigger/OnBoardServiceToolRestoreCommand')
            datarecord.gpsantennadisconnectedtimerexpired = \
                self._gettext(recordinfo, 'MachineStartStatusTrigger/GPSAntennaDisconnectedTimerExpired')
            datarecord.telematicsantennadisconnectedtimerexpired = \
                self._gettext(recordinfo, 'MachineStartStatusTrigger/TelematicsAntennaDisconnectedTimerExpired')
            datarecord.connectiontobackofficetimerexpired = \
                self._gettext(recordinfo, 'MachineStartStatusTrigger/ConnectionToBackOfficeTimerExpired')
            datarecord.tamperresolved = self._gettext(recordinfo, 'MachineStartStatusTrigger/TamperResolved')
            datarecord.tamperuninstalled = self._gettext(recordinfo, 'MachineStartStatusTrigger/TamperUninstalled')
            data['DataRecord'].append(datarecord)
        return data

    def get_mo_single_file_request(self, xmlstring, record='MOSingleFileRequestRecord'):
        """ Method to get the MO single file request. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_mo_single_filerequest_record()
            datarecord.filetype = self._gettext(recordinfo, 'FileType')
            data['DataRecord'].append(datarecord)
        return data

    def get_otasp_status(self, xmlstring, record='OTASPStatusRecord'):
        """ Method to get the information from OTASP Status Message."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_otasp_status_record()
            datarecord.otaspstatus = self._gettext(recordinfo, 'OTASPStatus')
            data['DataRecord'].append(datarecord)
        return data

    def get_public_j1939_ecm_info(self, xmlstring, record='ECMJ1939PublicInfoRecord'):
        """ Method to get the Public J1939 Message ECM Info. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_publicj1939_ecminfo()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.ecmhardwarepartnumber = self._gettext(recordinfo, 'ECMHardwarePartNumber')
            datarecord.ecmserialnumber = self._gettext(recordinfo, 'ECMSerialNumber')
            datarecord.softwarepartnumber = self._gettext(recordinfo, 'SoftwarePartNumber')
            datarecord.publicname = self._getattrib(recordinfo, 'PublicName', 'hex')
            datarecord.identitynumber = self._gettext(recordinfo, 'PublicName/IdentityNumber')
            datarecord.manufacturercode = self._gettext(recordinfo, 'PublicName/ManufacturerCode')
            datarecord.ecuinstance = self._gettext(recordinfo, 'PublicName/ECUInstance')
            datarecord.functioninstance = self._gettext(recordinfo, 'PublicName/FunctionInstance')
            datarecord.function = self._gettext(recordinfo, 'PublicName/Function')
            datarecord.vehiclesystem = self._gettext(recordinfo, 'PublicName/VehicleSystem')
            datarecord.vehiclesysteminstance = self._gettext(recordinfo, 'PublicName/VehicleSystemInstance')
            datarecord.industrygroup = self._gettext(recordinfo, 'PublicName/IndustryGroup')
            datarecord.arbitraryaddresscapable = self._gettext(recordinfo, 'PublicName/ArbitraryAddressCapable')
            data['DataRecord'].append(datarecord)
        return data

    def get_remote_flash_status_response(self, xmlstring, record='RemoteFlashStatusResponseRecord'):
        """ Method to get the flash status response information."""
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_remoteflash_status_response_record()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.fsmstate = self._getattrib(recordinfo, 'FSM', 'state')
            datarecord.fsmstatus = self._getattrib(recordinfo, 'FSM', 'status')
            datarecord.firmwarestate = self._gettext(recordinfo, 'FSM/FirmwareState')
            datarecord.firmwarestatus = self._gettext(recordinfo, 'FSM/FirmwareStatus')
            data['DataRecord'].append(datarecord)
        return data

    def get_reserved_geofence_crossing_messages(self, xmlstring, record='AssetMoveFenceRecord'):
        """ Method to get the reversed geofence crossing messages. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_asset_move_fence_record()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.totaloperatinghours = self._gettext(recordinfo, 'TotalOperatingHours')
            datarecord.gpslatitude = self._gettext(recordinfo, 'GPSLatitude')
            datarecord.gpslongitude = self._gettext(recordinfo, 'GPSLongitude')
            datarecord.gpsheight = self._gettext(recordinfo, 'GPSHeight')
            datarecord.gpslocationstatus = self._getattrib(recordinfo, 'GPSLocationStatus', 'hex')
            datarecord.gpssourcenotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSSourceNotAvailableFlag')
            datarecord.gpsstatusinvalidflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSStatusInvalidFlag')
            datarecord.gpsfilteredflag = self._gettext(recordinfo, 'GPSLocationStatus/GPSFilteredFlag')
            datarecord.gpsaltitudetype = self._gettext(recordinfo, 'GPSLocationStatus/GPSAltitudeType')
            datarecord.gpsfixtype = self._gettext(recordinfo, 'GPSLocationStatus/GPSFixType')
            datarecord.gpsconnectionsavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSConnectionsAvailableFlag')
            datarecord.gpsfixnotavailableflag = \
                self._gettext(recordinfo, 'GPSLocationStatus/GPSFixNotAvailableFlag')
            datarecord.gpslocationaccuracy = self._gettext(recordinfo, 'GPSLocationAccuracy')
            datarecord.gpsdirectionalheading = self._gettext(recordinfo, 'GPSDirectionalHeading')
            datarecord.gpsgroundspeed = self._gettext(recordinfo, 'GPSGroundSpeed')
            datarecord.timestamputclastgoodtimestamp = \
                self._gettext(recordinfo, 'TimestampUTCLastGoodGPSLocation')
            datarecord.gpsradiosourceid = self._gettext(recordinfo, 'GPSRadioSourceID')
            datarecord.fenceid = self._gettext(recordinfo, 'FenceID')
            data['DataRecord'].append(datarecord)
        return data

    def get_rtc_range(self, xmlstring, record='RealTimeClockRangeRecord'):
        """ Method to get the infromation from the RTC Range. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_realtimeclockrange_instance()
            datarecord.timestamputcfirstbad = self._gettext(recordinfo, 'TimestampUTCFirstBad')
            datarecord.totaloperatinghoursfirstbad = self._gettext(recordinfo, 'TotalOperatingHoursFirstBad')
            datarecord.timestamputclastbad = self._gettext(recordinfo, 'TimestampUTCLastBad')
            datarecord.totaloperatinghourslastbad = self._gettext(recordinfo, 'TotalOperatingHoursLastBad')
            data['DataRecord'].append(datarecord)
        return data

    def get_smh_adjust_response(self, xmlstring, record='SMHAdjustResponseRecord'):
        """ Method to get the SMH Adjust Response message. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_smh_adjust_response_record()
            datarecord.timestamputccurrent = self._gettext(
                recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.totaloperatinghoursprevious = self._gettext(recordinfo, 'TotalOperatingHoursPrevious')
            datarecord.totaloperatinghoursadjusted = self._gettext(recordinfo, 'TotalOperatingHoursAdjusted')
            data['DataRecord'].append(datarecord)
        return data

    def get_switch_configuration(self, xmlstring, record='SwitchConfigRecord'):
        """ Method to get the Switch Configuration message. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_switch_config_record_instance()
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.digitalinputid = self._gettext(recordinfo, 'DigitalInputID')
            datarecord.monitoringstate = self._gettext(recordinfo, 'MonitoringState')
            datarecord.monitoringcondition = self._gettext(recordinfo, 'MonitoringCondition')
            datarecord.delaytime = self._gettext(recordinfo, 'DelayTime')
            datarecord.description = self._gettext(recordinfo, 'Description')
            datarecord.reportingcondition = self._gettext(recordinfo, 'ReportingCondition')
            data['DataRecord'].append(datarecord)
        return data

    def get_system_flash_fingerprint(self, xmlstring, record='ECMFingerprintRecord'):
        """ Method to get the System Flash Finger Print message. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update(
            {'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_ecmfingerprintrecord()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.locationcode = self._gettext(recordinfo, 'LocationCode')
            datarecord.ecmserialnumber = self._gettext(recordinfo, 'ECMSerialNumber')
            datarecord.hardwarepartnumber = self._gettext(recordinfo, 'HdwePtno')
            datarecord.softwarepartnumber = self._gettext(recordinfo, 'SftwePtno')
            datarecord.applicationid = self._gettext(recordinfo, 'ApplicationID')
            datarecord.componentid = self._gettext(recordinfo, 'ComponentID')
            datarecord.aftermarketid = self._gettext(recordinfo, 'AftermarketID')
            datarecord.datalinks = self._gettext(recordinfo, 'DataLinks/Datalink')
            data['DataRecord'].append(datarecord)
        return data

    def get_tms_information(self, xmlstring, record='TMSInfoRecord'):
        """ Method to get the TMS information of the TMS Info record. """
        headerrecordinfo, datarecordinfo = self._getrecordinfo(xmlstring, record)
        data = {}
        data.update({"TotalNumberofHeaderRecord": len(headerrecordinfo)})
        data.update({"TotalNumberofDataRecord": len(datarecordinfo)})
        data.update({"DataRecord": []})
        data.update({'HeaderRecord': self._get_message_header_info(headerrecordinfo)})
        for recordinfo in datarecordinfo:
            datarecord = messagestructure.get_tms_info_record_instance()
            datarecord.timestamputccurrent = self._gettext(recordinfo, 'TimestampUTCCurrent')
            datarecord.trigger = self._gettext(recordinfo, 'Trigger')
            datarecord.sensorlocationaxlenumber = self._gettext(recordinfo, 'SensorLocation/SensorLocationAxleNumber')
            datarecord.sensorlocationtirenumber = self._gettext(recordinfo, 'SensorLocation/SensorLocationTireNumber')
            datarecord.ecuid = self._getattrib(recordinfo, 'ECUID', 'hex')
            datarecord.tiresensorstatus = self._gettext(recordinfo, 'TireSensorStatus')
            data['DataRecord'].append(datarecord)
        return data
