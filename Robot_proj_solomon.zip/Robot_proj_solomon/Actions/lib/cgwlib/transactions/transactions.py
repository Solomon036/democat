"""
File contains operation requried on the transaction page of Cat Gateway 2.0.
"""
# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     cgwlib/transactions/transactions.py
# **
# ** DESCRIPTION:
# **     File contains operation requried on the transaction page of Cat Gateway 2.0.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# **
# *******************************************************************************
# """


from time import sleep
from lib.webinterface import catch_except
from lib.cgwlib.transactions import messageinfo


class Transaction(object):
    """ Class to carry out the operation in Transaction Page. """
    def __init__(self, parent):
        self.parent = parent
        self.message_func = messageinfo.MessageInfo(parent)

    @catch_except
    def is_button_pressed(self, element):
        """ Method to verify whether the button is pressed. """
        value = element.get_attribute("class").encode("utf-8")
        return "active" in value

    @catch_except
    def filter_the_transaction_type(self, trans_type):
        """ Method to filter the transactions based on the transaction type: Message, Command."""
        self.go_to_message_viewer()
        type_list = ['message', 'file', 'command']
        for trans_type_ in type_list:
            element = self.parent.driver.find_element_by_xpath('.//*[@id="{}"]'.format(trans_type_))
            while self.is_button_pressed(element):
                element.click()
                sleep(0.2)
        self.parent.driver.find_element_by_xpath('.//*[@id="{}"]'.format(trans_type)).click()
        sleep(0.5)
        self.parent.wait_till_delay(("id", "divTransactionList"))
        self.parent.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1* 60)
        return True

    @catch_except
    def go_to_message_viewer(self):
        """ Method to go to the Message Viewer. """
        self.parent.go_to_transactions()
        sleep(1)

    @catch_except
    def set_filter(self, filter_type, filter_msg):
        """ Method to set filter the on the Transaction Page, based on the filter-type and filter message."""
        self.go_to_message_viewer()
        element = self.parent.driver.find_element_by_xpath('.//*[@data-ng-click="aFilterPopUp()"]')
        if element:
            element.click()
            sleep(0.5)
            filters = ["triggerfilter('Message')", "triggerfilter('File')", "triggerfilter('Command')"]
            for loop in filters:
                if filter_type.capitalize() in loop:
                    element = self.parent.driver.find_element_by_xpath('.//*[@data-ng-click="{}"]'.format(loop))
                    element.click()
                    break
            self.parent.click(("data-ng-click", "clearAll()"))
            self.parent.input(("ng-model", "filtertextbox"), filter_msg)
            self.parent.click('.//*[@id="availableAdvanceFilter"]/option[@label="{}"]'.format(filter_msg))
            sleep(0.5)
            self.parent.click(("data-ng-click", "addWork()"))
            sleep(1)
            self.parent.click(("data-ng-click", "applyAdvancedFilter()"))
            sleep(5)
            self.parent.wait_till_delay('.//*[@id="loading-bar"]')
            self.parent.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1 * 60)
            sleep(5)

    @staticmethod
    def _create_message_info_instance():
        """ Method to return the instance of the Message Info. """
        class MessageOuterInfo(object):
            """ Class to hold the Message Outer Info. """
            recordid = None
            deviceid = None
            equipment_serial_number = None
            record_type = None
            description = None
            file_name_user_id = None
            message_creation_time = None
            cgw_reception_time = None
            cmd_status_time = None
            cmd_status = None
        return MessageOuterInfo()

    @catch_except
    def _get_table_content(self):
        """ Method to return the Table content of the Transaction page."""
        return self.parent.driver.find_elements_by_xpath('.//*[@id="transSearchTableResult"]')

    @catch_except
    def _get_element_value(self, element):
        """ Method to return the value of the element. """
        return self.parent.get_value_by_element(element)

    @catch_except
    def get_message_info(self, index):
        """ Method to return the value of the Message based on the index.
        This function will be called after setting a filter to return the filtered type of information. """

        msg_instance = self._create_message_info_instance()
        cols = self._get_table_content()[index]
        msg_instance.recordid = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td2"]'))
        msg_instance.deviceid = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td3"]'))
        msg_instance.equipment_serial_number = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td4"]'))
        msg_instance.record_type = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td5"]'))
        msg_instance.description = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td6"]'))
        msg_instance.file_name_user_id = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td7"]'))
        msg_instance.message_creation_time = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td8"]'))
        msg_instance.cgw_reception_time = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td9"]'))
        msg_instance.cmd_status_time = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td10"]'))
        msg_instance.cmd_status = self._get_element_value(cols.find_element_by_xpath('.//*[@id="td11"]'))
        return msg_instance

    @catch_except
    def get_message_details_info(self, message_type, index=0, consolidated=False):
        """ Method to return the details of the messages. """
        condensed_messages = dict()
        self.go_to_message_viewer()
        sleep(5)
        condensed_messages.update({"Consolidated Utilization": ["Fuel Basic", "Fuel Level",
                                                                "Odometer GPS", "HoursLoc"]})
        self.filter_the_transaction_type("message")
        sleep(5)
        if message_type in condensed_messages["Consolidated Utilization"] and consolidated:
            self.set_filter("message", "Consolidated Utilization Message")
        else:
            self.set_filter("message", message_type)
        sleep(5)
        cols = self._get_table_content()[index]
        # self.parent.wait_till_delay('.//*[@id="loading-bar"]')
        self.parent.wait_till_inactive_delay('.//*[@id="loading-bar"]', 1*60)
        sleep(5)
        cols.find_element_by_xpath('.//*[@id="td12"]').click()
        sleep(15)
        self.parent.wait_till_delay('.//*[@id="xml"]')
        # sleep(10)
        xml_info = self.parent.get_value('.//*[@id="xml"]')
        if message_type == "VL HoursLoc":
            message_type = "HoursLoc"
        fmt_message_type = "get_{}".format(message_type.lower().replace(" ", "_").replace("-", "_"))
        value = getattr(self.message_func, fmt_message_type)(xml_info)
        self.go_to_message_viewer()
        return value
