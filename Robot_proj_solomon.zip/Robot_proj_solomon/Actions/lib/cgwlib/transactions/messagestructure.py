"""
File contains only the class message strucutures for all the message of Cat Gateway 2.0.
"""

# """
# *******************************************************************************
# * COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
# -------------------------------------------------------------------------------
# **
# ** FILE NAME:
# **     cgwlib/transactions/messagestrucutre.py
# **
# ** DESCRIPTION:
# **     File contains only the class message strucutures for all the message of Cat Gateway 2.0.
# **
# ** AUTHOR:
# **    Mani Shankar Venkatachalam(venkam5)
# **
# *******************************************************************************
# """


def get_battey_voltage_instance():
    """ Method to get the Battery Voltage Instance. """
    class BatteryVoltageRecord(object):
        """ Class to hold values from Battery Voltage Record Message. """
        def __init__(self):
            self.utctimestamp = ''
            self.trigger = ''
            self.gps_latitiude = ''
            self.gps_longitude = ''
            self.gps_location_status = ''
            self.gps_source_not_available_flag = ''
            self.gps_status_invalid_flag = ''
            self.gps_filtered_flag = ''
            self.gps_altitude_type = ''
            self.gps_fix_type = ''
            self.gps_connection_available_flag = ''
            self.gps_fix_not_available_flag = ''
            self.battery_voltage = ''
    return BatteryVoltageRecord()


def get_ecminfov3_instance():
    """ Method to get the ECM Info V3 Instances."""
    class ECMInfoVer3Record(object):
        """ Class to hold values from ECM Info V3 Record Message. """
        utctimestamp = ''
        ecuid = ''
        hardware_pn = ''
        serial_num = ''
        software_pn = ''
        general_info = ''
        engine_ecm_flag = ''
        transmission_ecm_flag = ''
        cdl_flag = ''
        cdl_deviceid_include_flag = ''
        j1939_flag = ''
        j1939_deviceid_include_flag = ''
        ethernet_flag = ''
        ethernet_deviceid_include_flag = ''
        public_name_include_flag = ''
        acting_master_flag = ''
        sync_clock_protocol_supported_flag = ''
        troubleshooting_code_protocol_flag = ''
        public_name = ''
        identity_number = ''
        manufacturer_code = ''
        ecu_instance = ''
        function_instance = ''
        function = ''
        vehicle_system = ''
        vehicle_system_instance = ''
        industry_group = ''
        arbitary_address_capable = ''
    return ECMInfoVer3Record()


def get_fuel_basic_instance():
    """ Method to get the Fuel Basic Infromation Instance. """
    class FuelBasicDataRecord(object):
        """ Class to hold values from Fuel Basic Data Record Message. """
        def __init__(self):
            self.ecuid = ''
            self.utctimestamp = ''
            self.trigger = ''
            self.total_max_fuel = ''
            self.total_idle_time = ''
            self.total_idle_fuel = ''
            self.total_fuel_used = ''
            self.num_of_engine_starts = ''
            self.lifetime_eng_rev = ''
            self.totalfuelwithoutsubstitution = ''
    return FuelBasicDataRecord()


def get_fuel_level_instance():
    """ Method to get the Fuel Level Infromation Instance. """
    class FuelLevelRecord(object):
        """ Class to hold values from Fuel level Record Message. """
        def __init__(self):
            self.ecuid = ''
            self.utctimestamp = ''
            self.trigger = ''
            self.fuel_level = ''
    return FuelLevelRecord()


def get_geotimefence_status_instance():
    """ Method to get the Geo time Fence Status Record Instance. """
    class GeoTimeFenceStatusRecord(object):
        """ Class to hold values from Geo Time Fence Status Record Message. """
        def __init__(self):
            self.fenceid = ''
            self.trigger = ''
            self.gps_radio_sourceid = ''
    return GeoTimeFenceStatusRecord()


def get_hours_loc_instance():
    """ Method to return the Hours Loc Instance. """
    class HoursLocRecord(object):
        """ Class to hold values from Hours Loc Record Message. """
        def __init__(self):
            self.utctimestamp = ''
            self.trigger = ''
            self.ecuid = ''
            self.total_operating_hours = ''
            self.latitude = ''
            self.longitude = ''
            self.height = ''
            self.location_status = ''
            self.gps_source_not_available_flag = ''
            self.gps_status_invalid_flag = ''
            self.gps_filtered_flag = ''
            self.gps_altitude_type = ''
            self.gps_fix_type = ''
            self.gps_correction_available_flag = ''
            self.gps_fix_not_available_flag = ''
            self.gps_directional_heading = ''
            self.last_good_gps_utctimestamp = ''
            self.gps_radio_source_id = ''
    return HoursLocRecord()


def get_odometer_gps_instance():
    """ Method to return the Odometer GPS Instance. """
    class OdometerGPSRecord(object):
        """ Class to hold the values from Odometer GPS record Message. """
        def __init__(self):
            self.utctimestamp = ''
            self.trigger = ''
            self.total_distance_travelled = ''
    return OdometerGPSRecord()


def get_productinfo_instances():
    """ Method to get the Product Info Instances."""
    class ProductInfoRecord(object):
        """ Class to hold the values of the Product Info Message."""
        prod_ecuid = ''
        prod_id = ''
    return ProductInfoRecord()


def get_radio_info_instance():
    """ Method to return the Radio Info message instance. """
    class RadioInfoRecord(object):
        """ Class to hold the values of the Radio Info Record Message. """
        radio_sn = ''
        type = ''
        hardware_pn = ''
        software_pn = ''
        firmware_version = ''
        cdma_preferred = ''
        imei = ''
        meid = ''
        imsi = ''
        iccid = ''
        port = ''
    return RadioInfoRecord()


def get_radio_reg_info_instance():
    """ Method to return the Radio Registration Info Message Instance. """
    class RadioRegistrationInfoRecord(object):
        """ Class to hold the values of Radio Registration Info message. """
        utctimestamp = ''
        prodid = ''
        prod_ecuid = ''
        ecm_sn = ''
        machine_sn = ''
        equipment_id = ''
        num_of_radios = ''
        radio_data = []
        num_of_engines = ''
        engine_ecuid = ''
        engine_sn = ''
        num_of_products = ''
        product_data = []
    return RadioRegistrationInfoRecord()


def get_smh_record_instance():
    """ Method to return the SMH Info record Instance."""
    class SMHInfoRecord(object):
        """ Class to hold the values of the SMHInfo message. """
        def __init__(self):
            self.ecuid = ''
            self.utctimestamp = ''
            self.trigger = ''
            self.total_operating_hours = ''
    return SMHInfoRecord()


def get_start_stop_instance():
    """ Method to return the Start-Stop record Instance. """
    class StartStopRecord(object):
        """ Class to hold the values of the Start-Stop message. """
        def __init__(self):
            self.ecuid = ''
            self.utc_trigger_active = ''
            self.utc_trigger_inactive = ''
            self.machine_security_key_id = ''
    return StartStopRecord()


def get_transmissioninfo_record():
    """ Method to return  the Transmission Info record Instance. """
    class TransmissionInfoRecord(object):
        """ Class to hold the values of the Transmission info message. """
        def __init__(self):
            self.Transmission_Serial_Number = ''
            self.ecuid = ''
    return TransmissionInfoRecord()


def get_alert_event_info_instance():
    """ Method to return the Alert Event Info record Instance. """
    class AlertEventInfoRecord(object):
        """ Class to hold the values of the Alert Event info message. """
        def __init__(self):
            self.alerteventlevelid = ''
            self.timestamputcactivation = ''
            self.alertlinkedmessageid = ''
            self.alerteventid = ''
            self.alerteventoccurancecount = ''
            self.alerteventuserid = ''
            self.alerteventnotificationtype = ''
    return AlertEventInfoRecord()


def get_alert_event_registration_instance():
    """ Method to return the Alert Event Registration Info record instance. """
    class AlertRegistrationRecord(object):
        """ Class to hold the values of the Alert Event registration message. """
        def __init__(self):
            self.alerteventid = ''
            self.alertlanguagecode = ''
            self.alertdescription = ''
            self.alerteventlevelid = ''
            self.alertstatus = ''
            self.alerttypecode = ''
    return AlertRegistrationRecord()


def get_config_file_registration_record():
    """ Method to return the Config File registration info record instance. """
    class ConfigFileRegistrationRecord(object):
        """ Class to hold the values of the Config file registration record. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.filetype = ''
            self.sha1 = ''
            self.statuscode = ''
            self.modifiedbysystem = ''
            self.modifiedbyuserid = ''
    return ConfigFileRegistrationRecord()


def get_disablederate_tamperconfig_registration():
    """ Method to return the Disable Derate Tamper Config Registration info record instance. """
    class DisableDerateTamperConfigRegistrationRecord(object):
        """ Class to hold the values of the Disable Derate Tamper Config registration record. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.machinestartmode = ''
            self.machinesource = ''
            self.tamperlevel = ''
            self.tampersource = ''
            self.tampertstatuscode = ''
            self.modifiedbysystem = ''
            self.modifiedbyuserid = ''
    return DisableDerateTamperConfigRegistrationRecord()


def get_daily_reporting_time_record_instance():
    """" Method to return the Daily Reporting Time Record instance."""
    class DailyReportTimeRecord(object):
        """ Class to hold the values of the Daily reporting time record. """
        def __init__(self):
            self.timestamputcurrent = ''
            self.endofdayutctime = ''
            self.endofdayisovrride = ''
            self.modifiedbysystem = ''
            self.modifiedbyuserid = ''
            self.reporttimestatuscode = ''
    return DailyReportTimeRecord()


def get_acn_ods_movement_config_reg_instance():
    """ Method to return the instance of the ACN-ODS Movement Config Registration."""
    class MovementConfigurationRegistrationRecord(object):
        """ Class to hold the values of Move confgiruation Registration Record. """
        def __init__(self):
            self.timestampcurrent = ''
            self.radius = ''
            self.velocity = ''
            self.duration = ''
            self.modifiedbysystem = ''
            self.modifiedbyuserid = ''
            self.statuscode = ''
    return MovementConfigurationRegistrationRecord()


def get_acn_ods_switch_config_reg():
    """ Method to return the instance of ACN-ODS Switch Config."""
    class SwitchConfigurationRegistrationRecord(object):
        """ Class to hold the message of the Switch Configuration Registration Record. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.digitalinputid = ''
            self.monitoringstate = ''
            self.monitoringcondition = ''
            self.delaytime = ''
            self.description = ''
            self.reportingcondition = ''
            self.modifiedbysystemid = ''
            self.modifiedbyuserid = ''
            self.statuscode = ''
    return SwitchConfigurationRegistrationRecord()


def get_additive_subscription_instance():
    """ Method to return the Instance of the Additive Subscription. """
    class AdditiveSubscriptionRecord(object):
        """ Class to hold the message of the Additive Subscription. """
        def __init__(self):
            self.subscriptionid = ''
    return AdditiveSubscriptionRecord()


def get_battery_threshold_record_instance():
    """ Method to return the instance of the Battery Threshold message. """
    class BatteryThresholdRecord(object):
        """ Class to hold the infromation of the  Battery Threshold message. """
        def __init__(self):
            self.batterythresholdvoltage = ''
    return BatteryThresholdRecord()


def get_config_file_status_record():
    """ Method to return the instance of the Config file status. """
    class ConfigFileStatusRecord(object):
        """ Class to hold the information of the Config File Status. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.filetype = ''
            self.sha1 = ''
            self.trigger = ''
    return ConfigFileStatusRecord()


def get_current_subscription_record_instance():
    """ Method to return the instance of the Current Subscription record. """
    class CurrentSubscriptionRecord(object):
        """ Class to hold the infromation of the Current Subscription record."""
        def __init__(self):
            self.subscriptionid = ''
    return CurrentSubscriptionRecord()


def get_diagnostics_recordv2():
    """ Method to return the instance of the Diagnostics Info V2 Record.  """
    class DiagnosticRecord(object):
        """ Class to hold the information of the Diagnostics Info V2. """
        def __init__(self):
            self.diagnosticlevelid = ''
            self.timestamputcactivation = ''
            self.gpslatitude = ''
            self.gpslongitude = ''
            self.gpslocationstatus = ''
            self.gpssourcenotavailableflag = ''
            self.gpsstatusinvalidflag = ''
            self.gpsfilteredflag = ''
            self.gpsaltitudetype = ''
            self.gpsfixtype = ''
            self.gpsconnectionavailableflag = ''
            self.gpsfixnotavailableflag = ''
            self.ecuid = ''
            self.componentid = ''
            self.diagnosticsoccurnacecount = ''
            self.diagnosticoperatorannuciation = ''
            self.diagnosticsfailuremodeidentifier = ''
            self.totaloperatinghours = ''
    return DiagnosticRecord()


def get_ecminfov2_record_instance():
    """ Method to return the instance of the ECM infoV2 Record.  """
    class ECMInfoVer2Record(object):
        """ Class to hold the infromation of the ECMInfo V2 Message. """
        utctimestamp = ''
        ecuid = ''
        hardware_pn = ''
        serial_num = ''
        software_pn = ''
        general_info = ''
        engine_ecm_flag = ''
        transmission_ecm_flag = ''
        cdl_flag = ''
        j1939_flag = ''
        acting_master_flag = ''
        sync_clock_protocol_supported_flag = ''
        event_protocol_ver_flag = ''
        diagnostics_protocol_ver_flag = ''
    return ECMInfoVer2Record()


def get_engine_info_instance():
    """ Method to return the instance of the Engine Info. """
    class EngineInfoRecord(object):
        """ Class to hold the message of Engine Info. """
        def __init__(self):
            self.ecuid = ''
            self.engineserialnumber = ''
    return EngineInfoRecord()


def get_event_record_instance():
    """ Method to return the instance of te Event Record. """
    class EventRecord(object):
        """ Class to hold the infromation of the Event Record. """
        def __init__(self):
            self.eventlevelid = ''
            self.timestamputcactivation = ''
            self.gpslatitude = ''
            self.gpslongitude = ''
            self.gpslocationstatus = ''
            self.gpssourcenotavailableflag = ''
            self.gpsstatusinvalidflag = ''
            self.gpsfilteredflag = ''
            self.gpsaltitudetype = ''
            self.gpsfixtype = ''
            self.gpsconnectionavailableflag = ''
            self.gpsfixnotavailableflag = ''
            self.ecuid = ''
            self.eventid = ''
            self.eventoccurancecount = ''
            self.eventoperatorannunciation = ''
            self.totaloperatinghours = ''
    return EventRecord()


class GPSInfo(object):
    """ Class to hold the GPS Info. """
    def __init__(self):
        self.gpslatitude = ''
        self.gpslongitude = ''
        self.gpslocationstatus = ''
        self.gpsheight = ''
        self.gpssourcenotavailableflag = ''
        self.gpsstatusinvalidflag = ''
        self.gpsfilteredflag = ''
        self.gpsaltitudetype = ''
        self.gpsfixtype = ''
        self.gpsconnectionsavailableflag = ''
        self.gpsfixnotavailableflag = ''
        self.gpslocationaccuracy = ''
        self.gpsdirectionalheading = ''
        self.gpsgroundspeed = ''
        self.timestamputclastgoodtimestamp = ''


def get_faultcode_record_instance():
    """ Method to return the instnce of the Fault Code record instance. """
    class FaultCodeRecord(GPSInfo):
        """ Class to hold the infromation of the Fault code. """
        def __init__(self):
            super(FaultCodeRecord, self).__init__()
            self.eventlevelid = ''
            self.ecuid = ''
            self.timestamputcactivation = ''
            self.totaloperatinghours = ''
            self.totaldistancetravelled = ''
            self.faultecuid = ''
            self.faultecmservicemeterhours = ''
            self.faulttype = ''
            self.diagnosticslevelid = ''
            self.componentid = ''
            self.diagnosticsfailuremodeidentifier = ''
            self.operatorannunciation = ''
            self.j1939dtclevelid = ''
            self.suspectparameternumber = ''
            self.dtcfailuremodeidentifier = ''
            self.occurancecount = ''
            self.dtclampstatus = ''
            self.dtclampflash = ''
    return FaultCodeRecord()


def get_geotime_fence_event_instance():
    """ Method to return the instance of the GeoFence Time Event. """
    class GeoTimeFenceEventRecord(GPSInfo):
        """ Class to hold the information of the GeoTimeFence Event Record. """
        def __init__(self):
            super(GeoTimeFenceEventRecord, self).__init__()
            self.timestamputccurrent = ''
            self.trigger = ''
            self.totaloperatinghours = ''
            self.fenceid = ''
            self.offboardclientfenceid = ''
            self.offboardclientid = ''
    return GeoTimeFenceEventRecord()


def get_j1939dtc_v2_info():
    """ Method to return the instance of the J1939 DTC Info V2"""
    class J1939DTCRecord(GPSInfo):
        """ Class to hold the information of the J1939 DTCV2 Record. """
        def __init__(self):
            super(J1939DTCRecord, self).__init__()
            self.ecuid = ''
            self.j1939dtclevelid = ''
            self.timestamputcactivation = ''
            self.totaloperatinghours = ''
            self.suspectparameternumber = ''
            self.dtcoccurancecount = ''
            self.dtcfailuremodeidentifier = ''
            self.dtclampstatus = ''
            self.dtclampflash = ''
    return J1939DTCRecord()


def get_machineidle_startstop_record():
    """ Method to return the instance of the Machine Idle Start Stop. """
    class MachineIdleStartStopRecord(object):
        """ Class to hold the information of the Machine Idle Start Stop. """
        def __init__(self):
            self.ecuid = ''
            self.trigger = ''
            self.machineidleflag = ''
            self.timestamputctriggerchange = ''
    return MachineIdleStartStopRecord()


def get_machine_info_instance():
    """ Method to return the instance of the Machine Info. """
    class MachineInfoRecord(object):
        """ Class to hold the infromation of the Machine Info Record."""
        def __init__(self):
            self.timestamputccurrent = ''
            self.machineserialnumber = ''
            self.productid = ''
            self.dealerid = ''
    return MachineInfoRecord()


def get_machine_start_mode_instance():
    """ Method to return the instance of the Machine Start Mode."""
    class MachineStartModeRecord(GPSInfo):
        """ Class to hold the information of the Machine Start Mode. """
        def __init__(self):
            super(MachineStartModeRecord, self).__init__()
            self.timestamputccurrent = ''
            self.timestamputcactivation = ''
            self.machinestartstatus = ''
            self.machinestartstatustrigger = ''
            self.unknownnotconfigurednottriggered = ''
            self.otacommand = ''
            self.onboardservicetoolrestorecommand = ''
            self.gpsantennadisconnectedtimerexpired = ''
            self.telematicsantennadisconnectedtimerexpired = ''
            self.connectiontobackofficetimerexpired = ''
            self.tamperresolved = ''
            self.tamperuninstalled = ''
    return MachineStartModeRecord()


def get_mo_single_filerequest_record():
    """ Method to return the instance of the MO Single File Request."""
    class MOSingleFileRequestRecord(object):
        """ Class to hold the infromation of the MO Single File Request."""
        def __init__(self):
            self.filetype = ''
    return MOSingleFileRequestRecord()


def get_otasp_status_record():
    """ Method to return the instance of the OTASP Status."""
    class OTASPStatusRecord(object):
        """ Class to hold the information of the OTASP Status. """
        def __init__(self):
            self.otaspstatus = ''
    return OTASPStatusRecord()


def get_publicj1939_ecminfo():
    """ Method to return the instance of the PublicJ1939 ECM Info. """
    class ECMJ1939PublicInfoRecord(object):
        """ Class to hold the information of the Public J1939 ECM Info."""
        def __init__(self):
            self.timestamputccurrent = ''
            self.ecuid = ''
            self.ecmhardwarepartnumber = ''
            self.ecmserialnumber = ''
            self.softwarepartnumber = ''
            self.publicname = ''
            self.identitynumber = ''
            self.manufacturercode = ''
            self.ecuinstance = ''
            self.functioninstance = ''
            self.function = ''
            self.vehiclesystem = ''
            self.vehiclesysteminstance = ''
            self.industrygroup = ''
            self.arbitraryaddresscapable = ''
    return ECMJ1939PublicInfoRecord()


def get_remoteflash_status_response_record():
    """ Method to return the instance of the Remote Flash Status Response Record. """
    class RemoteFlashStatusResponseRecord(object):
        """ Class to hold the information of the Remote Flash Status Response Record. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.fsmstate = ''
            self.fsmstatus = ''
            self.firmwarestate = ''
            self.firmwarestatus = ''
    return RemoteFlashStatusResponseRecord()


def get_asset_move_fence_record():
    """ Method to return the instance of the Asset Move Fence Record. """
    class AssetMoveFenceRecord(GPSInfo):
        """ Class to hold the information of the Asset Move Fence Record. """
        def __init__(self):
            super(AssetMoveFenceRecord, self).__init__()
            self.timestamputccurrent = ''
            self.trigger = ''
            self.totaloperatinghours = ''
            self.gpsradiosourceid = ''
            self.fenceid = ''
    return AssetMoveFenceRecord()


def get_realtimeclockrange_instance():
    """ Method to return the instance of the Real Time Clock Range. """
    class RealTimeClockRangeRecord(object):
        """ Class to hold the infromation of the Real Time Clock Range."""
        def __init__(self):
            self.timestamputcfirstbad = ''
            self.totaloperatinghoursfirstbad = ''
            self.timestamputclastbad = ''
            self.totaloperatinghourslastbad = ''
    return RealTimeClockRangeRecord()


def get_smh_adjust_response_record():
    """ Method to return the instance of the SMH Adjust Response. """
    class SMHAdjustResponseRecord(object):
        """ Class to hold the infromation of the SMH Adjust Response. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.trigger = ''
            self.totaloperatinghoursprevious = ''
            self.totaloperatinghoursadjusted = ''
    return SMHAdjustResponseRecord()


def get_switch_config_record_instance():
    """ Method to return the instance of the Switch Config. """
    class SwitchConfigRecord(object):
        """ Class to hold the infromation of the Swith Config. """
        def __init__(self):
            self.trigger = ''
            self.digitalinputid = ''
            self.monitoringstate = ''
            self.monitoringcondition = ''
            self.delaytime = ''
            self.description = ''
            self.reportingcondition = ''
    return SwitchConfigRecord()


def get_ecmfingerprintrecord():
    """ Method to return the instance of the ECM fingerprint record."""
    class ECMFingerprintRecord(object):
        """ Class to hold the infromation of the ECM finger print message. """
        def __init__(self):
            self.timestamputccurrent = ''
            self.locationcode = ''
            self.ecmserialnumber = ''
            self.hardwarepartnumber = ''
            self.softwarepartnumber = ''
            self.applicationid = ''
            self.componentid = ''
            self.aftermarketid = ''
            self.datalinks = ''
    return ECMFingerprintRecord()


def get_tms_info_record_instance():
    """ Method to return the instance of the TMS Information record. """
    class TMSInfoRecord(object):
        """ Class to hold the infromation of the TMS info Record."""
        def __init__(self):
            self.timestamputccurrent = ''
            self.trigger = ''
            self.sensorlocationaxlenumber = ''
            self.sensorlocationtirenumber = ''
            self.ecuid = ''
            self.tiresensorstatus = ''
    return TMSInfoRecord()
