"""
*******************************************************************************
* COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
-------------------------------------------------------------------------------
**
** FILE NAME:
**     cgwlib/reports.py
**
** DESCRIPTION:
**     File to get the information of the Report page from Cat Gateway 2.0.
**
** AUTHOR:
**    Mani Shankar Venkatachalam(venkam5)
** HISTORY:
** Change 00  2017-01-15 (venkam5)
**     Created the Initial Version of the file for strucuture.
**
*******************************************************************************
"""
from time import sleep
from lib.webinterface import catch_except


class Reports(object):
    """ Class to do operations in Reports Page. """
    def __init__(self, parent):
        self.parent = parent

    @catch_except
    def _settle_at_flashlog(self):
        """ Method to go to Flash log Page."""
        self.parent.go_to_flashlog()

    @catch_except
    def get_flash_log_records(self):
        """ Method to get the flash log records. """
        self._settle_at_flashlog()
        sleep(1)

        class FlashLogTable(object):
            """ Class to hold the infromation of the Flash Log. """
            report_date = None
            queued = None
            download_success = None
            flash_success = None
            flash_failed = None
            initial_download_fail = None
            auto_retry_1 = None
            auto_retry_2 = None
            stale_files_removed = None
            download_no_response = None
            simsi_record_errors = None
            simsi_records_sent = None
            downloadable = None
        table_data = list()
        rows = self.parent.driver.\
            find_elements_by_xpath('.//*[@ng-repeat="report in flashLogList"]')
        for row in rows:
            info = FlashLogTable()
            cols = row.find_elements_by_tag_name('td')
            info.report_date = self.parent.get_value_by_element(cols[0])
            info.queued = self.parent.get_value_by_element(cols[1])
            info.download_success = self.parent.get_value_by_element(cols[2])
            info.flash_success = self.parent.get_value_by_element(cols[3])
            info.flash_failed = self.parent.get_value_by_element(cols[4])
            info.initial_download_fail = self.parent.get_value_by_element(cols[5])
            info.auto_retry_1 = self.parent.get_value_by_element(cols[6])
            info.auto_retry_2 = self.parent.get_value_by_element(cols[7])
            info.stale_files_removed = self.parent.get_value_by_element(cols[8])
            info.download_no_response = self.parent.get_value_by_element(cols[9])
            info.simsi_record_errors = self.parent.get_value_by_element(cols[10])
            info.simsi_records_sent = self.parent.get_value_by_element(cols[11])
            info.downloadable = \
                row.find_element_by_xpath('.//*[@class="corporate-yellow"]').is_enabled()
            table_data.append(info)
        return table_data

    @catch_except
    def get_rate_plan_log(self):
        """ Method to get the rate plan log. """
        return self.parent.get_value('.//*[@id="tabContent"]/div/div/div/div[4]/div]')
