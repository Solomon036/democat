""" Packages for Supporting Files. """

import os
from lib import catch_except
#from supportfiles.meta.metaclasses import CommHandles
from . import constants
from .constants import NODATA, SIMULTATION
from .common import handles, asset, ispassfailflag, htmlreport, msgcreationtimestamp, testcasenumber, testsetup, domain
from .common import engineecm, credentials
from supportfiles import constants
from supportfiles import pidinfo
from supportfiles import meta
from supportfiles.common import handles, asset, htmlreport
from supportfiles.common import credentials, engineecm, msgcreationtimestamp
from supportfiles.common import testcasenumber, testsetup, domain
from supportfiles import common


@catch_except
def initialcleanup():
    """ Method to clean up the any residual of handles and drivers."""
    os.system(r".\bin\setting.bat")


@catch_except
def finalcleanup():
    """ Method to clean up the any residual of handles and drivers."""
    os.system(r".\bin\setting.bat")
    os.system("taskkill /F /IM python.exe >nul 2>&1")

import glob
from os.path import dirname, basename, isfile
MODULES = glob.glob(dirname(__file__)+"/*.py")
__all__ = [basename(f)[:-3] for f in MODULES if isfile(f)]