"""
Module to hold the Meta Classes for the data storage and processing in runtime.
"""


class PLECMInfo(object):
    """ Class to hold the Product Link ECM information."""
    def __init__(self):
        self.id = None
        self.devicetype = None
        self.loccode = None
        self.aftermarketid = None
        self.ecmsn = None
        self.lastserviceflashtool = None
        self.ecmpn = None
        self.custecmpn = None
        self.macaddress = None
        self.operatingsystempn = None
        self.subscription = None


class PLRadioInfo(object):
    """ Class to hold the Product Link Radio information."""
    def __init__(self):
        self.type = None
        self.port = None
        self.macaddress = None
        self.ipaddress = None
        self.serialnum = None
        self.hardwarepn = None
        self.softwarepn = None
        self.firmwarever = None
        self.signalstrength = None
        self.currentnetwork = None
        self.preferrednetwork = None
        self.meid = None
        self.imsi = None
        self.imei = None
        self.commantennastatus = None
        self.gpsantennastatus = None


class DeviceGPSInfo(object):
    """ Class to hold the Product Link GPS information."""
    def __init__(self):
        self.gpssource = None
        self.gpstime = None
        self.longitude = None
        self.latitude = None
        self.altitude = None
        self.speed = None
        self.track = None
        self.fixquatlity = None
        self.noofstatelliteused = None
        self.noofstatellitevisible = None


class ApplicationInfo(object):
    """ Class to hold the Application information of Product Link."""
    def __init__(self):
        self.partnumber = None
        self.namecode = None
        self.componentid = None
        self.applicationid = None
        self.csvid = None


class EthernetPort(object):
    """ Sub Class to hold the Ethernet Port information of Product Link."""
    def __init__(self):
        self.vlan = None
        self.speed = None
        self.duplex = None
        self.addressmode = None
        self.metric = None
        self.devicetype = None
        self.ipaddress = None
        self.netmask = None
        self.dhcpdns = None
        self.gateway = None
        self.enable = None


class PortConfig(EthernetPort):
    """ Class to hold the Port Configuration information of Product Link."""
    def __init__(self):
        self.port1 = EthernetPort.__init__(self)
        self.port2 = EthernetPort.__init__(self)
        self.port3 = EthernetPort.__init__(self)
        self.port4 = EthernetPort.__init__(self)


class ElectroincControlModule(object):
    """ Class to hold the Electronic Control Module Information."""
    def __init__(self):
        self.name = None
        self.et = None
        self.cdluid = None
        self.j1939uid = None
        self.propj1939uid = None
        self.keysw = None
        self.keyon = None
        self.keyoff = None


class PLDeviceInfo(PLECMInfo, DeviceGPSInfo, ApplicationInfo,
                   PortConfig, ElectroincControlModule):
    """ Class to hold the Product Link Device information."""
    def __init__(self):
        PLECMInfo.__init__(self)
        DeviceGPSInfo.__init__(self)
        ApplicationInfo.__init__(self)
        PortConfig.__init__(self)
        ElectroincControlModule.__init__(self)
        self.rtermkeysw = None
        self.rtermkeyoff = None
        self.rtermkeyon = None
        self.priradio = PLRadioInfo()
        self.secradio = PLRadioInfo()


class SetupHandles(object):
    """ Class to hold the Setup handles for the Bench setup."""
    def __init__(self):
        self.fast = None
        self.controldesk = None
        self.vbench = None
        self.gps = None


class DataLinkHandles(object):
    """ Class to hold the handles for Datalink of the Bench setup."""
    def __init__(self):
        self.cdl = None
        self.et = None
        self.j1939 = None
        self.ssh = None


class WebHandles(object):
    """ Class to hold the handles for Webpages used for the Project."""
    def __init__(self):
        self.cgw = None
        self.plweb = None
        self.fids = None
        self.rs = None
        self.dsp = None
        self.equipdata = None
        self.srvdash = None
        self.mobileweb = None
        self.visionlink = None


class CommHandles(SetupHandles, DataLinkHandles, WebHandles):
    """ Class to hold the Communication Handles. """
    def __init__(self):
        SetupHandles.__init__(self)
        DataLinkHandles.__init__(self)
        WebHandles.__init__(self)


class SubCredentials(object):
    """ Sub-Class to hold the credentials information."""
    def __init__(self):
        self.username = None
        self.password = None


class Profiles(object):
    """ Class to hold the Profiles information. """
    def __init__(self):
        self.cat = SubCredentials()
        self.stdcat = SubCredentials()
        self.dlr = SubCredentials()
        self.stddlr = SubCredentials()
        self.customer = SubCredentials()
        self.stdcustomer = SubCredentials()


class DomainCredentials(object):
    """ Class to hold the Profile infromation based on Domains. """
    def __init__(self):
        self.cgw = Profiles()
        self.plweb = Profiles()
        self.dsp = Profiles()
        self.equipdatata = Profiles()
        self.visionlink = Profiles()
        self.fids = Profiles()
        self.rs = Profiles()


class Credentials(object):
    """ Class to hold the Primary & Secondary Credentials."""
    def __init__(self):
        self.pricredential = DomainCredentials()
        self.seccredential = DomainCredentials()
