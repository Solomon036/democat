"""
Module to hold the information of messages in form of classes.
"""


class StartStop(object):
    """ Class to hold the Start Stop Information."""
    def __init__(self):
        self.assetstatus = None
        self.ecmdescription = None
        self.macsecuritykeyid = None
        self.utctimestamp = None


class ReginfoRadio(object):
    """ Class used as a subclass to hold the Radio Registration information Messages. """
    def __init__(self):
        self.radioecmserialnumber = None
        self.type = None
        self.hardwarepn = None
        self.softwarepn = None
        self.firmwarever = None
        self.port = None
        self.cdmapreferred = None
        self.imei = None
        self.meid = None
        self.imsi = None
        self.iccid = None


class RegistrationInfoV2(object):
    """ Class to hold the Registration Info. """
    def __init__(self):
        self.ecmserialnumber = None
        self.machineserialnumber = None
        self.equipmentid = None
        self.numberofradios = None
        self.priradio = ReginfoRadio()
        self.secradio = ReginfoRadio()
        self.numofengines = None
        self.numofproducts = None
