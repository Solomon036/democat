"""
Module to hold the Meta Functions for the data storage and processing in runtime.
"""

from lib import catch_except
from .. import ispassfailflag
from .. import htmlreport
from supportfiles import constants, htmlreport



# @catch_except
# def checkrangevalue(domain, channel, expval, actval, tol=0.0):
#     """ Method to verify float or integer value whether it is within the range. """
#     status = "pass"
#     try:
#         if constants.NA not in [str(expval), str(actval)]:
#             if not (float(expval)-tol <= float(actval) <= float(expval)+tol):
#                 status = "fail"
#                 supportfiles.ispassfailflag = False
#     except Exception as err:
#         #if actval == constants.NODATA:
#         status = "fail"
#     #htmlreport.log_add_to_table([domain, channel, expval, actval, status])
#     return status


@catch_except
def checkstring(domain, channel, expval, actval):
    """ Method to Compare the Strings. """
    status = "pass"
    try:
        if not (str(expval) == str(actval) or constants.NA in [str(expval), str(actval)]):
            status = "fail"
            ispassfailflag = False
    except Exception as err:
        if actval == constants.NODATA:
            status = "fail"
        # htmlreport.log_error_to_html(str(err))
    #htmlreport.log_add_to_table([domain, channel, expval, actval, status])
    return status


@catch_except
def checksubstring(domain, channel, expval, actval):
    """ Method to verify whether the substring is present in the string. """
    status = "pass"
    try:
        if not (str(expval) in str(actval) or constants.NA in [str(expval), str(actval)]):
            status = "fail"
            ispassfailflag = False
    except Exception as err:
        if actval == constants.NODATA:
            status = "fail"
        htmlreport.log_error_to_html(str(err))
    #htmlreport.log_add_to_table([domain, channel, expval, actval, status])
    return status


@catch_except
def checkvaluegreater(domain, channel, firstval, secval):
    """ Method to check the value is greater than expected value. """
    status = "pass"
    try:
        if constants.NA not in [str(firstval), str(secval)]:
            if not firstval == secval:
                status = "fail"
            if firstval-secval >= 2:
                status = "pass"
    except Exception as err:
        if secval == constants.NODATA:
            status = "fail"
    #htmlreport.log_add_to_table([domain, channel, firstval, secval, status])
    return status




@catch_except
def checkvaluegreaterequal(domain, channel, firstval, secval):
    """ Method to verify float or integer value whether it is within the range. """
    status = "pass"
    if not firstval >= secval:
        status = "fail"
    #htmlreport.log_add_to_table([domain, channel, firstval, secval, status])
    return status

@catch_except
def checkstatus(domain, channel, expval, actval, tol=0.0):
    """ Method to verify float or integer value whether it is within the range. """
    status = "pass"
    if constants.NA not in [str(expval), str(actval)]:
        if not float(expval)-tol <= float(actval) <= float(expval)+tol:
            status = "fail"
            ispassfailflag = False
    #htmlreport.log_add_to_table([domain, channel, expval, actval, status])
    return status

@catch_except
def checklist(domain, channel, explist, actlist, tol=0.0):
    """ Method to verify float or integer value whether it is within the range. """
    status = "pass"
    if explist == actlist:
       status = "pass"
    else:
        status = "fail"
    ispassfailflag = False
    #htmlreport.log_add_to_table([domain, channel, explist, actlist, status])
    return status

@catch_except
def checkvalue(domain, channel, expval, actval, tol=0.0):
    """ Method to verify float or integer value whether it is within the range. """
    status = "pass"
    try:
        if float(expval) == float(actval):
            status = "pass"
        else:
            status = "fail"
    except Exception as err:
        if expval == actval:
            status = "pass"
        else:
            status = "fail"
    #htmlreport.log_add_to_table([domain, channel, expval, actval, status])
    return status

@catch_except
def checkdate(domain, channel, expval, actval, tol=0.0):
    """ Method to verify float or integer value whether it is within the range. """
    status = "pass"
    try:
        if float(expval) == float(actval):
            status = "pass"
        else:
            status = "fail"
    except Exception as err:
        if expval == actval:
            status = "pass"
        else:
            status = "fail"
    #htmlreport.log_add_to_table([domain, channel, expval, actval, status])
    return status

@catch_except
def checkboolean(domain, channel, expstatus, actstatus, tol=0.0):
    """ Method to verify float or integer value whether it is within the range. """
    status = "pass"
    if expstatus == actstatus:
       status = "pass"
    else:
        status = "fail"
    ispassfailflag = False
    #htmlreport.log_add_to_table([domain, channel, expstatus, actstatus, status])
    return status
