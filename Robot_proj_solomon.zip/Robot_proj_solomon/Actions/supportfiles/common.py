"""
Module to hold the basic structural instance for the test execution.
"""
from lib.report.report import Report
from supportfiles.meta.metaclasses import CommHandles
from supportfiles.meta.metaclasses import PLDeviceInfo, Credentials, ElectroincControlModule

handles = CommHandles()
asset = PLDeviceInfo()
htmlreport = Report()
credentials = Credentials()
engineecm = ElectroincControlModule()
ispassfailflag = True
msgcreationtimestamp = None
testcasenumber = None
testsetup = None
domain = None
testingresults = True