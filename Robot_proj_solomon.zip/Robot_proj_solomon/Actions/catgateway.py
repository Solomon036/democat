"""
Module to hold generic funcitons for Cat Gateway.
"""

import logging
from time import clock, sleep
from lib.cgwlib import CatGateway
from supportfiles.common import handles, credentials
# from supportfiles.meta.metadatetime import setdelay
from lib import catch_except
from robot.api.deco import keyword
# from supportfiles import urlconfig, testconfig, asset, htmlreport
# from .. import constants

handles=''
@keyword('Login to Cat gateway')
def initializecgw(url,username,password):
    """ Method to perform initialization for Cat Gateway."""
    global handles
    handles = CatGateway()
    status = handles.login(url,username,password)
    # if asset.id:
    #     handles.cgw.search_asset(asset.id, asset.macaddress)
    #htmlreport.log_to_html_report_text("Initialization of CGW is {}".format("Successful!!" if status else "Failed"))


#@catch_except
@keyword('Close Cat gateway')
def closecgw():
    """ Method to close the CGW webpage and reset the cgw handle to None."""
    global handles
    handles.logout()
    handles = None


@keyword('Search Asset in Cat gateway')
def cgw_search_asset(serialnumber):
    """ This method to searching the sn in CGW"""
    handles.cgw_search_sn(serialnumber)

#
# @catch_except
# def cgw_xml(xml):
#     """ This method to verify the xml config """
#     val = handles.cgw.get_cgw_xml_command(xml)
#     return val
#
#
# @catch_except
# def cgw_subscription(sub):
#     """ Method to check the the subscription push in CGW"""
#     val = handles.cgw.verify_cgw_subscription_command(sub)
#     return val
#
#
# @catch_except
# def cgw_subscription_cmd():
#     """ Method to get subscription command line"""
#     val = handles.cgw.get_cgw_subs_command()
#     return val
#
#
# @catch_except
# def cgw_terminal_logs_clear():
#     """ To clear the terminal line"""
#     handles.cgw.cgw_clear_terminal()
#
#
# @catch_except
# def calculateenginestatus(timestamp):
#     """ Method to calcuate the engine running status from timestamp. """
#     if "1980" in timestamp:
#         return constants.ENGINERUNNING
#     else:
#         return constants.ENGINENOTRUNNING
#
#
# @catch_except
# def readmessages(message, consolidated=False):
#     """ Method to read only the data information from the message."""
#     try:
#         return handles.cgw.transaction.get_message_details_info(message, consolidated=consolidated)['DataRecord']
#     except Exception as err:
#         htmlreport.log_image_to_html(handles.cgw.getscreenshot())
#         htmlreport.log_error_to_html(str(err))
#         logging.error(str(err))
#         return constants.NODATA
#
#
# @catch_except
# def waittillcommandqueuedelay(msg, present=True):
#     """ Wait till the command message is queued or consumed.\n
#     present: True if wait for message to be queued,
#     else False if the queued message is cleared or consumed.
#     """
#     stop = 0
#     start = clock()
#     while stop-start < constants.TIMEOUT:
#         cmdqueues = handles.cgw.configure.get_command_queue()
#         try:
#             if not((msg in cmdqueues) ^ present):
#                 break
#             else:
#                 stop = clock()
#                 sleep(2)
#         except Exception as err:
#             logging.error(str(err))
#     htmlreport.log_to_html_report_note("Total time taken "
#                                        "for Command {} is "
#                                        "{} seconds".
#                                        format("Queued" if present else "Consumed", clock() - start))
#
#
# @catch_except
# def uploadflashfile(flashfilename, wake="Cellular"):
#     """ Consolidated method to upload the flash file to the cgw and
#     wait till the flash file push message is consumed"""
#     handles.cgw.go_to_configure()
#     handles.cgw.configure.clear_command_queue()
#     handles.cgw.firmware.upload_frimware(flashfilename)
#     setdelay(30)
#     waittillcommandqueuedelay("PUSH - Deployment file")
#     handles.cgw.configure.wakeup(wake)
#     waittillcommandqueuedelay("PUSH - Deployment file", False)
#     setdelay(5*60)
#
#
# @catch_except
# def gethourslocinformation():
#     """ Method to get the Hours Loc information of CGW Message. """
#     hourslocinfo = handles.cgw.transaction.get_message_details_info("HoursLoc")[0]
#     hours = hourslocinfo.total_operating_hours
#     latitude = hourslocinfo.latitude
#     longitude = hourslocinfo.longitude
#     gpsstatus = constants.GPSINVALID \
#         if hourslocinfo.gps_status_invalid_flag == "1" else constants.GPSVALID
#     return hours, gpsstatus, latitude, longitude
#
#
# @catch_except
# def getshortmessageondemand(message):
#     handles.cgw.generalcmd.send_short_message_on_demand_to_device(message)
#     sleep(2)
#     handles.cgw.configure.wakeup()
#     sleep(5)
#     waittillcommandqueuedelay(message, False)
#
#
# @catch_except
# def readfiles(filetype):
#     """ Method to read only the row information of the files."""
#     try:
#         handles.cgw.transaction.filter_the_transaction_type('file')
#         handles.cgw.transaction.set_filter('file', filetype)
#         return handles.cgw.transaction.get_message_info(0)
#     except Exception as err:
#         htmlreport.log_image_to_html(handles.cgw.getscreenshot())
#         logging.error(str(err))
#         return constants.NODATA
