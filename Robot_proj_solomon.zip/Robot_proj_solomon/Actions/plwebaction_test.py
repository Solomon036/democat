import plweb_actions as pl


ASSETID='QPE64102'
URL='https://qa-productlinkweb.cat.com'
CGW_URL='https://qa-servicetool-beta.telematics-managed.com'

pl.initialize_plweb(URL,USER,PSWD,ASSETID)

pl.getenginestatusinformation(ASSETID)